Replacement Colour Icon + Patch file for 2ConnectYou
====================================================

Simply use the enclosed 2ConnectU.aif, Background.mbm and 2ConnectU.mbm to replace the existing files in c:\System\Apps\2ConnectU\ or d:\System\Apps\2ConnectU\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Egon Widmer (alpinist-epwb@dplanet.ch).  Many thanks to Egon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003