Replacement Colour Icon + Patch file for Asteroids
==================================================

Simply use the enclosed Asteroids.aif and Asteroids.mbm to replace the existing files in c:\System\Apps\Asteroids\ or d:\System\Apps\Asteroids\ (depending upon where you installed the application originally).

This patch created and provided courtesy of Matthew Walters.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2004