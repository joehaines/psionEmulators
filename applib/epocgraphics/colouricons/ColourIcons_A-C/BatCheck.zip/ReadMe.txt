Replacement Colour Icon + Patch file for BatCheck
=================================================

Simply use the enclosed BatCheck.aif and BatCheck.mbm to replace the existing files in c:\System\Apps\BatCheck\ or d:\System\Apps\BatCheck\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by David Lir (davlir@attcanada.ca).  Many thanks to David for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003