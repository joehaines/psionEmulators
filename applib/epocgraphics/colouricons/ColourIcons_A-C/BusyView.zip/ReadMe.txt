Replacement Colour Patch file 
=============================

Simply use the enclosed .mbm files to replace the existing files in c:\System\Apps\AppName\ or d:\System\Apps\AppName\ (depending upon where you installed the application originally and where 'AppName.mbm' would be the .mbm file name.  For example - Clock5.mbm).

This patch/icon created and provided courtesy of Matthew Walters.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

November 2004