Replacement icon for CalcCRC
============================

Simply use the enclosed .aif file to replace the existing files in c:\System\Apps\CalcCRC\ or d:\System\Apps\CalcCRC\ (depending upon where you installed the application originally).

Colour .aif kindly contributed by Lewis Barton <LRBarton@orange.net>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003