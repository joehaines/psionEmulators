CleanIt
+++++++

There is a separate CleanIt.mbm file as well as the CleanIt.aif file here.  Use this file to replace the existing CleanIt.mbm file on your machine.

These files courtesy of Simon Johns <SIJ@lsc.co.uk>.