Replacement Colour Icons for Collins dictionaries =================================================

These .aif files are used to replace the existing program .aif files as with all the other applications.  However, Collins/TomTom have a slightly tricky naming convention for their installed applications which makes them difficult to figure out.  Hence, here's a list of the available applications that I've got colour icons for and their associated file names:-

Application name														.aif File name
================														==============
"Easy Learning" English-French							Collinsf.aif
"Easy Learning" English-German							Collinsg.aif
Collins English-French											Bigcolf.aif
Collins English-German											Bigcolg.aif
Collins English-Italian											Bigcoli.aif
Collins English-Spanish											Bigcols.aif
Collins French-German												Bigcolfg.aif

These is also another zip file (CollinsEG.zip) kindly created and donated by Michael Degn (michael.degn@wanadoo.dk).  These are alternative icons to the Bigcolg.aif and Collinsg.aif.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003