Replacement Colour Icon + Patch file 
====================================

Simply use the enclosed files to replace the existing equivalent files in c:\System\Apps\AppName\ or d:\System\Apps\AppName\ (depending upon where you installed the application originally and where 'AppName.aif' would be the .aif file name.  For example - Clock5.aif).

This patch created and provided courtesy of Fritz Waechter.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

September 2004