Replacement Colour Icons + Patch files for Convert5 Pro
=======================================================

Simply use the enclosed Con5Pro.aif and Con5Pro.mbm to replace the existing files in c:\System\Apps\Con5Pro\ or d:\System\Apps\Con5Pro\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Steve Hodgson <steve@shodgson.org.uk>.  Many thanks to Steve for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003