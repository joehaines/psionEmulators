ConvertPro
++++++++++

There is a separate ConvertPro.mbm file as well as the ConvertPro.aif file here.  Use this file to replace the existing ConvertPro.mbm file on your machine to get colour toolbar icons.