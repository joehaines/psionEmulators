Replacement Colour Icons + Patch files for DSTEdit
==================================================

Simply use the enclosed DSTEdit.aif and DSTEdit.mbm to replace the existing files in c:\System\Apps\DSTEdit\ or d:\System\Apps\DSTEdit\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Steve Hodgson <steve@shodgson.org.uk>.  Many thanks to Steve for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003