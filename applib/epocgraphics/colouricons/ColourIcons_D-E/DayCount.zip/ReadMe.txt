Replacement Colour Icon + Patch file for DayCount
=================================================

Simply use the enclosed Daycount.aif and Daycount.mbm files to replace the existing files in c:\System\Apps\Daycount\ or d:\System\Apps\Daycount\ (depending upon where you installed the application originally).

Both files kindly contributed by Ric.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003