Essential Disk Utilities (EDU)
++++++++++++++++++++++++++++++

There are 4 separate .aif icon files and 4 separate mbm colour patch files
here for the 4 seperate programs that make up EDU:- ChkDisk.aif/.mbm,
Optimize.aif/.mbm, SmartFmt.aif/.mbm, and DiskEdit.aif/.mbm.  Install as per
any of the other .aif/.mbm files.

.aif icon files kindly contributed by Simon Johns <SIJ@lsc.co.uk>.

.mbm colour patch files kindly contributed by Lewis Barton
<LRBarton@orange.net>.

Best regards,
Martin Guthrie

May 2003
www.pscience5.net

