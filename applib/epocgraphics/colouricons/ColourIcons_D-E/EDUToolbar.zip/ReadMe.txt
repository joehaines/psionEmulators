Essential Disk Utilities (EDU)
++++++++++++++++++++++++++++++

There are 4 alternative .mbm colour patch/toolbar files here to the ones already offered in EDU.zip.  Install as per any of the other .mbm files.

These .mbm colour patch files kindly contributed by David Lir <davlir@attcanada.ca>.

Best regards,
Martin Guthrie

May 2003
www.pscience5.net

