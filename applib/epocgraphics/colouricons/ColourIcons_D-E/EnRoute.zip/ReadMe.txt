EnRoute (aka. Route)
++++++++++++++++++++

There are 2 replacement EnRoute.aif files here.  EnRoute.aif is the original 'highway+bridge' sign (colourised of course).  EnRoute1.aif is the newer TomTom 'hands' logo (again, colourised).  If you want to use the latter, unzip it and then rename to EnRoute.aif...

Martin