Replacement Colour Patch file for EpocSync
==========================================

Simply use the enclosed EpocSync.mbm to replace the existing file in c:\System\Apps\EpocSync\ or d:\System\Apps\EpocSync\ (depending upon where you installed the application originally).  The icon should already be in colour on your Extras bar if you installed directly onto your machine.

This colour patch was created by David Lir (davlir@attcanada.ca).  Many thanks to David for passing it on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003