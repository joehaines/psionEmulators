Replacement Colour Icon + Patch file for Palmtop Expense Manager
================================================================

Simply use the enclosed Expenses.aif, Expenses.mbm, Splash.pbm, and Logo.pdm files to replace the existing files in c:\System\Apps\Expenses\ or d:\System\Apps\Expenses\ (depending upon where you installed the application originally).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003