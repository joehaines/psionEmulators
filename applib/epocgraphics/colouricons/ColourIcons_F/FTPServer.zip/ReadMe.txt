Replacement Colour Icon + Patch file for FTP Server
===================================================

Simply use the enclosed FTPServer.aif and FTPIcons.mbm to replace the existing files in c:\System\Apps\FTPServer\ or d:\System\Apps\FTPServer\ (depending upon where you installed the application originally).

This colour conversion patch was created by Roel van Deinsen <schrobby20@hotmail.com>.  Many thanks to Roel for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003