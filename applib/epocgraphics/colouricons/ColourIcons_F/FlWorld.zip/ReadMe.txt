Replacement Colour Icon + Patch file for FlWorld
================================================

Simply use the enclosed FlWorld.aif and FlWorld.mbm files to replace the existing files in c:\System\Apps\FlWorld\ or d:\System\Apps\FlWorld\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Simon Johns (SIJ@lsc.co.uk).  Many thanks to Simon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003