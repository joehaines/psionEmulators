Replacement Colour Icons and Patch file for FlashBack
=====================================================

Simply use the enclosed FlashBack.aif and FlashBack.mbm files to replace the existing files in c:\System\Apps\FlashBack\ or d:\System\Apps\FlashBack\ (depending upon where you installed the application originally).

Both files kindly contributed by Max Westen <netbook@myrealbox.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003