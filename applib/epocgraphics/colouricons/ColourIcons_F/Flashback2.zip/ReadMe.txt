Replacement Colour Icon + Patch file for Flashback
==================================================

Simply use the enclosed Flashback.aif and Flashback.mbm to replace the existing files in c:\System\Apps\Flashback\ or d:\System\Apps\Flashback\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Egon Widmer (alpinist-epwb@dplanet.ch).  Many thanks to Egon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003