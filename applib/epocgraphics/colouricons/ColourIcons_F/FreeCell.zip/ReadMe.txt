Replacement Colour Icon + Patch file for FreeCell
=================================================

Simply use the enclosed FreeCell.aif and FreeCell.mbm files to replace the existing files in c:\System\Apps\FreeCell\ or d:\System\Apps\FreeCell\ (depending upon where you installed the application originally).

Both files kindly contributed by Michael Degn <michael.degn@wanadoo.dk>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003