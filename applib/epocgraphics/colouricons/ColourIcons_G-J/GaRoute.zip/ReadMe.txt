Replacement Colour Icons and Patch file for GaRoute
===================================================

Simply use the enclosed GaRoute.aif and GaRoute.mbm files to replace the existing files in c:\System\Apps\GaRoute\ or d:\System\Apps\GaRoute\ (depending upon where you installed the application originally).

Both files kindly contributed by Max Westen <netbook@myrealbox.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003