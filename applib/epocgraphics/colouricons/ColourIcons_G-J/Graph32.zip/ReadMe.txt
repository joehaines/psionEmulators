Replacement Colour Icon + Patch files for Graph32
=================================================

Simply use the enclosed Graph32.aif and associated .mbm files to replace the existing files in c:\System\Apps\Graph32\ or d:\System\Apps\Graph32\ (depending upon where you installed the application originally).

These files were kindly created and donated by Michael Degn (michael.degn@wanadoo.dk).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003