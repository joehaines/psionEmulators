Replacement Colour Icon + Patch file for Invasion
=================================================

Simply use the enclosed Invasion.aif and Graphics.mbm to replace the existing files in c:\System\Apps\Invasion\ or d:\System\Apps\Invasion\ (depending upon where you installed the application originally).

This patch created and provided courtesy of Fritz Waechter.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2004