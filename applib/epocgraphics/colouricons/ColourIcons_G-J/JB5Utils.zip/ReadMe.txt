Replacement Colour Icon + Patch file for JB5Utils
=================================================

Simply use the enclosed JB5Utils.aif and JB5Utils.mbm to replace the existing files in c:\System\Apps\JB5Utils\ or d:\System\Apps\JB5Utils\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by David Lir (davlir@attcanada.ca).  Many thanks to David for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003