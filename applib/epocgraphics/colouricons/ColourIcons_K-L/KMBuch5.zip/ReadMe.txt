Replacement Colour Icon + Patch file 
====================================

Simply use the enclosed .aif and .mbm files to replace the existing files in c:\System\Apps\AppName\ or d:\System\Apps\AppName\ (depending upon where you installed the application originally and where 'AppName.aif' would be the .aif file name.  For example - Clock5.aif).

This patch/icon created and provided courtesy of Markus Heinermann.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

November 2004