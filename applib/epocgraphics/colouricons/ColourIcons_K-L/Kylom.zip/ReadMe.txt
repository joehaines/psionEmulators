Replacement Colour Patch file 
=============================

Simply use the enclosed Kylom.mbm file to replace the existing files in c:\System\OPX\ or d:\System\OPX\ (depending upon where you installed the application(s) originally).

This patch created and provided courtesy of Fritz Waechter.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

November 2004