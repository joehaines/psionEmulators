MSN Messenger
+++++++++++++

There is a separate MessengerForce.mbm file as well as the MessengerForce.aif file here.  Use this file to replace the existing MessengerForce.mbm file on your machine to get colour icons on the toolbar.

These files courtesy of Simon Johns <SIJ@lsc.co.uk>.