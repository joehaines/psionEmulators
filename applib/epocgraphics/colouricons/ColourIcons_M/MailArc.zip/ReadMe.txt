Replacement Colour Icon + Patch file for MailArc
================================================

Simply use the enclosed MailArc.aif and MailArc.mbm to replace the existing files in c:\System\Apps\MailArc\ or d:\System\Apps\MailArc\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Lewis Barton <LRBarton@orange.net>.  Many thanks to Lewis for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003