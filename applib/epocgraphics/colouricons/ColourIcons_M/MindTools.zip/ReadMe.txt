Replacement Colour Icons + Patch files for MindTools
====================================================
MindTools.zip consist of:Mindt.aif - for the main shell applicationActionPlanner.aif + ap.mbm (patch) - for ActionPlannerBrainstormer.aif + bs.mbm (patch) - for BrainstormerCreativeMind.aif + cm.mbm (patch) - for CreativeMind
Simply use the enclosed .aif and associated .mbm files to replace the existing files in c:\System\Apps\AppName\ or d:\System\Apps\AppName\ (depending upon where you installed the application originally and 'AppName' benig the name of the application you're updating).

These files were kindly created and donated by Michael Degn (michael.degn@wanadoo.dk).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003