Replacement Patch files for MobiReader
======================================

Simply use the enclosed .aif and .mbm files to replace the existing files in c:\System\Apps\Mobireader\ or d:\System\Apps\Mobireader\ (depending upon where you installed the application originally).

.mbm file kindly contributed by Simon Johns <SIJ@lsc.co.uk>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003