Money
+++++

There are separate Money.mbm, Logo.pbm, and Splash.pbm files here as well as the Money.aif file.  Use these files to replace the existing Money files on your machine to get colour toolbar icons, etc.

These files kindly contributed by Simon Johns <SIJ@lsc.co.uk>.