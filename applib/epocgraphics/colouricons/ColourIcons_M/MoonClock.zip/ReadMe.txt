Replacement Colour Patch file 
=============================

Simply use one of the enclosed .mbm files - renamed to MoonClock.mbm - to replace the existing file in c:\System\Data\ or d:\System\Data\ (depending upon where you installed the application originally).  There are 2 slightly different versions to choose from.

These patches created and provided courtesy of Fritz Waechter.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

November 2004