Replacement Colour Icon + Patch file for Navigator
==================================================

Simply use the enclosed Navigator.aif, and Navigator.mbm to replace the existing files in c:\System\Apps\Navigator\ or d:\System\Apps\Navigator\ (depending upon where you installed the application originally).

These files were kindly created and donated by Ralph Sprenger (ralph.sprenger@gmx.net).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003