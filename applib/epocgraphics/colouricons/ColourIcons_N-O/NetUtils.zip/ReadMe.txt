Replacement Colour Icon + Patch file for NetUtils
=================================================

Simply use the enclosed NetUtils.aif and NetUtils.mbm to replace the existing files in c:\System\Apps\NetUtils\ or d:\System\Apps\NetUtils\ (depending upon where you installed the application originally).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003