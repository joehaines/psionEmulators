NetUtils Colour Icons and Buttons

These files have been created by Simon Johns

Replacement Colour Icon + Patch file for NetUtils
=================================================

Simply use the enclosed NetUtils.aif and NetUtils.mbm to replace the existing files in c:\System\Apps\NetUtils\ or d:\System\Apps\NetUtils\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Simon Johns (s.m.johns@bigfoot.com).  Many thanks to Simon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

September 2003