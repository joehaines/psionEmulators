Replacement Colour Icon + Patch file for NotePad
================================================

Simply use the enclosed NotePad.aif and NotePad.mbm to replace the existing files in c:\System\Apps\NotePad\ or d:\System\Apps\NotePad\ (depending upon where you installed the application originally).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003