Replacement Colour Patch file 
=============================

Simply use the enclosed .mbm files to replace the existing files in c:\System\Apps\Opm\ or d:\System\Apps\Opm\ (depending upon where you installed the application originally).

This patch/icon created and provided courtesy of Fritz Waechter.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

November 2004