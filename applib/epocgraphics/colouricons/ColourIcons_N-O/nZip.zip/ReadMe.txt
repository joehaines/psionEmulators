Replacement Colour Icon + Patch file for nZip
=============================================

Simply use the enclosed nZipUi.aif and nZipUi.mbm to replace the existing files in c:\System\Apps\nZipUi\ or d:\System\Apps\nZipUi\ (depending upon where you installed the application originally).

Files courtesy of Colin Messer.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2004