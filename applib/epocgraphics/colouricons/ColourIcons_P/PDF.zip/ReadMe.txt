Replacement Colour Icon + Patch file for PDF (Freeware version)
===============================================================

Simply use the enclosed PDF.aif and PDF.mbm to replace the existing files in c:\System\Apps\PDF\ or d:\System\Apps\PDF\ (depending upon where you installed the application originally).

Files courtesy of David Steer.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2004