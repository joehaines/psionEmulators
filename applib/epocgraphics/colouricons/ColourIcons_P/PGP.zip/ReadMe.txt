Replacement Colour Icon + Patch file for PGP
============================================

Simply use the enclosed PGP.aif, and PGP.mbm to replace the existing files in c:\System\Apps\PGP\ or d:\System\Apps\PGP\ (depending upon where you installed the application originally).

These files were kindly created and donated by Michael Degn (michael.degn@wanadoo.dk).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003