PhoneMan
++++++++

There is a separate PhoneMan.mbm file as well as the PhoneMan.aif file here.  Use this file to replace the existing PhoneMan.mbm file on your machine to get colour icons on the toolbar, etc.

These files created jointly by myself and Simon Johns <SIJ@lsc.co.uk>.