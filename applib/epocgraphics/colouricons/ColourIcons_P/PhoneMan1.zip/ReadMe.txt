Replacement Colour Icons and Patch file for PhoneMan
====================================================

Simply use the enclosed PhoneMan.aif and PhoneMan.mbm files to replace the existing files in c:\System\Apps\PhoneMan\ or d:\System\Apps\PhoneMan\ (depending upon where you installed the application originally).

Both files kindly contributed by Max Westen <netbook@myrealbox.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003