Replacement Colour Icon + Patch file for Photopal
=================================================

Simply use the enclosed Photopal.aif and Photopal.mbm to replace the existing files in c:\System\Apps\Photopal\ or d:\System\Apps\Photopal\ (depending upon where you installed the application originally).

This colour conversion icon + patch was created by Egon Widmer (alpinist-epwb@dplanet.ch).  Many thanks to Egon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003