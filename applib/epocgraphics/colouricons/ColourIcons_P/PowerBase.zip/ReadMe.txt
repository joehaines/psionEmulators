Replacement Colour Icon + Patch file for PowerBase
==================================================

Simply use the enclosed PowerBase.aif and PowerBase.mbm to replace the existing files in c:\System\Apps\PowerBase\ or d:\System\Apps\PowerBase\ (depending upon where you installed the application originally).

NB: This colour conversion patch was very kindly created by Michael Degn (michael.degn@wanadoo.dk) and donated by him to be used alongside the PowerBase.aif that I created.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

March 2003