Replacement patch file for PowerBase
====================================

Simply use the enclosed .mbm file to replace the existing file in c:\System\Apps\Powerbase\ or d:\System\Apps\Powerbase\ (depending upon where you installed the application originally).

This is an alternative PowerBase patch file to that previously contributed by Michael Degn.  This one kindly contributed by Tony Hotchkiss <tony.hotchkiss@freenet.de>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003