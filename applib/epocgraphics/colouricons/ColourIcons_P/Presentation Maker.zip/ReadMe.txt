Replacement icon and patch file for Presentation Maker
======================================================

Simply use the enclosed .aif and .mbm files to replace the existing files in c:\System\Apps\Presentation\ or d:\System\Apps\Presentation\ (depending upon where you installed the application originally).

Colour patch kindly contributed by Lewis Barton <LRBarton@orange.net>.  .aif file by myself.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003