Replacement Colour Icon + Patch file for ProLingua
==================================================

Simply use the enclosed Plprot.aif and Plprot.mbm to replace the existing files in c:\System\Apps\Plprot\ or d:\System\Apps\Plprot\ (depending upon where you installed the application originally).

NB: This colour conversion icon + patch was created by Egon Widmer.  Many thanks to Egon for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003