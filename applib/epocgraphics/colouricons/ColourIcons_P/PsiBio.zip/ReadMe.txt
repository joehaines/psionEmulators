Replacement Colour Icon + Patch file for PsiBio
===============================================

Simply use the enclosed PsiBio.aif and PsiBio.mbm files to replace the existing files in c:\System\Apps\PsiBio\ or d:\System\Apps\PsiBio\ (depending upon where you installed the application originally).

Both files kindly contributed by Michael Degn <michael.degn@wanadoo.dk>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003