Replacement icon file for Pdf+
==============================

Simply use the enclosed .aif file to replace the existing file in c:\System\Apps\PDFPlus\ or d:\System\Apps\PDFPlus\ (depending upon where you installed the application originally).

This .aif fixes the 'shimmering' effect seen on Series 7 / netBook screens - see the 'before & after' image to compare...

The PDF+ colour patch file is a file for the top toolbar in PDF+ - use in the normal way.

Both kindly contributed by Lewis Barton <LRBarton@orange.net>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003