Replacement Colour Icon + Patch file for psiMind
===============================================

Simply use the enclosed psiMind.aif and psiMind.mbm to replace the existing files in c:\System\Apps\psiMind\ or d:\System\Apps\psiMind\ (depending upon where you installed the application originally).

NB: This colour conversion was originally done by Egon Widmer but his website has since disappeared and so I am passing these files on to the EPOC community as a service on his part.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

March 2003
