Replacement Colour Icon + Patch file for RMRDraw
================================================

Simply use the enclosed RMRDraw.aif and RMRDraw.mbm files to replace the existing files in c:\System\Apps\RMRDraw\ or d:\System\Apps\RMRDraw\ (depending upon where you installed the application originally).

Both files kindly contributed by Michael Degn <michael.degn@wanadoo.dk>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003