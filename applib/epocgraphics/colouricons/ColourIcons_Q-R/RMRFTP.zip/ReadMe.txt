Replacement Colour Icon + Patch file for RMRFTP
===============================================

Simply use the enclosed RMRFTP.aif and RMRFTP.mbm to replace the existing files in c:\System\Apps\RMRFTP\ or d:\System\Apps\RMRFTP\ (depending upon where you installed the application originally).

NB: This colour conversion patch was originally done by Egon Widmer but his website has since disappeared and so I am passing these files on to the EPOC community as a service on his part.  The .aif file is my own one however.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

March 2003