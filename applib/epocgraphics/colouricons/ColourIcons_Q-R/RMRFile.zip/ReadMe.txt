Replacement Colour Icon + Patch file for RMRFile
================================================

Simply use the enclosed RMRFile.aif and RMRFile.mbm files to replace the existing files in c:\System\Apps\RMRFile\ or d:\System\Apps\RMRFile\ (depending upon where you installed the application originally).

These files were kindly created and donated by Michael Degn (michael.degn@wanadoo.dk).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003