Replacement Colour Icon + Patch file for RMRNews
================================================

Simply use the enclosed RMRNews.aif, and RMRNews.mbm to replace the existing files in c:\System\Apps\RMRNews\ or d:\System\Apps\RMRNews\ (depending upon where you installed the application originally).

These files were kindly created and donated by Simon Johns (SIJ@lsc.co.uk).

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003