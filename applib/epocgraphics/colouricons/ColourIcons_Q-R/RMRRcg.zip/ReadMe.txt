Replacement Colour Icon + Patch file for RMRRcg
===============================================

Simply use the enclosed RMRRcg.aif and RMRRcg.mbm files to replace the existing files in c:\System\Apps\RMRRcg\ or d:\System\Apps\RMRRcg\ (depending upon where you installed the application originally).

Both files kindly contributed by Matthew Walters <matthew.walters@ic24.net>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003