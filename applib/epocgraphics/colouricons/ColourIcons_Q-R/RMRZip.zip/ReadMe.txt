Replacement Colour Icon + Patch file for RMRZip
===============================================

Simply use the enclosed RMRZip.aif and RMRZip.mbm to replace the existing files in c:\System\Apps\RMRZip\ or d:\System\Apps\RMRZip\ (depending upon where you installed the application originally).

NB: This colour conversion was originally done by Egon Widmer but his website has since disappeared and so I am passing these files on to the EPOC community as a service on his part.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

February 2003