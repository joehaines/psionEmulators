Replacement Patch files for Safeplace
=====================================

Simply use the enclosed Safeplace.aif Safeplace.mbm files to replace the existing files in c:\System\Apps\Safeplace\ or d:\System\Apps\Safeplace\ (depending upon where you installed the application originally).

Both files kindly contributed by Simon Johns <s.m.johns@bigfoot.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003