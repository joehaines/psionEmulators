Replacement Colour Icon + Patch files for SameGame
==================================================

Simply use the enclosed SameGame.aif and various .mbm files to replace the existing files in c:\System\Apps\SameGame\ or d:\System\Apps\SameGame\ (depending upon where you installed the application originally).

Both files kindly contributed by David Steer <david@playright.plus.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003