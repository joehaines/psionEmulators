Replacement Colour Icon + Patch file for Sound Master
=====================================================

Simply use the enclosed Sound.aif, Logo.pdm and Sound.mbm to replace the existing files in c:\System\Apps\Sound\ or d:\System\Apps\Sound\ (depending upon where you installed the application originally).


Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003