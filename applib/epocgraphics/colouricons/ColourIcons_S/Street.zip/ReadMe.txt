Replacement Patch files for Street/CityMaps
===========================================

Simply use the enclosed two .mbm files to replace the existing files in c:\System\Apps\Street\ or d:\System\Apps\Street\ (depending upon where you installed the application originally).

Both files kindly contributed by Lewis Barton <LRBarton@orange.net>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

June 2003