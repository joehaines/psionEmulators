Replacement Colour Icon + Patch file for TheDialer
==================================================

Simply use the enclosed TheDialer.aif and TheDialer.mbm to replace the existing files in c:\System\Apps\TheDialer\ or d:\System\Apps\TheDialer\ (depending upon where you installed the application originally).

This colour conversion icon was done by myself and the patch was created by David Lir (davlir@attcanada.ca).  Many thanks to David for passing it on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

May 2003