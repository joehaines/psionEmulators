Replacement Colour Icon for Tomeraider
======================================

Replacing the icon for Tomeraider is just slightly more complicated than normal applications.  This because Palm-tec/Proporta upgraded the application to v2.x and changed the file format it handled - but left hooks in place to handle Tomeraider v1.x files (I think).  The upshot being that there are two 'Tomeraiders' installed on your machine:- 'Tomeraider' itself and 'TR2'.  Of these, it's the TR2.aif file that needs replacing to create a colour icon on your Extras bar (and the TR2.mbm file for the colour toolbar) - and that's what's enclosed here.  NB: don't delete any of the 'Tomeraider' app stuff on your machine - you still need it.

The colour patch was created by David Lir (davlir@attcanada.ca).  Many thanks to David for passing it on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

February & May 2003