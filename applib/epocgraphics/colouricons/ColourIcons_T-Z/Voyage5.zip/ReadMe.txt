Replacement Colour Icon + Patch file for Voyage5
================================================

Simply use the enclosed Voyage5.aif and Voyage5.mbm to replace the existing files in c:\System\Apps\Voyage5\ or d:\System\Apps\Voyage5\ (depending upon where you installed the application originally).

NB: The Voyage5 application was upgraded to a Voyage7 one (i.e. 2 separateapps),  but this is strictly for the former to run on a colour machine.  This colour conversion icon + patch was created by Michael Degn (michael.degn@wanadoo.dk).  Many thanks to Michael for passing them on for distribution.  :-)

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

April 2003