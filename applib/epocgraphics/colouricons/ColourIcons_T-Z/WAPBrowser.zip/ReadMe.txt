Replacement patch files for Psion WapBrowser
============================================

Simply use the enclosed .aif and .mbm files to replace the existing files in c:\System\Apps\WapBrowser\ or d:\System\Apps\WapBrowser\ (depending upon where you installed the application originally).

Both colour patches kindly contributed by Lewis Barton <LRBarton@orange.net>.  .aif file by myself.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003