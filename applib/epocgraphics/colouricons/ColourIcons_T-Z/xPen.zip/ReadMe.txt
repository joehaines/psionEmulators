Replacement Colour Icon + Patch file for xPen
=============================================

Simply use the enclosed xPen.aif and xPen.hdl to replace the existing files in c:\System\Apps\xPen\ or d:\System\Apps\xPen\ (depending upon where you installed the application originally).

NB: This colour conversion patch was originally done by Egon Widmer.  He kindly forwarded on the colour files to me to convert and generate the .aif file from.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

March 2003