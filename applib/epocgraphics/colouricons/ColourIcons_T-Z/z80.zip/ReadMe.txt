Replacement Patch files for the Z80 Spectrum emulator
=====================================================

Simply use the enclosed Z80.aif logo.pbm files to replace the existing files in c:\System\Apps\Z80\ or d:\System\Apps\Z80\ (depending upon where you installed the application originally).

Both files kindly contributed by Simon Johns <s.m.johns@bigfoot.com>.

Best regards,
Martin Guthrie
martin@pscience5.net
www.pscience5.net

August 2003