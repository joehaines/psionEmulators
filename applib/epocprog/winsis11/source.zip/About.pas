unit About;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls;

type
  TAboutBox = class(TForm)
    Panel1: TPanel;
    ProgramIcon: TImage;
    ProductNameLabel: TLabel;
    VersionLabel: TLabel;
    FreewareLabel: TLabel;
    CommentsLable: TLabel;
    OKButton: TButton;
    EmailLabel1: TLabel;
    EmailLabel2: TLabel;
    WebAddressLabel: TLabel;
    procedure OKButtonClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AboutBox: TAboutBox;

implementation

{$R *.DFM}

procedure TAboutBox.OKButtonClick(Sender: TObject);
begin
AboutBox.Hide;
end;

end.
 
