unit winsis;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Menus, ShellAPI, ExtCtrls, About, IniFiles;

type
  TForm1 = class(TForm)
    OpenDialog1: TOpenDialog;
    AppEdit: TEdit;
    PcPathEdit: TEdit;
    UidEdit: TEdit;
    AppLabel: TLabel;
    PcPathLabel: TLabel;
    UidLabel: TLabel;
    BrowseButton: TButton;
    UidButton: TButton;
    Memo1: TMemo;
    PsionPathEdit: TEdit;
    PsionPathLabel: TLabel;
    ExitButton: TButton;
    MakeSisButton: TButton;
    HelpButton: TButton;
    ZoomInImage: TImage;
    ZoomOutImage: TImage;
    IrImage: TImage;
    EditImage: TImage;
    MenuImage: TImage;
    MainPopupMenu: TPopupMenu;
    About: TMenuItem;
    EditPopupMenu: TPopupMenu;
    Cut1: TMenuItem;
    Copy1: TMenuItem;
    Paste1: TMenuItem;
    Exit1: TMenuItem;
    Openfile1: TMenuItem;
    Saveas1: TMenuItem;
    SaveDialog1: TSaveDialog;
    procedure BrowseButtonClick(Sender: TObject);
    procedure UidButtonClick(Sender: TObject);
    procedure ExitButtonClick(Sender: TObject);
    procedure MakeSisButtonClick(Sender: TObject);
    procedure ZoomOutImageClick(Sender: TObject);
    procedure ZoomInImageClick(Sender: TObject);
    procedure MenuImageClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure EditImageClick(Sender: TObject);
    procedure AboutClick(Sender: TObject);
    procedure Cut1Click(Sender: TObject);
    procedure Copy1Click(Sender: TObject);
    procedure Paste1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure Saveas1Click(Sender: TObject);
    procedure Openfile1Click(Sender: TObject);
    procedure PsionPathEditKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure HelpButtonClick(Sender: TObject);
  private
    { Private declarations }
    function GetUid(FileName: String): Longint;
    function GetFileName(FullFilePath: String): String;
    
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  procedure ShowString(AnyString: String);
  procedure ShowInt(Int: Longint);

implementation

{$R *.DFM}

procedure TForm1.BrowseButtonClick(Sender: TObject);
begin
if OpenDialog1.Execute
then
    begin
    if (ExtractFileExt(OpenDialog1.FileName) = '.app') or
       (ExtractFileExt(OpenDialog1.FileName) = '.aif') or
       (ExtractFileExt(OpenDialog1.FileName) = '.opx')
    then
        begin
           if ExtractFileExt(OpenDialog1.FileName) = '.opx' then
              AppEdit.Text := 'opx'
           else
               AppEdit.Text := GetFileName(OpenDialog1.FileName)
        end
    else
    if AppEdit.Text = '' then
       begin
       MessageDlg('First select an App, Aif or Opx file or type a '+#13+#10+'App name in the App name edit box.',mtError,[mbOK],0);
       Exit;
       end;
    PcPathEdit.Text := OpenDialog1.FileName;
    if ExtractFileExt(OpenDialog1.FileName) = '.opx' then
       PsionPathEdit.Text := '!:\system\' + AppEdit.Text + '\' +
                          ExtractFileName(OpenDialog1.FileName)
    else
        PsionPathEdit.Text := '!:\system\apps\' + AppEdit.Text + '\' +
                          ExtractFileName(OpenDialog1.FileName);
                          
    OpenDialog1.InitialDir := '';  //open again in last dir not ini file dir
    if (ExtractFileExt(OpenDialog1.FileName) = '.app') or
       (ExtractFileExt(OpenDialog1.FileName) = '.aif')
    then
        begin
        UidEdit.Text := IntToHex(GetUid(OpenDialog1.FileName), 8);
        UidButton.Enabled := True;
        Memo1.Lines[0] := '#{"' + GetFileName(OpenDialog1.FileName) + '"},('
                          + '0x' + IntToHex(GetUid(OpenDialog1.FileName), 8) + '),1,0,0';
        Memo1.Lines.Add('"' + OpenDialog1.FileName + '"-"' + PsionPathEdit.Text + '"');
        Memo1.Refresh;
        end
    else
        begin
        UidEdit.Text := '';
        UidButton.Enabled := False;
        Memo1.Lines.Add('"' + OpenDialog1.FileName + '"-"' + PsionPathEdit.Text + '"');
        Memo1.Refresh;
        end;
    end;
end;


procedure TForm1.UidButtonClick(Sender: TObject);
begin
if UidButton.Caption = 'Hex'
then
    begin
    UidEdit.Text := IntToStr(StrToInt('$' + UidEdit.Text));
    UidButton.Caption := 'Dec';
    end
else
    begin
    UidEdit.Text := {'Ox' + }IntToHex(StrToInt(UidEdit.Text), 8);
    UidButton.Caption := 'Hex';
    end;
end;


function TForm1.GetUid(FileName: String): Longint;
var
  F: file;
  Offset : Longint;
  Buf: Longint;
begin
AssignFile(F, FileName);
Reset(F, 1);
Offset := 8;
Seek(F,Offset);
BlockRead(F, Buf, 4);
CloseFile(F);
GetUid := Buf;
end;


function TForm1.GetFileName(FullFilePath: String): String;
var
   FileName: String;
   FileExt: String;
   FileExtLen: Integer;
begin
FileName := ExtractFileName(FullFilePath);
FileExt := ExtractFileExt(FullFilePath);
if FileExt = ''
then
    GetFileName := FileName
else
    begin
    FileExtLen := Length(FileExt);
    GetFileName := Copy(FileName, 0, Length(FileName) - FileExtLen)
    end;
end;


procedure TForm1.ExitButtonClick(Sender: TObject);
begin
Halt;
end;


procedure TForm1.MakeSisButtonClick(Sender: TObject);
Var
Handle: Integer;
F: TextFile;
begin
//check for makesis.exe
if FileExists(ExtractFilePath(Application.ExeName) + 'makesis.exe') then
   //do nothing
else //create the ini file
     begin
     MessageDlg('Makesis.exe is missing! Place a copy of '+#13+#10+'Makesis.exe in the same folder as '+#13+#10+'Winsis.exe',mtError,[mbAbort],0);
     Exit;
     end;
AssignFile(F, ExtractFilePath(Application.ExeName) + 'winsis.bat');
Rewrite(F);
Append(F);
Writeln(F, 'Makesis  -v winsis.pkg');
CloseFile(F);
Memo1.Lines.SaveToFile(ExtractFilePath(Application.ExeName) + 'winsis.pkg');
Handle := ShellExecute(0,'Open', Pchar(ExtractFilePath(Application.ExeName) + 'winsis.bat'),
'', Pchar(ExtractFilePath(Application.ExeName)), SW_SHOWNORMAL);
if MessageDlg('Run sis file!',
    mtInformation, [mbYes, mbNo], 0) = mrYes then
  begin
    Handle := ShellExecute(0, 'Open', 'winsis.sis', '',
    Pchar(ExtractFilePath(Application.ExeName)), SW_SHOWNORMAL);
  end;
  DeleteFile(ExtractFilePath(Application.ExeName) + 'winsis.bat');
  DeleteFile(ExtractFilePath(Application.ExeName) + 'winsis.pkg');
end;


procedure TForm1.ZoomOutImageClick(Sender: TObject);
begin
if Memo1.Font.Size = 24
then
    begin
    Memo1.Font.Size := 18;
    Exit;
    end;

if Memo1.Font.Size = 18
then
    begin
    Memo1.Font.Size := 14;
    Exit;
    end;

if Memo1.Font.Size = 14
then
    begin
    Memo1.Font.Size := 12;
    Exit;
    end;

if Memo1.Font.Size = 12
then
    begin
    Memo1.Font.Size := 10;
    Exit;
    end;

if Memo1.Font.Size = 10
then
    begin
    Memo1.Font.Size := 8;
    Exit;
    end;

if Memo1.Font.Size = 8
then
    begin
    Memo1.Font.Size := 24;
    Exit;
    end;
end;


procedure TForm1.ZoomInImageClick(Sender: TObject);
begin
if Memo1.Font.Size = 8
then
    begin
    Memo1.Font.Size := 10;
    Exit;
    end;

if Memo1.Font.Size = 10
then
    begin
    Memo1.Font.Size := 12;
    Exit;
    end;

if Memo1.Font.Size = 12
then
    begin
    Memo1.Font.Size := 14;
    Exit;
    end;

if Memo1.Font.Size = 14
then
    begin
    Memo1.Font.Size := 18;
    Exit;
    end;

if Memo1.Font.Size = 18
then
    begin
    Memo1.Font.Size := 24;
    Exit;
    end;

if Memo1.Font.Size = 24
then
    begin
    Memo1.Font.Size := 8;
    Exit;
    end;
end;


procedure TForm1.MenuImageClick(Sender: TObject);
begin
MainPopupMenu.Popup(Form1.Left + 40, Form1.Top + 170);
end;

procedure TForm1.FormCreate(Sender: TObject);
var
WinsisIni: TIniFile;
LastOpenDir: String;
LastSaveDir: String;
begin
//ini file section
WinsisIni := TIniFile.Create(ExtractFilePath(Application.ExeName) + 'WINSIS.INI');
if FileExists(ExtractFilePath(Application.ExeName) + 'WINSIS.INI') then
   //do nothing
else //create the ini file
     begin
     WinsisIni.WriteString('OpenPath', 'LastOpenDir', ExtractFilePath(Application.ExeName));
     WinsisIni.WriteString('SavePath', 'LastSaveDir', ExtractFilePath(Application.ExeName));
     end;
//now read from ini file
OpenDialog1.InitialDir := WinsisIni.ReadString('OpenPath', 'LastOpenDir', '');
SaveDialog1.InitialDir := WinsisIni.ReadString('SavePath', 'LastSaveDir', '');
WinsisIni.Free;
//end ini file section
Form1.Left := 30;
Form1.Top := 30;
end;


procedure TForm1.EditImageClick(Sender: TObject);
var
  I: Integer;
begin
if Memo1.SelLength = 0
then
    begin
    for I := 0 to EditPopupMenu.Items.Count - 2 do
        EditPopupMenu.Items[I].Enabled := False;
    end
else
    begin
    for I := 0 to EditPopupMenu.Items.Count - 1 do
        EditPopupMenu.Items[I].Enabled := True;
    end;
EditPopupMenu.Popup(Form1.Left + 40, Form1.Top + 220);
end;


procedure ShowString(AnyString: String);
begin
ShowMessage(AnyString);
end;


procedure ShowInt(Int: Longint);
begin
ShowMessage(IntToStr(Int));
end;


procedure TForm1.AboutClick(Sender: TObject);
begin
AboutBox.Left := Form1.Left + 130;
AboutBox.Top := Form1.Top + 80;
AboutBox.Show;
end;


procedure TForm1.Cut1Click(Sender: TObject);
begin
Memo1.CutToClipboard;
end;


procedure TForm1.Copy1Click(Sender: TObject);
begin
Memo1.CopyToClipboard;
end;


procedure TForm1.Paste1Click(Sender: TObject);
begin
Memo1.PasteFromClipboard;
end;


procedure TForm1.FormDestroy(Sender: TObject);
var
WinsisIni: TIniFile;
begin
if ExtractFilePath(OpenDialog1.FileName) = '' then
//do nothing
else
    begin
    WinsisIni := TIniFile.Create(ExtractFilePath(Application.ExeName) + 'WINSIS.INI');
    WinsisIni.WriteString('OpenPath', 'LastOpenDir', ExtractFilePath(OpenDialog1.FileName));
    WinsisIni.WriteString('SavePath', 'LastSaveDir', ExtractFilePath(SaveDialog1.FileName));
    //ShowString(ExtractFilePath(OpenDialog1.FileName));
    WinsisIni.Free;
    end;
end;


procedure TForm1.Saveas1Click(Sender: TObject);
begin
if SaveDialog1.Execute
then
    Memo1.Lines.SaveToFile(SaveDialog1.FileName);
end;


procedure TForm1.Openfile1Click(Sender: TObject);
begin
if OpenDialog1.Execute then
    Memo1.Lines.LoadFromFile(OpenDialog1.FileName);
end;


procedure TForm1.PsionPathEditKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
MessageDlg('Use the edit window to change this path.',mtInformation,[mbOK],0);
end;


procedure TForm1.HelpButtonClick(Sender: TObject);
begin
Application.HelpFile := ExtractFilePath(Application.ExeName) + 'WINSIS.HLP';
Application.HelpContext(1);
end;

end.
