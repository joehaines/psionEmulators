program winsis1;

uses
  Forms,
  winsis in 'winsis.pas' {Form1},
  About in '\Program Files\Borland\Delphi 2.0\Projects\WinSis\About.pas' {AboutBox};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'WinSis';
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TAboutBox, AboutBox);
  Application.Run;
end.
