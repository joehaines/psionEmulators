BRestart

Automatic Restart of all Documents/Applications after a Backup
By Steve Beadle
steve_beadle@iee.org
http://www.biblet.freeserve.co.uk
What does it do?
This program restarts documents and applications which have been stopped by PsiWin backup but which PsiWin cannot restart as they are not built-in.  i.e. Data and Agenda get restarted but Macro5 or BatCheck don't.  It does this with no user intervention.
Installation
BRestart requires Macro5 - Get Macro5 from any decent web site such as PsionKing (www.psionking.com).  Install Macro5 using its own method.  If you *really* don't need Macro5, then you can install it, copy \System\OPX\Macro5.* then uninstall it and reinstate those files.

Copy all files to a new folder called x:\System\Apps\BRestart where x: is any drive.  You may need to make the System folder visible from the System Preferences menu.

BRestart should then appear as an Extras icon.
How does it work?
BRestart does this by monitoring a selected file and detecting when that file is closed and opened.  The program itself *will not* respond to close requests and therefore will keep running across a backup. It can be stopped using Kill from the open file list or Exit from the program's menu.
What gets restarted?
Files to be restarted are specified in a directory. You can use shortcuts from NoMore, FileLink or Start5 to start programs like BatCheck.  Files ending in an underscore will not be opened.
How I use it
I set it to open files in my \Documents directory, and name shortcuts to programs starting in underscore to keep them out of the way.
Macro5 Required
This program requires Macro5 in order to restart applications. (It expects Macro5.mcx and Macro5.opx to be in x:\System\OPX where x:\ is any drive).
Preferences
Check Interval
Time period between checks of your selected application.  This just has to be longer than the minimum time it takes to backup your machine.
File to Monitor
This file is checked to see when it is closed and then re-opened.  When re-opened the selected files will be opened.  You need to keep this file open between backups.
Folder of Documents to Restart
All files in this folder (documents, OPL programs etc.) will be reopened on completion of the backup, excluding those ending with an underscore. (_)
Acknowledgements
To: Pascal Nicolas for his excellent Macro5 utility, required for this program.
http://www.geocities.com/SiliconValley/Pines/1215
Copyright
This program has been written by Steve Beadle. It may be distributed freely as long as it is not altered or sold. This program is a SmileWare, which means that if you use it, you "MUST" send me a :-) .  I will then notify you of new releases.
Thank you to all of you who send me comments, new ideas, and :-)
Disclaimer
While this program has been extensively tested I will not be held responsible for any problems it may cause (sleepless nights, flat batteries etc).  Please forward any comments you may have to:
	steve_beadle@iee.org
Updated software is available via:
	http://www.biblet.freeserve.co.uk
Smileware
This program will cost you nothing - except a smile :-)
Email a smile :-) to me if you have used the program -  I will not use your address for any mailings except for notification of updates - just to stroke my ego and encourage me to produce more.  In progress are:
IRChat		Infra-red chat dialog between two Psion 5s.
Chime		Clock and repeater.
SB-Utilities	Simple extensible unit and time conversion, with date utility and ruler.
5Play		Sound file player
Please let me know if you are interested in any of these programs.

Steve.