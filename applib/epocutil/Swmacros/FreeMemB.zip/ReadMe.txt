FreeMemB v1.00
--------------

The memory taken by the system seems
to increase with time as programs
and documents are opened and closed.

In fact, there is no memory leaks but
EPOC32 caches procedures and does not deallocate
all the memory when an application is closed,
in case it is opened again soon.
It saves time and reduces the fragmentation.

However the memory gets fragmented with time
and it reduces performances (large memory
segments are spread over serveral cells).

FreeMen defragments the memory and
reclaims all the unused segments.
FreeMemB is the batch version of FreeMem.
It frees up the memory but does display a report.


Installation:
-------------
1 - Copy FreeMemB.opo wherever you want (e.g. where
    you store all your macros).
2 - If you don't already have it, install SystInfo.sis
    as you do with any other sis file : double-click
    on it either on the PC (if PsiWin 2.1 is installed) or
    on the Series 5 (if there is an Add/Remove icon in the
    configuration panel).


Usage:
------
Run it from the shell or any other application as
a program or a macro.


Planned enhancements :
----------------------
None.


Copyright :
-----------
This program has been written by Pascal NICOLAS.
It may be distributed freely as long as it is
not altered or sold. This program is a SmileWare,
which means that if you use it, you "MUST" send me a :-)

At this point, many many thanks and :-) to MattM who
gave me the trick on how to clean up the memory.

Pascal NICOLAS
Email : pnicolas@geocities.com
Latest version at http://www.geocities.com/SiliconValley/Pines/1215