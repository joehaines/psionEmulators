PicFlip 1.0
===========
   ...a simple mbm viewer and grabber/paster with minimal frills

This software is completely free.  I have provided the source file in case anyone wants to muck about with it.  Please let me know if you make improvements.
This software is an add-in for Macro5 by Pascal Nicholas and uses Clipboard functions provided by clipbit.opx from EMCC.  Macro5 provides the framework for interaction with other applications on the Psion 5, particularly in this instance Sketch, while clipbit.opx provides the handling of graphics to and from OPL bitmaps.

How it works
============
PicFlip will look for mbm graphic files in C:\Pictures or D:\Pictures (it will use the first directory it finds) and will present mbm pitures found to the screen.  Multiple bitmaps will only show their first frame (I did say this is simple!).

Hot keys allow the user to flip through all the pictures in the directory as rapidly as possible.  Pictures larger than the screen can be scrolled using the cursor keys.

If you were in Sketch and had selected an area on screen when you started the macro, PicFlip will offer you the option of saving the area selected as an mbm file in your Pictures directory.

PicFlip will also allow you to copy an mbm file to the clipboard (for pasting in Sketch or a Sketch object).

See the menu if you need reminding about control keys (these will all work with or without holding down Control).

Installation
============

PsiChem.opo should be installed to the default Macros directory (in my case D:\Macros) and the Clipbit opx module should b installed by running clipbit.sis with your Psion connected in the usual way.  clipbit.oxh should end up in C or D:\System\OPL and clipbit.opx should end up in C or D:\System\OPX.  Please see extra information about clipbit at the end of this file. 

Known problems
==============
Users should be aware of the dangers of task switching away from PsiChem and forgetting that it is "tying up" Macro5 while it is running.  If it is necessary to leave PicFlip in the background for a period, remember to find it again by selecting the Macro5 icon in the Extras tray (this of course applies to any Macro5 macro).

Acknowledgements
================
Macro5 is a brilliant tool.  Thanks to Pascal Nicholas.  Without Macro5, PicFlip would not be the same without it.  Why don't Psion release such utilities themselves?  I still wish I could record a few keystrokes and quickly replay them with a pre-assigned key.  Macro5 doesn't do this.  Maybe I a just going to have to program this myself!
The Clipboard handling system was developed by EMCC and made available free for freeware programmes.  Please see the readme file for shareware and commercial terms.  Here are the freeware terms from this readme file.  Without this OPX, PicFlip would have been impossible.

CLIPBIT.OPX is Copyright EMCC 1998, all rights reserved.
TERMS AND CONDITIONS FOR USING CLIPBIT.OPX:
1. Personal and freeware use only.
Free i.e. for personal use and applications distributed to others as freeware. The only condition is that the user sends/distributor sends their name and address details with a brief description of how and why they are using it to EMCC - contact details are given below. 
CONTACTING EMCC
Tel:	+44 (0) 161 969 3205Fax:	+44 (0) 161 969 3197email:	info@emcc.cix.co.ukWeb site:	http://www.compulink.co.uk/~emcc/
EMCCP.O. Box 109SaleCheshireM33 4TAUK

FEEDBACK
========
I welcome feedback - positive or negative!  Suggestions for improvements will be met with sympathy and interest (assuming such improvements are within my programming capabilities!!!)

Disclaimer
==========
I disclaim all warranties, expressed or implied, including, without limitation, the warranties of merchantability and of fitness for any purpose. I assume no liability for damages, direct or consequential, which may result from the use of PsiChem or any of its components or files bundled in the distribution package.

Julian Toler, Nottingham, UK
Email: JulianToler@csi.com

