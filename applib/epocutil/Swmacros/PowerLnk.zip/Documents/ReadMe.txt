PowerLink

Automatic Activation of Remote Link to PC When External Power is Plugged In
By Steve Beadle 
steve_beadle@iee.org
http://www.biblet.freeserve.co.uk
What does it do?
This program turns the external link on or off according to the state of the external power source.  It is useful when you mainly use the remote link when you are at your desk with the external power plug in at the same time.  It does all this with no user intervention.
Installation
PowerLink requires Macro5 - Get Macro5 from any decent web site such as PsionKing (www.psionking.com).  Install Macro5 using its own method.  If you *really* don't need Macro5, then you can install it, copy \System\OPX\Macro5.* then uninstall it and reinstate those files.

Copy all files to a new folder called x:\System\Apps\PowerLink where x: is any drive.  You may need to make the System folder visible from the System Preferences menu.

PowerLink should then appear as an Extras icon.
How does it work?
PowerLink monitors for external power on regular intervals.  It then sets the link state accordingly.  When started up PowerLink will set the link state according to the power input.  The program *will not* respond to PC close requests and therefore will keep running across a backup. It can be stopped using Kill from the open file list or Exit from the program's menu.

While the serial link does consume some power when on, the extra CPU usage of this program may counteract this.  Where it is useful is in making sure that the link is on before you backup.  If this isn't quite what you want, please email me with suggestions.
Manual Control of the Link
You can turn the link on and off using PowerLink menus or other means.  PowerLink will not override your manual setting unless you insert or remove the external power.
Using Web and Email
The latest version of MessageSuite disables the link automatically but does not reenable it again when you finish with them.  PowerLink gets round this annoyance if, when you use MessageSuite 'mobile' you plug back into your PC to backup or transfer files.
Macro5 Required
This program requires Macro5 in order to restart applications. (It expects Macro5.mcx and Macro5.opx to be in x:\System\OPX where x:\ is any drive).
Preferences
Check Interval
Time period between checks of external power.  Do this too often and you waste power.  Not often enough would be inconvenient.
Acknowledgements
To: Pascal Nicolas for his excellent Macro5 utility, required for this program.
http://www.geocities.com/SiliconValley/Pines/1215
Copyright
This program has been written by Steve Beadle. It may be distributed freely as long as it is not altered or sold. This program is a SmileWare, which means that if you use it, you "MUST" send me a :-) .  I will then notify you of new releases.
Thank you to all of you who send me comments, new ideas, and :-)
Disclaimer
While this program has been extensively tested I will not be held responsible for any problems it may cause (sleepless nights, flat batteries etc).  Please forward any comments you may have to:
	steve_beadle@iee.org
Updated software is available via:
	http://www.biblet.freeserve.co.uk
Smileware
This program will cost you nothing - except a smile :-)
Email a smile :-) to me if you have used the program -  I will not use your address for any mailings except for notification of updates - just to stroke my ego and encourage me to produce more.  In progress are several more 'indispensble' programs.

Steve.