PsiChem 2.0
===========
...a graphics and database utility for chemists

This software is completely free.  I have provided the source file in case anyone wants to muck about with it.  Please let me know if you make improvements.
This software is an add-in for Macro5 by Pascal Nicholas and uses Clipboard functions provided by clipbit.opx from EMCC.  Macro5 provides the framework for interaction with other applications on the Psion 5, particularly in this instance Sketch, while clipbit.opx provides the handling of graphics to and from OPL bitmaps.
The intention is to provide a way of creating chemical structure graphics easily and simply using Sketch as recipient of the structural components. Graphics can be saved to a purpose designed database with any text notes which may be relevant.  This macro allows the user to browse the database of graphics and paste them back into sketch whenever required.
The fact that Sketch is used as the basis for molecular graphics, also permits the user to add such pictures to other Psion applications as Objects - just run the macro from within the Sketch object and save in the normal way.

Installation and file locations
==============================
PsiChem.opo should be installed to the default Macros directory (in my case D:\Macros) and the Clipbit opx module should b installed by running clipbit.sis with your Psion connected in the usual way.  clipbit.oxh should end up in C or D:\System\OPL and clipbit.opx should end up in C or D:\System\OPX.  Please see extra information about clipbit at the end of this file.  That is basically all you need to do, however for those interested in what will then happen, here is a summary:
PsiChem will create a subdirectory in the macros folder called "PsiChem" and nested within PsiChem will create a directory called "Library".  A file called Library.ini will be created in the PsiChem directory.  This is an opl database file containing the library records (filenames of mbm graphics previously created and text notes relating to these graphics).  The default location for the mbm graphic files will therefore be [Macros path]\PsiChem\Library\ although it is possible for PsiChem to keep track of mbm files anywhere on your disk/directory structure.
The default directory structure is therefore:
Macros__PsiChem.opo
  |__PsiChem__Library.ini
        |__*.mbm graphics

Please note that PsiChem communicates with Sketch via the clipboard and normal Psion 5 format mbm files.  Files created using PsiChem can be imported into Sketch in the normal way, although I expect users will find it easier to use the PsiChem Library functions.
I have included a few simple chemical structure mbm files as examples of output.

Using PsiChem
=============

Structural Components
=====================
"Cyclic" for 5 and 6 atom rings (saturated and unsaturated)
"Bonds" for accurate bond angles and lengths.  Includes 3D style bonds (slats and wedges)
"Arrows" and "Brackets" for - guess what?
"Formula" for entering text and molecular shorthand.  The default text mode is formatted in a way familiar to chemists.  For example, entering CH2CH3 will result in the 2 and 3 being subscript.  Entering Na+ or Cl- will result in the ionic charge symbols being superscript.  If you need to enter un-formatted text, de-select the option box.

Structural components are created in a hidden bitmap and immediately pasted into Sketch.  Pasted items should be moved (using pen or cursor) to desired locations to  make up your desired structural diagram.  If Sketch is not running (either as Sketch or as a Sketch object in another app), you will see the error message "nothing to paste" as only Sketch can recognise a Clipboard bitmap. (The component will actually remain in the Clipboard so if you go into Sketch and paste you will see the result!).

Library Functions
=================
"Save" save a selected area in Sketch
"Add" add a graphic (mbm) file already present on disk. You can see that this function makes it easy to build up a library of non chemical pictures which can be flipped through.  For this purpose, if you do not need the chemical stuff, may I suggest that another macro might be better?   Try my macro PicFlip for this purpose.  This does not carry the overhead of the chemical stuff but has the advantage of being able to view graphics larger than the screen (yippee).
"Browse" browse the library of saved graphics.  The screen shows the filename and the first line of any text note.  To see the rest of a multiline note, use "Edit".  In browse mode, there is a menu available if you can't remember the hotkeys.  Most of the menu keys will also work without using the Control key modifier (except for edit where it I have provided the facility of using the Spacebar as an additional one button feature.

Browse Hotkey Summary
=====================
*FILE
Close      Ctrl+e or just e or [Escape]
*EDIT
Copy       Ctrl+c or c  (just copies to clipboard)
Paste      Ctrl+v or v or [Enter] (pastes to Sketch)
Add        Ctrl+a or a  (add  existing mbm file to library)
Edit       Ctrl+Shift+e (allows editing of file name and notes)
Rename     Ctrl+r or r  (Renames mbm file on disk and updates record)
Delete     Ctrl+d or d or [Delete] (deletes record and/or file)
*VIEW
Text mode  Ctrl+t or t or [Space bar]  (view and edit multiline note)
Next       Ctrl+n or n or [Cursor Right]
Back       Ctrl+b or b or [Cursor Left]
*TOOLS
Find       Ctrl+f or f  (Find a record)
Move to last Ctrl+l or l  (Moves the current record to last in file)
Help       Ctrl+h or h
About      Ctrl+o or o

Tips
====
I strongly recommend that you assign a hot key for this macro.  It is designed to be called repeatedly throughout the creation of a molecular structure and it would be tedious to have even one extra keystroke.
Try using the transparency control in Sketch to give various effects.  For example, an opaque "N" added to a benzene ring will easily make pyridine.
If you frequently manage complex structures having a common component, to save drawing the common item each time, save it as a template and use the Library paste function to start a new structure when needed.
If you need to incorporate molecules in reports or faxes, create a Sketch object within Word and run PsiChem from there.

Known problems
==============
Users should be aware of the dangers of task switching away from PsiChem and forgetting that it is "tying up" Macro5 while it is running.  If it is necessary to leave PsiChem in the background for a period, remember to find it again by selecting the Macro5 icon in the Extras tray (this of course applies to any Macro5 macro.
I have not bothered to tweak the slight drawing inaccuracies caused by integer conversion rounding errors.  In my view, the additional code is sacrificed in favour of a smaller program size and faster loading.

Acknowledgements
================
Macro5 is a brilliant tool.  Thanks to Pascal Nicholas.  Without Macro5, PsiChem would have been too awkward to use (or would have involved programming beyond my meagre capabilities).  Why don't Psion release such utilities themselves?  I still wish I could record a few keystrokes and quickly replay them with a pre-assigned key.  Macro5 doesn't do this.  Maybe I a just going to have to program this myself!
The Clipboard handling system was developed by EMCC and made available free for freeware programmes.  Please see the readme file for shareware and commercial terms.  Here are the freeware terms from this readme file.  Without this OPX, PsiChem would have been impossible.
CLIPBIT.OPX is Copyright EMCC 1998, all rights reserved.
TERMS AND CONDITIONS FOR USING CLIPBIT.OPX:
1. Personal and freeware use only.
Free i.e. for personal use and applications distributed to others as freeware. The only condition is that the user sends/distributor sends their name and address details with a brief description of how and why they are using it to EMCC - contact details are given below. 
CONTACTING EMCC
Tel:	+44 (0) 161 969 3205Fax:	+44 (0) 161 969 3197email:	info@emcc.cix.co.ukWeb site:	http://www.compulink.co.uk/~emcc/
EMCCP.O. Box 109SaleCheshireM33 4TAUK

FEEDBACK
========
I welcome feedback - positive or negative!  Suggestions for improvements will be met with sympathy and interest (assuming such improvements are within my programming capabilities!!!)

Disclaimer
==========
I disclaim all warranties, expressed or implied, including, without limitation, the warranties of merchantability and of fitness for any purpose. I assume no liability for damages, direct or consequential, which may result from the use of PsiChem or any of its components or files bundled in the distribution package.

Julian Toler, Nottingham, UK
Email: JulianToler@csi.com


