Welcome to SAVENEWS Macro v1.00
------------------
To be used with Macro5 (from v2.37) and
RMRNews News Reader for EPOC (v1.00F English)

PLEASE READ CAREFULLY
------------------
SaveNews is a macro that automates the process of storing your articles
from RMRNews to any number of "preformatted" Data files (e.g. one for
each NewsGroup you have subscribed).
Before proceeding, keep in mind the following:
* especially when you choose to archive multiple articles, SaveNews
  may take some time to accomplish its task: please note that while the
  macro is running, Macro5 is NOT available for other operations and you
  also should NOT switch to other tasks or applications;
* be also advised NOT to touch the keyboard while SaveNews is running,
  because you could interfere with the scheduled sequence of keystrokes,
  thus leading to some misbehavior of the macro itself (including the
  deletion of all your articles in the worst case, only if the "auto-delete"
  option is selected);
* use the "auto-dele" option with care, as there is no way of restoring
  any deleted article from RMRNews. I strongly recommend a good
  BACKUP before starting to play with SaveNews...
* I decline any responsibility for any loss of data that may result from
  the use of this program.

HOW TO INSTALL AND USE
------------------
1)  Unzip the savenews.zip file.
2)  Copy SaveNews.opo, SaveNews.ico and SaveNews.box to the folder
    where you keep all the macros of Macro5. The SaveNews.box file is
    a "preformatted" Data file used to create new target Data files from
    within the macro. DO NOT use this file to store your articles, just
    leave it empty in your macros folder.
3)  Launch Macro5 and create a new shortcut to SaveNews.opo (remember
    to select "Macro" and not "Program" in the shortcut "Type" definition).
4)  Call SaveNews macro through the associated Macro5 shortcut: the first
    time you launch it, a Setup process will start, showing your System
    settings: location of your RMRNews program, and Macro5 version
    (remember you need v2.37 at least, as this macro is not tested with
    previous releases); a second dialog will ask you for the location
    of your default Data file (the one that will be used by default to store
    your articles); if you do not have previous .box Data files to use,
    select NEW and a dialog will let you create a new Data file and place
    it wherever you want (the .box extension will be automatically added
    if you forget it); finally a last window will ask if you want to enable
    the choice of different Data files (note that you can create multiple
    Data files also in a second time using the NEW option), and if you
    want to open a dialog window to automate the process of archiving
    (and deleting) a group of articles each time you launch SaveNews.
5)  All these settings are stored to a SaveNews.ini file located in the
    "C:\System\" folder; if for any reason you need to change these settings,
    simply delete the file, and when you will recall SaveNews, the setup
    process will be launched again.
    Alternatively, you can relaunch the Setup procedure from within the
    macro, in the target data file window (if enabled).
6)  Once accomplished the setup process, these are the steps to follow:
    - launch your RMRNews program
    - highlight an article without opening it (do not press Enter)
    - call SaveNews macro through the associated Macro5 shortcut
NOTE: if the highlighted article is not available off-line (you just
  downloaded the header), the macro automatically stops and the
  connection window will be displayed, so that you can retrieve the
  whole article from your news server, or abort the connection.
7)  According to the options you have selected in the setup process, once
    launched, SaveNews may:
    - ask for the location of your target Data file to store your article(s)
    - ask for the number of articles to automatically archive
    - ask if it has to delete the original article(s) from RMRNews
8)  If everything is OK, once SaveNews has finished its task, you should
    find yourself again in the RMRNews screen, but you should also find
    the article(s) stored in the (selected) target Data file.

NOTES ON THE NEWSBOX DATA FILE
------------------
The "preformatted" DATA file, where the articles from RMRNews are
stored, has the following labels:
Subject  (type: text length: 250)  second sorting key (ascending)
Date     (type: text length: 30)   first sorting key  (descending)
From     (type: text length: 250)
To       (type: text length: 250)
CC/BCC   (type: memo length: unlimited)
Body     (type: memo length: unlimited)

The format of the Date field is "yyyy/mm/dd" in order to have the articles
correctly sorted by time in the NewsBox file.
Some of the above fields are not used by SaveNews, but are left to
maintain the full compatibility with the Data files used by SaveMail
(a similar macro that works with the Email application), so you can
also use "mixed" target files to store articles or messages both from
RMRNews and the Email application.

TRANSLATING THE OPL CODE
------------------
Feel free to modify the source code (SaveNews.opl) as you like...

KNOWN ISSUES
------------------
* If an article has a field (excluded the body of the article) with more
  than 250 characters, only the first 250 will be copied to the Data file;
  if this happens, a dialog is displayed to alert you
* the Date field of the target Data file will show the time of archiving,
  marked with (*) and not the real time of the message; if you want to
  store the real time of the message, then open RMRNews (Article view)
  and select menu - view - "show headers": some additional information
  (including date & time of the article) will be copied to the body field
  of the target Data file

ACKNOWLEDGMENTS
------------------
A great thank you to:
* Pascal Nicolas for writing Macro5
  Visit his homepage for a huge library of useful macros:
  http://www.geocities.com/SiliconValley/Pines/1215/
* Serge Chestopalov for writing RMRNews,
  available from RMR Software at:
  http://www.rmrsoft.com/
* Roger R. Prokic for suggesting and beta testing this macro

Any comments & suggestions are welcome!

E-mail me at:
  sergioalisi@geocities.com
Visit my homepage at:
  http://www.geocities.com/siliconvalley/bridge/1492

THANKS & ENJOY