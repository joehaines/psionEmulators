EScript sample macros
=====================

The following macros are included within this zip file and demonstrate the EScript macro system:-

BattCheck.opo - Displays the system screen battery status dialog. Settings
allow you to configure wether the user returns to the original application
when finished by pressing ENTER.

DateStamp.opo - Pastes the date and time into the current application or
document. Settings configure wether the date and/or time is pasted.

Evaluate.opo - Evalutates a sum. Type 2+2 into an application or document and run the macro. The sum is selected and the answer is pasted ie, 2+2=4.

Shortcut.opo - This macro uses the shortcuts.dbf data file to replace abbreviations with full text words. Type ys in an application or document and run the macro. ys is selected and replaced with 'Yours Sincerely'. You can configure the shortcuts from the macro settings dialog within ExtraBars.
Make sure shortcut.opo is in the same folder as the Shortcut.opo macro file.

SpellCheck.opo - Checks the spelling of a word. Type a word and run the macro. The current word is selected and checked in the spell application. Alternatives are shown and selecting one and pressing the ENTER key replaces the original word.

Todolist.opo - Displays the Todo view in agenda. (Foreign language machines may need to alter the code to rename the "Agenda" string with the foreign version).

JasonK - 21/9/98