@echo off

rem -------------------------------------------------------------------------
rem
rem EPOC32 SDK DOEBLD 
rem 
rem -------------------------------------------------------------------------
set example=%2
set implmnt=%3
set build=%4

if "%1"=="createproject"  goto docp
if "%1"=="createworkdirs" goto domw
if "%1"=="buildproject"   goto dobp
if "%1"=="cleanproject"   goto docl
goto end

rem -------------------------------------------------------------------------
rem Create a project
rem -------------------------------------------------------------------------
:docp
echo  Creating project file for "%example%" "%implmnt%"
call makmake %example% %implmnt%
goto end

rem -------------------------------------------------------------------------
rem Create work directories
rem -------------------------------------------------------------------------
:domw
echo  Creating work directories for "%example%" "%implmnt%"
call makmake -makework %example% %implmnt%
goto end

rem -------------------------------------------------------------------------
rem Build project
rem -------------------------------------------------------------------------
:dobp
echo  Building %example% %implmnt% %build%
if "%implmnt%"=="wins" goto dobpws
if "%implmnt%"=="WINS" goto dobpws
if "%implmnt%"=="marm" goto dobpmm
if "%implmnt%"=="MARM" goto dobpmm
goto end

:dobpws
call nmake /s /nologo /f %example%.%implmnt%  %build%
if exist \Epoc32ex\Opl\%example%     copy \Epoc32ex\Opl\%example%      \Epoc32\Wins\C\Documents
if exist \Epoc32ex\Opl\%example%.oxh copy \Epoc32ex\Opl\%example%.oxh  \Epoc32\Wins\C\Documents
goto end

:dobpmm
call nmake /f %example%.%implmnt% /x %example%.AER  %build%
if "%build%"=="rel" goto dobpmm04
if "%build%"=="REL" goto dobpmm04
if "%build%"=="deb" goto dobpmm06
if "%build%"=="DEB" goto dobpmm06
goto end

:dobpmm04
echo creating "%example%.sis"
call copy %example%.rkg  %example%.pkg
call makesis %example%.pkg
goto end

:dobpmm06
echo creating "%example%.sis"
call copy %example%.dkg  %example%.pkg
call makesis %example%.pkg
goto end


rem -------------------------------------------------------------------------
rem Clean project
rem -------------------------------------------------------------------------
:docl
echo  Cleaning project %example% %implmnt%
call makmake -clean %example% %implmnt%
goto end

:end
set build=
set example=
set implmnt=

