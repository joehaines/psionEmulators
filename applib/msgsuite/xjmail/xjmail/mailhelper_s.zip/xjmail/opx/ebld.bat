@echo off

rem -------------------------------------------------------------------------
rem
rem EPOC32 SDK EBLD implementation batch file for the Opl example set
rem 
rem -------------------------------------------------------------------------

rem -------------------------------------------------------------------------
rem Set the list of examples
rem -------------------------------------------------------------------------
set prjlist=mailhelper


if "%1"==""              goto Lhelp 
if "%1"=="?"             goto Lhelp
if "%1"=="help"          goto Lhelp
if "%1"=="HELP"          goto Lhelp 

rem -------------------------------------------------------------------------
rem Expect to build all examples for a specific implementation
rem and build type
rem -------------------------------------------------------------------------
if "%1"=="ALL"           goto L100 
if "%1"=="all"           goto L100 

rem -------------------------------------------------------------------------
rem Expect to build one or all examples for all combinations of implementation
rem and build type
rem -------------------------------------------------------------------------
if "%1"=="BLDALL"        goto L200
if "%1"=="bldall"        goto L200

rem -------------------------------------------------------------------------
rem Expect to create a project file for a single example or project files for
rem all examples
rem -------------------------------------------------------------------------
if "%1"=="MAKMAKE"       goto L300
if "%1"=="makmake"       goto L300

rem -------------------------------------------------------------------------
rem Expect to create the work directories
rem -------------------------------------------------------------------------
if "%1"=="MAKEWORKDIR"   goto L400
if "%1"=="makeworkdir"   goto L400

rem -------------------------------------------------------------------------
rem Expect to delete all files in all work directories
rem -------------------------------------------------------------------------
if "%1"=="CLEAN"         goto L500
if "%1"=="clean"         goto L500

rem -------------------------------------------------------------------------
rem Expect to run an exanple for a single build
rem -------------------------------------------------------------------------
if "%1"=="RUN"           goto L600
if "%1"=="run"           goto L600

rem -------------------------------------------------------------------------
rem Expect to build a single project for a specific implementatation and 
rem build type
rem -------------------------------------------------------------------------
goto L700



rem -------------------------------------------------------------------------
rem Process remaining arguments and do the job
rem -------------------------------------------------------------------------

rem -------------------------------------------------------------------------
rem Build all examples for a specific implementation and build type
rem -------------------------------------------------------------------------
:L100
if "%2"=="WINS" goto L104
if "%2"=="wins" goto L104
if "%2"=="MARM" goto L104
if "%2"=="marm" goto L104
echo 2nd argument missing or contains invalid implementation; must be one of
echo     WINS
echo     MARM
goto end

:L104
if "%3"=="DEB" goto L108
if "%3"=="deb" goto L108
if "%3"=="REL" goto L108
if "%3"=="rel" goto L108
echo 3rd argument missing or contains invalid build;must be one of
echo     DEB
echo     REL
goto end

:L108
if "%4"==""      goto L112
if "%4"=="clean" goto L116
if "%4"=="CLEAN" goto L116
echo 4th argument is invalid; if specified, it must be one of
echo     CLEAN
goto end

:L112
for %%i in (%prjlist%) do call doebld createproject  %%i %2
for %%i in (%prjlist%) do call doebld createworkdirs %%i %2
for %%i in (%prjlist%) do call doebld buildproject   %%i %2 %3
goto end

:L116
for %%i in (%prjlist%) do call doebld createproject  %%i %2
for %%i in (%prjlist%) do call doebld cleanproject   %%i %2
for %%i in (%prjlist%) do call doebld createworkdirs %%i %2
for %%i in (%prjlist%) do call doebld buildproject   %%i %2 %3
goto end



rem -------------------------------------------------------------------------
rem Build one or all examples for all combinations of implementation
rem and build type
rem -------------------------------------------------------------------------
:L200
if "%2"=="ALL"  goto L204
if "%2"=="all"  goto L204
if exist %2.mmp goto L208
echo  2nd argument missing or contains invalid example name
goto end

:L204
for %%i in (%prjlist%) do call doebld createproject  %%i WINS
for %%i in (%prjlist%) do call doebld createworkdirs %%i WINS
for %%i in (%prjlist%) do call doebld buildproject   %%i WINS DEB
for %%i in (%prjlist%) do call doebld buildproject   %%i WINS REL
for %%i in (%prjlist%) do call doebld createproject  %%i MARM
for %%i in (%prjlist%) do call doebld createworkdirs %%i MARM
for %%i in (%prjlist%) do call doebld buildproject   %%i MARM DEB
for %%i in (%prjlist%) do call doebld buildproject   %%i MARM REL
goto end

:L208
call doebld createproject  %2 WINS
call doebld createworkdirs %2 WINS
call doebld buildproject   %2 WINS DEB
call doebld buildproject   %2 WINS REL
call doebld createproject  %2 MARM
call doebld createworkdirs %2 MARM
call doebld buildproject   %2 MARM DEB
call doebld buildproject   %2 MARM REL
goto end



rem -------------------------------------------------------------------------
rem Create a project file for a single example or project files for
rem all examples
rem -------------------------------------------------------------------------
:L300
if "%3"=="VC4" goto L304
if "%3"=="vc4" goto L304
if "%3"=="VC5" goto L304
if "%3"=="vc5" goto L304
echo 3rd argument missing or contains invalid Ide type; must be one of
echo     VC4
echo     VC5
goto end

:L304
if "%2"=="ALL" goto L308
if "%2"=="all" goto L308
if exist %2.mmp goto L312
echo  2nd argument missing or contains invalid example name
goto end

:L308
for %%i in (%prjlist%) do call doebld createproject  %%i %3
goto end

:L312
call doebld createproject  %2 %3
goto end



rem -------------------------------------------------------------------------
rem Create work directories for all valid implementations and all
rem valid projects
rem -------------------------------------------------------------------------
:L400
for %%i in (%prjlist%) do call doebld createworkdirs %%i WINS
for %%i in (%prjlist%) do call doebld createworkdirs %%i MARM
goto end



rem -------------------------------------------------------------------------
rem Clean all files in all work directories for all valid implementations and
rem all valid projects
rem -------------------------------------------------------------------------
:L500
for %%i in (%prjlist%) do call doebld cleanproject %%i WINS
for %%i in (%prjlist%) do call doebld cleanproject %%i MARM
goto end



rem -------------------------------------------------------------------------
rem Run the DEB or REL emulator
rem -------------------------------------------------------------------------
:L600
if "%2"=="DEB" goto L604
if "%2"=="deb" goto L604
if "%2"=="REL" goto L604
if "%2"=="rel" goto L604
echo 2nd argument missing or contains invalid build;must be one of
echo     DEB
echo     REL
goto end

:L604
if not exist \Epoc32\Release\Wins\%2\epoc.exe goto L608
\Epoc32\Release\Wins\%2\epoc.exe
goto end

:L608
echo.
echo Cannot find \Epoc32\Release\Wins\%2\epoc.exe
echo.
goto end



rem -------------------------------------------------------------------------
rem Build a single example for a specific implementation and build type
rem -------------------------------------------------------------------------
:L700
if exist %1.mmp goto L704
echo  1st argument missing or contains invalid example name
goto end

:L704
if "%2"=="WINS" goto L708
if "%2"=="wins" goto L708
if "%2"=="MARM" goto L708
if "%2"=="marm" goto L708
echo 2nd argument missing or contains invalid implementation; must be one of
echo     WINS
echo     MARM
goto end

:L708
if "%3"=="DEB" goto L712
if "%3"=="deb" goto L712
if "%3"=="REL" goto L712
if "%3"=="rel" goto L712
echo 3rd argument missing or contains invalid build;must be one of
echo     DEB
echo     REL
goto end

:L712
if "%4"==""      goto L716
if "%4"=="clean" goto L720
if "%4"=="CLEAN" goto L720
echo 4th argument is invalid; if specified, it must be one of
echo     CLEAN
goto end

:L716
call doebld createproject  %1 %2
call doebld createworkdirs %1 %2
call doebld buildproject   %1 %2 %3
goto end

:L720
call doebld createproject  %1 %2
call doebld cleanproject   %1 %2
call doebld createworkdirs %1 %2
call doebld buildproject   %1 %2 %3
goto end




rem -------------------------------------------------------------------------
rem Display help
rem -------------------------------------------------------------------------
:Lhelp
echo.
echo  EBLD the SDK Epoc32ex Opl set of examples
echo  -----------------------------------------
echo.
echo  Use:
echo.
echo  EBLD   [ example / ALL ]   implementation build [CLEAN]
echo         build a single example project or ALL projects for 
echo         the specific implementation and build where:
echo           implementation  is either WINS or MARM
echo           build           is either DEB or REL
echo           CLEAN           means optionally do a full re-build
echo.
echo  EBLD BLDALL [ example / ALL ] 
echo         build a single example project or ALL projects for 
echo         all combinations of implementation and build. 
echo.
echo  EBLD MAKMAKE [ example / ALL ] ide
echo         create project files for one or ALL example projects 
echo         for the specified ide where:
echo           ide             is either VC4 or VC5 
echo.
echo  EBLD MAKEWORKDIR
echo         create all needed work directories 
echo.
echo  EBLD CLEAN
echo         delete all files in all work directories 
echo.
echo  EBLD RUN build
echo         run the DEB or REL emulator 
echo.
goto end

:end
set prjlist=


