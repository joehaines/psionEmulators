// mailhelper.CPP
//
// ktkawabe@hi-ho.ne.jp
//

#include "mailhelper.h"
#include <oplapi.h>
#include <oplerr.h>

#if !defined(__TXTETEXT_H__)
#include <TXTETEXT.H>
#endif

////////////////////////////////////////////////////////////////////////////////////////////
// COpxRoot class : derives from COpxBase
//

// The language extension procedures provided by this OPX
//

void CMailerHelper::GetThisThread(){
	RThread thisthread;
	TThreadId aId=thisthread.Id();
	iOplAPI.Push(*((TInt32*)&aId));
}

void CMailerHelper::GetBoundary(){
	// Use this AFTER using MIMEStructure
	iOplAPI.PushL(tempstring);
}

TBool CMailerHelper::InsideBraKet(const TDesC8& src, const TInt pos, const char bra, const char ket){
	if (pos<=0 || pos>=src.Size()-1)
		return EFalse;
	TInt brapos=0, ketpos=0;
	while (brapos!=KErrNotFound && ketpos!=KErrNotFound && brapos<pos && ketpos<pos ){
		if (ketpos) brapos=src.Mid(ketpos).Locate(bra+1);
		else brapos=src.Mid(ketpos).Locate(bra);
		if (brapos!=KErrNotFound)
			ketpos=src.Mid(brapos+1).Locate(ket);
		if (ketpos!=KErrNotFound)
			ketpos+=(brapos+1);
	}
	if (brapos!=KErrNotFound && ketpos!=KErrNotFound && brapos<pos && ketpos>pos ){
		return ETrue;
	}else{
		return EFalse;
	}
}

void CMailerHelper::ExtractForwardPath(){
	HBufC8* strHeap=HBufC8::NewMaxLC(256);
	TPtr8 str=strHeap->Des();
	TPtrC8 str_org=iOplAPI.PopString8();
	str.Copy(str_org);// Make a copy, don't destroy the original.

	TInt pos;
	while ( (pos=str.Locate('<'))!=KErrNotFound){
		str.Delete(0, pos+1);
	}
	while ( (pos=str.Locate('>')) != KErrNotFound){
		str.Delete(pos, str.Size()-pos);
	}
	if (str.Size()!=0)
		iOplAPI.PushL(str);
	else
		iOplAPI.PushL(str_org);
	CleanupStack::PopAndDestroy();
}

void CMailerHelper::SimpleUnscramble(){
	HBufC8* strHeap=HBufC8::NewMaxLC(256);
	TPtr8 str=strHeap->Des();
	str=iOplAPI.PopString8(); // Make a copy, don't destroy the original.
//	TBuf8<256> str=iOplAPI.PopString8();
	TInt length=str.Size();
	for (TInt i=0; i<length; i++)
		str[i]= (TUint8)((str[i]&0x55) + ((~str[i]) & 0xAA));
	TUint8 firstbit=(TUint8)((str[0])&0x80);

	for (i=0; i<length-1; i++){
		str[i]= (TUint8)(str[i]*2);
		str[i] = (TUint8) (str[i]+(str[i+1] & 0x80)/0x80);
	}

	str[length-1]= (TUint8) (str[length-1]*2);
	str[length-1]= (TUint8) (str[length-1]+ firstbit/0x80);

	iOplAPI.PushL(str);
	CleanupStack::PopAndDestroy();
}

void CMailerHelper::SimpleScramble(){
	HBufC8* strHeap=HBufC8::NewMaxLC(256);
	TPtr8 str=strHeap->Des();
	str=iOplAPI.PopString8(); // Make a copy, don't destroy the original.
	TInt length=str.Size();
	TUint8 lastbit=(TUint8)(str[length-1]&1);
	for (TInt i=length-1; i>0; i--){
		str[i] = (TUint8) (str[i]/2);
		str[i] = (TUint8) ( str[i]+ (str[i-1] & 1)*0x80);
		str[i] = (TUint8) ((str[i]&0x55) + ((~str[i]) & 0xAA));
	}
	str[0]=(TUint8) (str[0]/2);
	str[0] = (TUint8) (str[0]+lastbit*0x80);
	str[0]= (TUint8) ((str[0]&0x55) + ((~str[0]) & 0xAA) );

	iOplAPI.PushL(str);

	CleanupStack::PopAndDestroy();
}

void CMailerHelper::TrimString(){
	HBufC8* strHeap=HBufC8::NewMaxLC(256);
	TPtr8 string=strHeap->Des();
	string=iOplAPI.PopString8(); // Make a copy, don't destroy the original.
//	TBuf8<256> string=iOplAPI.PopString8();
	string.Trim();
	iOplAPI.PushL(string);
	CleanupStack::PopAndDestroy();
}
	
void CMailerHelper::BEncodeHeader(){
	// The header should be folded after this.
	// All of the double quotes are recognized.
	// Therefore one should not place any kanji between two double quotes.
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	dest.Zero();
	TInt pos=0;
	while (pos<srcSize){
		TInt len=0;
		while ( pos+len<srcSize &&  !iskanji(src[pos+len]) )
			len++;
		TInt dblQuote=src.Mid(pos).Locate(0x22); // double quote (")
		if (dblQuote!=KErrNotFound && dblQuote<=len){
			if (destMax>=dest.Size()+dblQuote){
				dest.Append(src.Mid(pos,dblQuote+1));
				pos+=(dblQuote+1);
				len-=(dblQuote+1);
				dblQuote=src.Mid(pos).Locate(0x22); // double quote (")
				if (dblQuote!=KErrNotFound){
					if (destMax>=dest.Size()+dblQuote){
						dest.Append(src.Mid(pos,dblQuote+1));
						pos+=(dblQuote+1);
						len-=(dblQuote+1);
					}else{
						iOplAPI.Push( (TInt32) -1);
						return;
					}
				}
				continue;
			}else{
				iOplAPI.Push( (TInt32) -1);
				return;
			}
		}

		if (destMax>=dest.Size()+len){
			dest.Append(src.Mid(pos,len));
		}else{
			iOplAPI.Push( (TInt32) -1);
			return;
		}

		pos+=len;
		if (pos==srcSize){
			iOplAPI.Push( (TInt32) dest.Size());
			return;
		}

		TInt maxlength=26;// RFC2047 says that any encodedword should be
					// shorter than or equal to 75 chars.
					// "=?ISO-2022-JP?B?" + "?=" --> 18,
					// thus JIS string may be up to 57 chars after encoding.
					// As B encoding will encode 3bytes to 4, and
					// since 57=14*4+1, this means that JIS string may be
					// up to 42(=3*14) chars before encoding.
					// "Esc+$B" + "Esc+(B" --> 6,
					// so up to 36(=42-6) bytes can be included.
					// However, it might be that one wants to include
					// the space at the end in the B encoded word.
					// Also it might be that one will have a difficulty in folding
					// the header properly when there's no space at all.
					// So here I limited the maximum length up to 26 bytes (without space)
					// just for safety.
//		TInt linetop=src.Left(pos).LocateReverse((TChar) 0x0a);
//		if (linetop!=KErrNotFound){
//			linetop=pos-linetop-1;
//			if (linetop<=10){ //It is highly probable that this Japanese encoded-word
//				             //is actually at the top of subject: or from: or to:
//				maxlength-=linetop;
//				maxlength=(maxlength/2)*2;
//			}
//		}
		len=0;
		while ( (pos+len+1<srcSize) && ( iskanji(src[pos+len]) ) && (len<=maxlength))
			len+=2;

		TBool adjuscent_encodedwords=EFalse;
		if (len>maxlength){
			len=maxlength;
			adjuscent_encodedwords=ETrue;
		}else if ((len>=4) && (pos>=2) && !iskanji(src[pos-2]) ){// More than 2 kanji, no adjuscent encoded-words
			len=(len/4)*2;
			adjuscent_encodedwords=ETrue;
//		}else if ( pos+len < srcSize && src[pos+len]==0x20){
//			len=maxlength+1;
		}else if (pos+len+1 < srcSize && src[pos+len]==0x20 && iskanji(src[pos+len+1]) ){
				len=len+1;// 2000/07/07
				adjuscent_encodedwords=ETrue;
				// this is to ensure that a space between two
				// kanji chars is correctly handled.
		}


		if ( ((len+6+2)/3)*4+18+dest.Size()>destMax){
			// 18 -->"=?ISO-2022-JP?B?" and "?="
			// ((len+6+2)/3)*4 --> safe length for bdecoding. +6 is for SJIS->JIS.
			iOplAPI.Push( (TInt32) -1);
			return;
		}else{
			dest.Append(_L("=?ISO-2022-JP?B?"));
			TUint8* jis=new TUint8[(len+11)]; // len+6 should be enough, but this is only when we know that SJIS is really SJIS without any ASCII.
			                                  // Since Sjis2JisDes accepts the mixture of ASCII and SJIS, it will require a larger cell for safety.
			TPtr8 jisDes(jis, len+11);        // 11=3+3+5, 3 for the kanji-in and kanji-out, and 5 for the internal safety margin.
			TInt hankaku;
			Sjis2JisDes(src.Mid(pos, len), jisDes, hankaku );
			TUint8* tmp=new TUint8[((jisDes.Size()+2)/3)*4];
			TPtr8 decoded(tmp, ((jisDes.Size()+2)/3)*4);
			//BEncodeDes(src.Mid(pos,len), decoded);
			BEncodeDes(jisDes, decoded);
			dest.Append(decoded);
			delete[] jis;
			delete[] tmp;
			dest.Append(_L("?="));
			pos+=len;
			if (adjuscent_encodedwords){
				if ( dest.Size()>destMax-1){
					iOplAPI.Push( (TInt32) -1);
					return;
				}else{
					dest.Append(_L(" "));
				}
			}
		}
	}

	iOplAPI.Push( (TInt32) dest.Size());
	return;
}

void CMailerHelper::BEncodeBuf(const TBool isOldAPI){
	TInt32 aLineSize;
	TInt16 aLineBreakType;
	if (isOldAPI){
		aLineSize=64;
		aLineBreakType = EMHLineBreakCRLF;
	}else{
		aLineSize = iOplAPI.PopInt32();
		aLineBreakType = iOplAPI.PopInt16();
	}

	TBool allowLineBreak=ETrue;
	TBuf8<2> aLineBreak;
	aLineBreak.Zero();
	switch (aLineBreakType){
	case EMHLineBreakNever:
		allowLineBreak=EFalse;
		break; // Do nothing
	case EMHLineBreakCR:
		aLineBreak.Append((TChar) 0x0d);
		break;
	case EMHLineBreakLF:
		aLineBreak.Append((TChar) 0x0a);
		break;
	case EMHLineBreakCRLF:
		aLineBreak.Append((TChar) 0x0d);
		aLineBreak.Append((TChar) 0x0a);
		break;
	case EMHLineBreakEPOC:
		aLineBreak.Append((TChar) CEditableText::EParagraphDelimiter);
		break;
	default:
		User::Leave(KErrArgument);
	}

	
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();

	if (srcSize <= 0){
		iOplAPI.Push( (TInt32) 0);
		return;
	}

	TInt32 rawEncodeSize=((srcSize+2)/3)*4;

	if ( destMax < rawEncodeSize
		|| ( isOldAPI && ( destMax < rawEncodeSize+ ((rawEncodeSize-1)/aLineSize )*aLineBreak.Size() )  )
		|| ( !isOldAPI && allowLineBreak && ( destMax < rawEncodeSize+ (1+ (rawEncodeSize-1)/aLineSize )*aLineBreak.Size() )  )
		)
		User::Leave(KErrGeneral);

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	TInt32 len=BEncodeDes(src, dest);
	if (allowLineBreak){
		for (TInt i=0; i<(len-1)/aLineSize; i++){
			dest.Insert(aLineSize+i*(aLineSize+aLineBreak.Size()), aLineBreak);
		}
		if (!isOldAPI)
			dest.Append(aLineBreak);
	}

	if (isOldAPI){
		iOplAPI.Push( len);
	}else{
		iOplAPI.Push((TInt32) dest.Size());
	}
	return;
}


TInt CMailerHelper::BEncodeDes(const TDesC8& src, TDes8& dest){
	// B-Encode the buffer src and put the result into dest.
	// Returns the length of the encoded buffer.
	// Leaves if the size of the Maxsize() of dest is smaller than
	// required.

	TInt srcLen=src.Size();
	if ( ((srcLen+2)/3)*4>dest.MaxSize())
		User::Leave(KErrGeneral);
	
	TInt off=0;
	do{
		TInt i=0;
		TBuf8<3> thischar;
		thischar.Zero();
		while (i<3){
			thischar.Append(src[off]);
			i++;
			off++;
			if (off>=srcLen){
				break;
			}
		}
		for (TInt n=0; n<3-i; n++){
			thischar.Append(0);
		}
		TBuf8<4> b_value;
		b_value.Zero();
		b_value.Append(thischar[0]/4);
		b_value.Append((thischar[0] & 3)*0x10+thischar[1]/0x10);
		b_value.Append((thischar[1] & 0x0F)*4+thischar[2]/0x40);
		b_value.Append(thischar[2] & 0x3F);
		
		TBuf8<4> fourbyte_segment;
 		TInt j=0;
		while ( j<i+1){
			fourbyte_segment.Append(bin2b_table[b_value[j]]);
			j++;
		}
		for (TInt k=0; k<4-j; k++){
			fourbyte_segment.Append('=');
		}
		dest.Append(fourbyte_segment);
	}while (off<srcLen);
	return dest.Size();
}

void CMailerHelper::HeaderUnfoldDes(TDesC8& src, TDes8& dest){
	dest.Zero();
	TInt32 pos=0, srcSize=src.Size(), destMax=dest.MaxSize();
	TBuf8<1> appendchar;
	while (pos<srcSize){
		appendchar.Zero();
		TInt32 pos1=src.Right(srcSize-pos).Find(_L("\r\n "));//space
		TInt32 pos2=src.Right(srcSize-pos).Find(_L("\r\n	"));//htab
		if ( (pos2==KErrNotFound) && (pos1==KErrNotFound) ){
			pos1=srcSize;
		}else{
			appendchar=_L(" ");// space
			if (pos2==KErrNotFound){// only crlf+space is there
				pos1+=pos;
			}else{
				if (pos1==KErrNotFound){// only crlf+tab is there
					pos1=pos+pos2;
				}else {// both has been found
					pos1=pos+ ((pos1<pos2)? pos1: pos2);
				}
			}
		}

//		TInt tmp=dest.MaxSize()-dest.Size();
		TInt appendbodylen=pos1-pos;
		if ( (destMax-dest.Size()) < (appendbodylen+appendchar.Size()) ){
			iOplAPI.Push( (TInt32) -1);
			return;
		}else {
			dest.Append(src.Mid(pos, appendbodylen) );
			dest.Append(appendchar);
		}

		pos=pos1+3;
		while ( pos<srcSize && (src[pos]==' ' || src[pos]=='	')) // successive spc or htab
			pos++;
	}
}

void CMailerHelper::HeaderUnfold(){
	// returns -1 if out of memory
	//         -2 if it's impossible to properly unfold
	// otherwise returns the size of the unfolded buffer 
	// Before using this, the header should first by B/Q encoded.
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();
	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	HeaderUnfoldDes(src, dest);
	iOplAPI.Push((TInt32) dest.Size());
}

TInt CMailerHelper::HeaderFoldDes(const TDesC8& src, TDes8& dest){
	// Before this, header first should be bencoded.
	dest.Zero();
	TInt maxlinesize=78; // including crlf
	TInt pos=0, srcsize=src.Size(), destmax=dest.MaxSize(), linesize, linetop=0;

	while (pos<srcsize){
		linesize=src.Mid(pos).Locate(0x0a);
		if (linesize!=KErrNotFound){
			linesize++;
		}else{
			linesize=src.Mid(pos).Size();
		}

		if ( linesize<maxlinesize ){
			if (destmax>=dest.Size()+linesize){
				dest.Append(src.Mid(pos, linesize));
				pos+=linesize;
				linetop=pos;
				continue;
			}else{
				return -1;
			}
		}else{ // Oversize line!!
			TInt breakpos=KErrNotFound;
			if (!src.Mid(linetop, 3).CompareF(_L("TO:")) ||
				!src.Mid(linetop, 3).CompareF(_L("CC:")) ||
				!src.Mid(linetop, 4).CompareF(_L("BCC:")) ||
				!src.Mid(linetop, 4).CompareF(_L("DCC:")) ||
				!src.Mid(linetop, 5).CompareF(_L("FROM:")) ){
				breakpos=src.Mid(pos, maxlinesize).LocateReverse(',');
				if (breakpos==KErrNotFound){
					breakpos=src.Mid(pos, linesize).Locate(',');
				}
				while ( InsideBraKet(src.Mid(pos, linesize), breakpos, '"', '"')){
					TInt off;
					if (breakpos!=KErrNotFound)
						off=src.Mid(pos+breakpos+1, linesize-breakpos-1).Locate(',') ;
					if (off!=KErrNotFound )
						breakpos+=(off+1);
					else{
						breakpos=KErrNotFound;
						break;
					}
				}
			}else if (!src.Mid(linetop, 11).CompareF(_L("REFERENCES:")) ){
				breakpos=src.Mid(pos,linesize).Find(_L("><"));
			}

			
			if (breakpos==KErrNotFound){
				breakpos=src.Mid(pos,linesize).Locate(' ');// spc
				if ( (breakpos!=KErrNotFound) && (linetop==pos) ){ // Here we want to avoid the folding for the space between the field name and value (ex. "from: kawabe" should not be folded as "from:"+crlf+" kawabe").
					TInt anotherbreakpos=src.Mid(pos+breakpos+1, linesize-breakpos-1).Locate(' ');// spc
					if (anotherbreakpos!=KErrNotFound)
						breakpos+=(1+anotherbreakpos);
				}
				if ( breakpos==KErrNotFound ){
					breakpos=src.Mid(pos, linesize).Locate('	');// "tab"
					if ( (breakpos!=KErrNotFound) && (linetop==pos) ){
						TInt anotherbreakpos=src.Mid(pos+breakpos+1, linesize-breakpos-1).Locate('	');// "tab"
						if (anotherbreakpos!=KErrNotFound)
							breakpos+=(1+anotherbreakpos);
					}
				}
			}

			if ( (breakpos==KErrNotFound) ){
				if (destmax>=dest.Size()+linesize){
					dest.Append(src.Mid(pos, linesize));
					pos+=linesize;
					linetop=pos;
					continue;
				}else{
					return -1;
				}
			}else if (src[pos+breakpos]!=',' && src[pos+breakpos] !='>' && destmax>=dest.Size()+breakpos+3){
				dest.Append(src.Mid(pos, breakpos));
				dest.Append(0x0d);
				dest.Append(0x0a);
				dest.Append(src[pos+breakpos]);
			}else if (destmax>=dest.Size()+breakpos+4){
				dest.Append(src.Mid(pos, breakpos));
				dest.Append(src[pos+breakpos]);
				dest.Append(0x0d);
				dest.Append(0x0a);
				dest.Append(' ');
			}else{
				return -1;
			}
			
			pos+=(breakpos+1);
			continue;
		}
	}	
	return dest.Size();
}

void CMailerHelper::HeaderFold(){
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();
	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);

	TInt ret=HeaderFoldDes(src, dest);
	if (ret>=0){
		iOplAPI.Push((TInt32) dest.Size());
	}else{ // No memory!!
		iOplAPI.Push((TInt32) -1);
	}
}

TInt CMailerHelper::HeaderFieldDes(TDesC8& src){
	TInt32 pos= src.Find(_L("\r\n\r\n"));
	if (pos!=KErrNotFound)
		pos+=2;
	return pos;
}

TInt CMailerHelper::HeaderFieldDes(TDesC8& src, TDesC8& separator){
	HBufC8* strHeap=HBufC8::NewMaxLC(separator.Size()+4);
	TPtr8 realseparator=strHeap->Des();
	realseparator=_L("\r\n");
//	TBuf8<255> realseparator=_L("\r\n");
	realseparator.Append(separator);
	realseparator.Append(_L("\r\n"));
	TInt32 pos= src.Find(realseparator);
	if (pos!=KErrNotFound)
		pos+=realseparator.Size();
	CleanupStack::PopAndDestroy();
	return pos;
}

void CMailerHelper::HeaderField(){
	// Find a separator (NULL line preceded by CR/LF),
	// and returns the end offset of a NULL line.
	// (i.e., the NULL line is considered as a part of the header.
	// Returns -1 if such a separator doesn't exist.
	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	TInt32 pos=HeaderFieldDes(src);
	if ( pos==KErrNotFound ){
		iOplAPI.Push((TInt32)-1);
	}else{
		iOplAPI.Push((TInt32) (pos+2));
	}
}

void CMailerHelper::BDecodeHeader(){
	// Decode the header buffer which may contain
	// the B-encoded Elements.
	// ISO-2022-JP is converted to SJIS.
	// The header may be unfolded before using this.

	TInt32 ignoreDblQuote=iOplAPI.PopInt32();
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();
	TInt32 srcSize=iOplAPI.PopInt32();

	if (destMax<srcSize)
		User::Leave(KErrGeneral);
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);
	dest.Zero();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);

	TInt top=0;
	
	while (top < srcSize){
		TInt lineEnd = src.Right(srcSize-top).Find(_L("\r\n"));
		if (lineEnd == KErrNotFound){
			lineEnd=srcSize-top;
		}else{
			lineEnd+=2;
		}

		TPtrC8 line=src.Mid(top, lineEnd);

		TPtrC aCharset[3]={
			_L("=?ISO-2022-JP?"),
			_L("=?SHIFT_JIS?"),
			_L("=?US-ASCII?")
		};
		TInt i, begin = KErrNotFound, charset, prefix_len;
		for (i=0; i<3; i++){
			TInt charset_begin = line.FindF(aCharset[i]);
			if (charset_begin!=KErrNotFound){ // thus charset_begin is non-negative.
				if (begin==KErrNotFound || begin>charset_begin){
					begin=charset_begin;
					charset=i;
					prefix_len=aCharset[i].Size()+2;
				}
			}
		}


		TInt end;
	
		if (begin == KErrNotFound){
			end=line.Size();
			dest.Append(line);
		}else if (line.Size()<begin+prefix_len
				||
				((line.Mid(begin+prefix_len-2, 2).CompareF(_L("B?")) !=0)
				  && (line.Mid(begin+prefix_len-2, 2).CompareF(_L("Q?")) !=0) )
				){
					// This is checking if, for example, this is not
					// "=?ISO-2022-JP?A=hogehoge" or something, which is
					// not an encoded word.
					end=begin+prefix_len-2;
					dest.Append(line.Left(begin+prefix_len-2));
		}else{
			end = line.Right(line.Size()-begin-prefix_len).FindF(_L("?="));
			if (end == KErrNotFound){
				end=line.Size();
				dest.Append(line);
			}else{
				end += (begin+prefix_len);
				if (!ignoreDblQuote){
					TInt dblQuoteBgn=line.Match(_L("*\"*\"*"));
					TInt dblQuoteEnd;
					if (dblQuoteBgn!=KErrNotFound){
						dblQuoteEnd=line.Right(line.Size()-dblQuoteBgn-1).Locate('"');
						if ((dblQuoteEnd!=KErrNotFound) && (dblQuoteBgn<begin)){
							begin=end=dblQuoteBgn+dblQuoteEnd+2;
						}
					}
				}


				dest.Append(line.Left(begin));
				if (begin!=end){// BEncoded stream!!
					HBufC8* bdecodedHeap=HBufC8::NewMaxLC(1024);
					TPtr8 bdecoded=bdecodedHeap->Des();
					HBufC8* sjdecodedHeap=HBufC8::NewMaxLC(2048); //2048 is just for safety.
					TPtr8 sjdecoded=sjdecodedHeap->Des();

					if (line.Mid(begin+prefix_len-2, 2).CompareF(_L("B?"))==0){
						BDecodeDes(line.Mid(begin+prefix_len,end-begin-prefix_len),bdecoded);
					}else if (line.Mid(begin+prefix_len-2, 2).CompareF(_L("Q?"))==0){
						QDecodeDes(line.Mid(begin+prefix_len,end-begin-prefix_len),bdecoded);
					}

					// prefix_len is the length of "=?ENCODINGNAME?B?" (i.e. 16 for ISO-2022-JP and 14 for SHIFT_JIS).

					if (charset == EISO2022JP){
						Jis2SjisDes(bdecoded, sjdecoded);
					}else{
						sjdecoded.Copy(bdecoded);
					}
					dest.Append(sjdecoded);
					end+=2;

					CleanupStack::PopAndDestroy(); // for sjdecodedHeap
					CleanupStack::PopAndDestroy(); // for bdecodedHeap

					// here we have to test if there's adjuscent encodedword.
					TInt nextbegin=KErrNotFound;
					for (i=0; i<3; i++){
						TInt next_charset_begin=src.Mid(top+end).FindF(aCharset[i]);
						if (next_charset_begin!=KErrNotFound){ // thus next_charset_begin is non-negative.
							if (nextbegin==KErrNotFound || nextbegin>next_charset_begin){
								nextbegin=next_charset_begin;
								prefix_len=aCharset[i].Size()+2;
							}
						}
					}

					TInt nextend;
					if (nextbegin!=KErrNotFound){
						if (src.Mid(top+end).Size()>=nextbegin+prefix_len
							&&
							((src.Mid(top+end+nextbegin+prefix_len-2, 2).CompareF(_L("B?")) ==0)
								|| (src.Mid(top+end+nextbegin+prefix_len-2, 2).CompareF(_L("Q?")) ==0) )
						){
							nextend=src.Mid(top+end+nextbegin+prefix_len).FindF(_L("?="));
							if (nextend != KErrNotFound){ // adjuscent encodedtext
								TBool onlywhitespaces=ETrue;
								for (TInt m=0; m<nextbegin; m++){
									if ((src.Mid(top+end) [m] != 0x20) && //space
										(src.Mid(top+end) [m] != 0x09) && //htab
										(src.Mid(top+end) [m] != 0x0d) &&
										(src.Mid(top+end) [m] != 0x0a)    ){
										onlywhitespaces=EFalse;
										break;
									}
								}
								if (onlywhitespaces){
									end+=nextbegin;
								}
							}
						}
					}
				}
			}
		}
		top+=end;

	
	
	}
	iOplAPI.Push((TInt32)dest.Size());
	return;
}

TInt CMailerHelper::Is7bit(const TDesC8& src){
	// Returns the position of the 8bit char.
	//         -1 if all of the chars are 7bit.
	TInt srcsize=src.Size();
	for (TInt i=0; i<srcsize; i++){
		if ( src[i] & (unsigned char) 128)
			return i;
	}
	return -1;
}

void CMailerHelper::Is7bit(){
	// Returns the position of the 8bit char.
	//         -1 if all of the chars are 7bit.

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	iOplAPI.Push((TInt32) Is7bit(src));
	return;
}

TInt CMailerHelper::IsStrictlyASCII(const TDesC8& src){
	// Returns the position of the non-ASCII char.
	//         -1 if all of the chars are either
	//          htab, cr, lf, or 0x20<=char<=0x7e
	TInt srcsize=src.Size();
	for (TInt i=0; i<srcsize; i++){
		if ( (src[i] & (unsigned char) 128) || ((src[i] & (unsigned char) 0xF0) <= 0x10 && src[i] != 0x0d && src[i] != 0x0a && src[i] != 9) )
			return i;
	}
	return -1;
}

void CMailerHelper::IsStrictlyASCII(){
	// Returns the position of the non-ASCII char.
	//         -1 if all of the chars are either
	//          htab, cr, lf, or 0x20<=char<=0x7e

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	iOplAPI.Push((TInt32) Is7bit(src));
	return;
}

TBool CMailerHelper::iskanji(const char ch){
	register unsigned char c = (unsigned char)ch;
	return (((0x80 <= c) && (c <= 0x9f)) || ((0xe0 <= c) && (c<=0xfc)));
}

void CMailerHelper::BDecodeBuf(){
	// Decodes the bencoded buf.
	// Any cr and lf at the head or tail are stripped off.
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();

	if (srcSize <=0){
		iOplAPI.Push( (TInt32) 0);
		return;
	}
	if (destMax < (srcSize*3)/4)
		User::Leave(KErrGeneral);

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	TInt begin=0, end=srcSize-1;
	while ((src[begin]==0x0d || src[begin]==0x0a) && begin<srcSize)
		begin++;
	while ((src[end]==0x0d || src[end]==0x0a) && end >=0)
		end--;

	TInt32 len=BDecodeDes(src.Mid(begin, end-begin+1), dest);
	iOplAPI.Push( len);
	return;
}

TInt CMailerHelper::BDecodeDes(const TDesC8& src, TDes8& dest){
	TInt srclen=src.Size();
	dest.Zero();
	
//	if (srclen & 3) // error if src length <> n*4
//		User::Leave(KErrGeneral);
// The above mentioned check has been commented out because
// this function was extended to handle multi-line.

	if ( (srclen*3)/4 > dest.MaxSize() )
		User::Leave(KErrGeneral);

	TInt i=0, flag=0, curChar, beforeChar;
	while (i < srclen){
		curChar = src[i];
		if (b2bin_table[curChar] < -1)
			User::Leave(KErrGeneral);
		else if (b2bin_table[curChar] == 0xFF)
			break;
		else if (curChar==0x0d || curChar==0x0a){
			i++;
			continue;
		}

		if (!flag){			
			// NOP
		}
		else if (flag == 1){
			dest.Append(b2bin_table[beforeChar]*4 +b2bin_table[curChar]/16);
		}
		else if (flag == 2){
			dest.Append(b2bin_table[beforeChar]*16+b2bin_table[curChar]/4);
		}
		else if (flag == 3){
			dest.Append(b2bin_table[beforeChar]*64+b2bin_table[curChar]);
		}
		else{
			User::Leave(KErrGeneral);
		}

		beforeChar = curChar;
		i++;
		flag++;
		if (flag == 4)
			flag = 0;
	}
	if ( (flag!=0) && (b2bin_table[curChar] != 0xFF) ) // This can only happen when the data stream
													   // is not really 4*n.
		iOplAPI.EikonEnv().InfoMsg(_L("Incorrectly BEncoded Sequence"));
	return dest.Size();
}

void CMailerHelper::QDecodeBuf(){
	// Decodes the qencoded buf.
	// Any cr and lf at the head or tail are stripped off.
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();

	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();

	if (srcSize <= 0){
		iOplAPI.Push( (TInt32) 0);
		return;
	}
	if (destMax < srcSize)
		User::Leave(KErrGeneral);

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);
	TUint8* destBuffer=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuffer, destMax);

	TInt begin=0, end=srcSize-1;
	while ((src[begin]==0x0d || src[begin]==0x0a) && begin<srcSize)
		begin++;
	while ((src[end]==0x0d || src[end]==0x0a) && end >=0)
		end--;

	TInt32 len=QDecodeDes(src.Mid(begin, end-begin+1), dest);
	iOplAPI.Push( len);
	return;
}

TInt CMailerHelper::QDecodeDes(const TDesC8& src, TDes8& dest){
	TInt srclen=src.Size();
	dest.Zero();
	if ( srclen > dest.MaxSize() )
		User::Leave(KErrGeneral);

	dest.Copy(src);
	TInt pos=0, nextpos;
	while ( (nextpos= dest.Right(dest.Size()-pos).Find(_L("\r\n")) )!=KErrNotFound){
		// To delete the "padded" WHSP chars at the end of lines.
		pos+=nextpos;
		for (; pos>0 && (dest[pos-1]==32 || dest[pos-1]==9); ){
			pos--;
			dest.Delete(pos, 1);
		}
		pos+=2;
	}

	pos=0;
	while ( (nextpos= dest.Right(dest.Size()-pos).Match(_L("*=??*")) )!=KErrNotFound){
		pos+=nextpos;
		TInt up=dest[pos+1], down=dest[pos+2];

		if (up==0x0d && down==0x0a){
			//Soft line break.
			dest.Delete(pos, 3);
			continue;
		}else if (  (  (up>='0' && up<='9')
					|| (up>='A' && up<='F')
					|| (up>='a' && up<='f')
					)
					&& 
					(  (down>='0' && down<='9')
					|| (down>='A' && down<='F')
					|| (down>='a' && down<='f')
					)
					){
			//8bit representation!
			TInt value=0;
			if (up<='9'){
				value+= (up-'0')*16;
			}else if (up>='a'){
				value+= (up-'a'+10)*16;
			}else{
				value+= (up-'A'+10)*16;
			}
			if (down<='9'){
				value+= (down-'0');
			}else if (down>='a'){
				value+= (down-'a'+10);
			}else{
				value+= (down-'A'+10);
			}
			dest.Delete(pos, 2);
			dest[pos]= value;
			pos++;
		}else{
			pos+=3;
		}
	}

	return dest.Size();
}

void CMailerHelper::Sjis2JisBuf(){
	// Return value is the length of the JIS data on normal return.

	// If jis buffer is not large enough, this function tries to convert
	// as many sjis chars as possible so long as the size of jis buffer allows,
	// and returns the length of the converted JIS, BUT WITH A MINUS SIGN.
	// In this case, SJIS size parameter (which is passed BYREF) is set 
	// to the size of the REMAINING (unconverted) SJIS data on return.
	
	// An integer parameter, hankakuflag, is used to indicate that any hankaku-kana char
	// or any invalid char (which this function cannot handle) has been detected.
	// If hankaku-kana is detected, the 1st bit of hankakuflag is set.
	// However, even in this case, the hankaku kanas are converted
	// into zenkaku automatically.
	// If some invalid char which this function cannot handle appears, this function
	// immediately returns with the second bit of hankakuflag set.

	TAny* ptrHankakuFlag=iOplAPI.PopPtrInt32();
	TInt32 jisMax=iOplAPI.PopInt32();
    TInt jisoffset=iOplAPI.PopInt32();
	TUint8* jisbuffer=iOplAPI.OffsetToAddrL(jisoffset, jisMax);
	TPtr8 jis(jisbuffer, jisMax);

	TAny* ptrSjisSize=iOplAPI.PopPtrInt32();
	TInt32 sjisSize=iOplAPI.GetLong(ptrSjisSize);
    TInt sjisoffset=iOplAPI.PopInt32();
	TUint8* sjbuffer=iOplAPI.OffsetToAddrL(sjisoffset, sjisSize);
	TPtrC8 sjis(sjbuffer, sjisSize);

	if (sjisSize <= 0){
		iOplAPI.Push( (TInt32) 0);
		return;
	}

	TInt hankakuflag;
	TInt ret=Sjis2JisDes(sjis, jis, hankakuflag);
	
	iOplAPI.PutLong(ptrHankakuFlag, hankakuflag);
	
	if (ret!=sjis.Size()){
		iOplAPI.PutLong(ptrSjisSize, sjis.Size()-ret);
		iOplAPI.Push((TInt32) -jis.Size());
	}
	else{
		iOplAPI.Push((TInt32) jis.Size());
	}
	return;
}

TInt CMailerHelper::Sjis2JisDes(const TDesC8& sjis, TDes8& jis, TInt& hankakuflag){
	// Return value is the converted length of the SJIS data.
	// If jis buffer is not large enough, this function tries to convert
	// as many sjis chars as possible so long as the size of jis buffer allows.
	// Even in this case returned value is the length of the converted SJIS.
	
	// An integer parameter, hankakuflag, is used to indicate that any hankaku-kana char
	// or any invalid char (which this function cannot handle) has been detected.
	// If hankaku-kana is detected, the 1st bit of hankakuflag is set.
	// However, even in this case, the hankaku kanas are converted
	// into zenkaku automatically.
	// If some invalid char which this function cannot handle appears, this function
	// immediately returns with the second bit of hankakuflag set.

	TUint hankakutable[255];
	TUint8 sjup, sjlow, upperoff1, upperoff2, loweroff;

	TBool hankakukana=EFalse, kanjiin=EFalse, invalid_char=EFalse;
	TInt32 sjoff=0;

	do{
		sjup=sjis[sjoff];
		
		if ((sjup>=0x81 && sjup<=0x9F) || (sjup>=0xE0 && sjup<=0xFC)){// kanji
			sjlow=sjis[sjoff+1];
			sjoff+=2;
			if (!kanjiin){
				jis.Append(0x1B);
				jis.Append('$');
				jis.Append('B');
				kanjiin=ETrue;
			}
			if (sjup <= 0x9F){
				upperoff1= 0x70;
			}else{
				upperoff1= 0xB0;
			}
			if (sjlow >= 0x9F){
				upperoff2=0;
				loweroff=0x7E;
			}
			else if (sjlow <= 0x7E){
				upperoff2=1;
				loweroff=0x1F;
			}
			else{
				upperoff2=1;
				loweroff=0x20;
			}
			jis.Append( (sjup-upperoff1)*2-upperoff2);
			jis.Append( sjlow-loweroff);
		}
		else if ((sjup>=0x20 && sjup<=0x7E) || sjup==0x0D 
			|| sjup==0x0A || sjup==0x09){ // ANK

			sjoff++;
			if (kanjiin){
				kanjiin=EFalse;
				jis.Append(0x1B);
				jis.Append('(');
				jis.Append('B');
			}
			if (sjup== 0x0D){
				continue;
			}
			else if (sjup== 0x0A){
				jis.Append( 0x0D);
				jis.Append( 0x0A);
			}
			else{
				jis.Append( sjup);
			}
		}
		else if (sjup>=0xA1 && sjup<=0xDF){// raw hankaku kana
			sjoff++;
			if (!hankakukana){
				hankakukana=ETrue;
				//Initialize the Hankaku-Kana mapping table
				hankakutable[0xA1]=0x2321;
				hankakutable[0xA2]=0x5621;
				hankakutable[0xA3]=0x5721;
				hankakutable[0xA4]=0x2221;
				hankakutable[0xA6]=0x7225;
				TInt i=0xA7;
				while (i<=0xAB){
					hankakutable[i]=0x2125+(i-0xA7)*2*256;
					i++;
				}
				while (i<=0xAE){
					hankakutable[i]=0x6325+(i-0xAC)*2*256;
					i++;
				}
				hankakutable[0xAF]=0x4325;
				hankakutable[0xB0]=0x3C21;
				i=0xB1;
				while (i<=0xB5){
					hankakutable[i]=0x2225+(i-0xB1)*2*256;
					i++;
				}
				while (i<=0xC1){
					hankakutable[i]=0x2B25+(i-0xB6)*2*256;
					i++;
				}
				while (i<=0xC5){
					hankakutable[i]=0x4425+(i-0xC2)*2*256;
					i++;
				}
				while (i<=0xCA){
					hankakutable[i]=0x4B25+(i-0xC6)*256;
					i++;
				}
				while (i<=0xCF){
					hankakutable[i]=0x5225+(i-0xCB)*3*256;
					i++;
				}
				hankakutable[0xD0]=0x5F25;
				i=0xD1;
				while (i<=0xD3){
					hankakutable[i]=0x6025+(i-0xD1)*256;
					i++;
				}
				while (i<=0xD6){
					hankakutable[i]=0x6425+(i-0xD4)*2*256;
					i++;
				}
				while (i<=0xDB){
					hankakutable[i]=0x6925+(i-0xD7)*256;
					i++;
				}
				hankakutable[0xDC]=0x6F25;
				hankakutable[0xDD]=0x7325;
				hankakutable[0xDE]=0x6D21;
				hankakutable[0xDF]=0x6B21;
			}
			if (!kanjiin){
				jis.Append(0x1B);
				jis.Append('$');
				jis.Append('B');
				kanjiin=ETrue;
			}
			//iOplAPI.PutLong((TAny*)(jisbuffer+jislen),hankakutable[sjup]);
			jis.Append((char) (hankakutable[sjup]/256));
			jis.Append((char) (hankakutable[sjup] & 255));

		}
		else{
   			invalid_char=ETrue;
			break;
		}
	}while (sjoff!=sjis.Size() && jis.Size()<=jis.MaxSize()-8);
		// Maximum of 5bytes (kanji-in+1kanji-char or 1kanji-char+kanji-out)
		//  may be written in jisbuffer, between do and while.
		// It is necessary to write kanji-out at the end
		//  when quitting while kanjiin, therefore
		//  jisMax has to be larger than or equal to
		//  jislen+8 when the above loop continues.
	
	if (kanjiin){
		jis.Append( 0x1B);
		jis.Append('(');
		jis.Append('B');
	}

	hankakuflag= invalid_char?2:0 + hankakukana?1:0;
	return sjoff;
}

void CMailerHelper::Jis2SjisBuf(){
	TInt32 aDestMax=iOplAPI.PopInt32();
    TInt32 aDestOffset=iOplAPI.PopInt32();
	TInt32 aSrcSize=iOplAPI.PopInt32();
    TInt32 aSrcOffset=iOplAPI.PopInt32();

	if (aSrcSize <= 0){
		iOplAPI.Push( (TInt32) 0);
		return;
	}
	if (aDestMax<=0){
		iOplAPI.Push( (TInt32) -1); // Error code
		return;
	}

	TUint8* aSrcHeap=iOplAPI.OffsetToAddrL(aSrcOffset, aSrcSize);
	TPtrC8 src(aSrcHeap, aSrcSize);

	TUint8* aDestHeap=iOplAPI.OffsetToAddrL(aDestOffset, aDestMax);
	TPtr8 dest(aDestHeap, aDestMax);

	TInt32 len=Jis2SjisDes(src, dest);
	iOplAPI.Push( len);
	return;
}

TInt CMailerHelper::Jis2SjisDes(const TDesC8& src, TDes8& dest){
	TInt p, x, c1, c2, rowOffset, cellOffset;
		
	TBool flagKanji = EFalse, flagKana=EFalse;

	dest.Zero();
	p = 0;

	while (p < src.Size()){
		if ( dest.Size() >= dest.MaxLength()-2){//  REM About to overflow.
			return -1;
		}
		x = src[p];
		if (x == 27){				//ESC 
			if (p>src.Size()-3)
				break;

			x = src[p + 1];
			if (x == '$'){
				x = src[ p + 2 ];
				if (x== 'B' ||  x == '@'){ 
					//	ESC-$-B is so-called KANJI-IN
					flagKanji = ETrue;
					flagKana=EFalse;
					p += 3;
					continue;
				}
			}
			else if (x == '('){
				x = src[p + 2];
				if (x == 'B' || x == 'J'){ // ESC-(-B is so-called KANJI-OUT
					flagKanji = EFalse;
					flagKana=EFalse;
					p += 3;
					continue;
				}
				else if ( x=='I'){ //	 ESC-(-I is outrageous kana-in used by
									//	 Netscape and Outlook Express.
					flagKana = ETrue;
					p += 3;
					continue;
				}
			}
			x = 27; // stay ESC
		}
		else if (x==0x0D){
			p++;
			continue;
		}
		else if ( x== 0x0A){// Control-F is End-Of-line
			flagKanji = EFalse;
			flagKana=EFalse;
			dest.Append( (TUint8) 0x0D);
			dest.Append( (TUint8) 0x0A);
			p++;
			continue;
		}
		else if ( x==0x0E){//  Outrageous Kana-in used by MS internet mail
			flagKana=ETrue;
			p++;
			continue;
		}
		else if (x==0x0F){ // outrageous Kana-out used by MS internet mail
			flagKana=EFalse;
			p++;
			continue;
		}

		if ( flagKana){// REM Outrageous kana character
			p++;
			if (x >=0x21 && x<=0x5F){ // ignore if it doesn't belong to 7bits kana.
				dest.Append((TUint8) (x+0x80));
			}
		}
		else if (!flagKanji){ // ANK
			dest.Append((TUint8) x); 
			p++;
		}
		else {// KANJI character
			if (p>=src.Size()-1)
				break;
			c1 = src[p];
			c2 = src[p + 1];
			p+=2;
			
			if (c1>=0x21 && c1<=0x74 && c2>=0x21 && c2<=0x7E){
			// ignore if it doesn't belong to kanji characters.
				if (c1 < 95){
					rowOffset = 112;
				}
				else{
					rowOffset = 176;
				}
				
				if (c1 / 2 * 2 == c1){
					cellOffset = 126;
				}
				else{
					if (c2 > 95)
						cellOffset = 32;
					else
						cellOffset = 31;
				}
				dest.Append( (TUint8) ((c1+1)/2 + rowOffset) );
				dest.Append( (TUint8) (c2 + cellOffset) );
			}
		}
	}
	return dest.Size();
}

TInt32 CMailerHelper::TruncateDes(const TDesC8& target, const TInt maxlength)
{	//Tries to truncate the SJIS test, 'target, in such a way that the length 
	// is as large as or smaller than 'maxlength. 
	// This is needed because SJIS cannot simply truncated without
	// considering the byte boundary.
	// Returns the actual length of the truncated string.
	
	TInt tmplen;
	if (maxlength<=target.Size()){
		tmplen=maxlength;
	}else{
		tmplen=target.Size();
	}

	TInt pos=0;
	while (pos<tmplen){
		if (iskanji(target[pos]) )
			pos+=2;
		else
			pos++;
	}

	if (pos>tmplen)
		tmplen--;
	return tmplen;
}

void CMailerHelper::TruncateString()
{
	TInt32 maxlength=iOplAPI.PopInt32();
	TPtrC8 string=iOplAPI.PopString8();
	iOplAPI.Push(TruncateDes(string, maxlength) );
	return;
}
	
void CMailerHelper::FieldNum(const TDesC8& separator)
{
	// Returns  0 if the buffer doesn't have the specified field.
	TPtrC8 keyword=iOplAPI.PopString8();
	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);

	TInt32 num=FieldNum(src, keyword, separator);
	iOplAPI.Push(num);
	return;
}

TInt32 CMailerHelper::FieldNum(TDesC8& src, const TDesC8& keyword, const TDesC8& separator){

//	TInt headeroff=HeaderFieldDes(src);
//	if (headeroff==KErrNotFound){
//		return 0;
//	}

	TInt srcsize=src.Size();
	TUint8* headerUfBuf= new TUint8[srcsize];
	if (!headerUfBuf){
		User::Leave(KErrNoMemory);
	}
	TPtr8 headerUf(headerUfBuf, srcsize);
	TPtrC8 header(src.Ptr(), srcsize);
	HeaderUnfoldDes(header, headerUf);

//	TUint8* keywordbuffer=new TUint8[256];
//	TPtr8 key(keywordbuffer, 256);
//	key=_L("\r\n");
//	key+=keyword;
//	TInt KeywordPosition=headerUf.FindF(key);
//	delete [] keywordbuffer;
	TInt KeywordPosition;
	do {
		KeywordPosition=headerUf.FindF(keyword);
		if (KeywordPosition!=KErrNotFound){
			if ( (KeywordPosition!=0 ) && (headerUf[KeywordPosition-1]!=0x0a) ){
				headerUf.Delete(0,KeywordPosition+keyword.Size());
			}else{
				break;
			}
		}
	}while (KeywordPosition!=KErrNotFound);

	if (KeywordPosition==KErrNotFound){
		delete[] headerUfBuf;
		return 0;
	}

	headerUf.Delete(0,KeywordPosition+keyword.Size());
	TInt lineEnd=headerUf.Find(_L("\r\n"));
	if (lineEnd==KErrNotFound)
		lineEnd=headerUf.Size();
	headerUf.Delete(lineEnd,headerUf.Size()-lineEnd);

//	TInt num=1, off=0, found;
	TInt num=1, found;
	while (  (found=headerUf.FindF(separator))  !=  KErrNotFound  ){
		TInt dblQuoteBgn=headerUf.Match(_L("*\"*\"*"));
		TInt dblQuoteEnd;
		if (dblQuoteBgn!=KErrNotFound){
			dblQuoteEnd=headerUf.Right(headerUf.Size()-dblQuoteBgn-1).Locate('"');
			if ( (found>dblQuoteBgn) && (found<dblQuoteBgn+dblQuoteEnd+1) ){
				headerUf.Delete(0, dblQuoteBgn+dblQuoteEnd+2);
				continue;
			}
		}

		num++;
		headerUf.Delete(0,found+1);
	}
	delete [] headerUfBuf;
	return num;

}


void CMailerHelper::FieldElement(const TDesC8& separator){
//	Extract the n-th element of the "keyowrd" field in the header.
//  Header buffer should have a valid header structure.
//	The keyword must not be at the very first line, unfortunately, for the moment.

	TInt32 num=iOplAPI.PopInt32();
	TPtrC8 keyword=iOplAPI.PopString8();
	TInt32 srcSize=iOplAPI.PopInt32();
    TInt srcoffset=iOplAPI.PopInt32();

	if (num<0 || (srcSize < keyword.Size()+2) ){
		// Either "invalid index" or "apparently no chance".
		iOplAPI.PushL(_L(""));
		return;
	}

	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);

	TUint8* headerUfBuf= new TUint8[srcSize];
	if (!headerUfBuf){
		User::Leave(KErrNoMemory);
	}
	TPtr8 headerUf(headerUfBuf, srcSize);
	HeaderUnfoldDes(src, headerUf);

	
	HBufC8* keyHeap=HBufC8::NewMaxLC(256);
	TPtr8 key=keyHeap->Des();
	key=_L("\r\n");
//	TBufC8<256> key=_L("\r\n");
//	key.Des().Append(keyword);
	key.Append(keyword);
	TInt keywordPosition=headerUf.FindF(key);
	if (keywordPosition==KErrNotFound){
		if (headerUf.Left(keyword.Size()).CompareF(keyword) ){
			iOplAPI.PushL(_L(""));
			delete [] headerUfBuf;
			CleanupStack::PopAndDestroy();; // for keyHeap
			return;
		}else{
			keywordPosition=keyword.Size();
		}
	}else{
		keywordPosition+=key.Size();
	}
	CleanupStack::PopAndDestroy(); // for keyHeap

	TInt lineSize=headerUf.Right(headerUf.Size()-keywordPosition).Find(_L("\r\n"));
	if (lineSize==KErrNotFound)
		lineSize=headerUf.Size()-keywordPosition;

	TUint8* headerBuf= new TUint8[lineSize];
	if (!headerBuf){
		delete [] headerUfBuf;
		User::Leave(KErrNoMemory);
	}
	TPtr8 header(headerBuf, lineSize);

	header.Copy(headerUf.Mid(keywordPosition, lineSize));
	header.TrimAll(); //2000/05/11
	TInt off=0, found;
	for (TInt i=0; i<num; i++){
		while ( (found=header.Mid(off).FindF(separator)) != KErrNotFound ){

			TInt dblQuoteBgn=header.Mid(off).Match(_L("*\"*\"*"));
			TInt dblQuoteEnd;
			if (dblQuoteBgn!=KErrNotFound){
				dblQuoteEnd=header.Mid(off).Mid(dblQuoteBgn+1).Locate('"');
				if ( (found>dblQuoteBgn) && (found<dblQuoteBgn+dblQuoteEnd+1) ){
					off+=dblQuoteBgn+dblQuoteEnd+2;
					continue;
				}
			}
			break;
		}

		if (found!=KErrNotFound){
			off+=(found+1);
		}else{
			delete [] headerUfBuf;
			delete [] headerBuf;
			iOplAPI.PushL(_L(""));
			return;
		}
	}

	header.Delete(0,off);
	off=0;
	while ( (found=header.Mid(off).FindF(separator)) != KErrNotFound ){
		TInt dblQuoteBgn=header.Mid(off).Match(_L("*\"*\"*"));
		TInt dblQuoteEnd;
		if (dblQuoteBgn!=KErrNotFound){
			dblQuoteEnd=header.Mid(off).Mid(dblQuoteBgn+1).Locate('"');
			if ( (found>dblQuoteBgn) && (found<dblQuoteBgn+dblQuoteEnd+1) ){
				off+=dblQuoteBgn+dblQuoteEnd+2;
				continue;
			}
		}
		break;
	}

	if (found==KErrNotFound)
		found=header.Size();
	header.Delete(found, header.Size()-found);
	header.Trim();
	TInt truncatedlength=TruncateDes(header, 255);
	if (truncatedlength!=header.Size())
		header.Delete(truncatedlength, header.Size()-truncatedlength);
	iOplAPI.PushL(header);
	delete [] headerUfBuf;
	delete [] headerBuf;
	return;
}

void CMailerHelper::MIMEStructure(){
	// Returns  0 if the buffer is not Multipart, but still has Content-Type: field.
	//         -1 if the buffer doesn't have a header.
	//         -2 if "mime-version" and "Content-Type:" are not found.
	//         -3 if the structure buffer is not large enough.
	//         -4 if multipart structure is corrupt (e.g. no closing delimiter etc.).
	// Otherwise, returns the number of the multipart.
	// Note that a multipart message with only one part returns 1, if such thing exists.
	// In the destBuffer, offset(s) and size of each individual part is stored
	// as a pare of 4-byte integers.
	// However, if it's not multipart, destBuffer is undefined.
	TInt32 destMax=iOplAPI.PopInt32();
    TInt destoffset=iOplAPI.PopInt32();
	TUint8* destBuf=iOplAPI.OffsetToAddrL(destoffset, destMax);
	TPtr8 dest(destBuf, destMax);

	TInt32 srcSize=iOplAPI.PopInt32();
	TInt srcoffset=iOplAPI.PopInt32();
	TUint8* srcBuffer=iOplAPI.OffsetToAddrL(srcoffset, srcSize);
	TPtrC8 src(srcBuffer, srcSize);

	tempstring=_L("");
	TInt headeroff=HeaderFieldDes(src);
	if (headeroff==KErrNotFound){
		iOplAPI.Push((TInt32) headeroff);
		return;
	}

	//First unfold the header.
	TUint8* headerUfBuf= new TUint8[headeroff];
	if (!headerUfBuf){
		User::Leave(KErrNoMemory);
	}
	TPtr8 headerUf(headerUfBuf, headeroff);
	TPtrC8 header(src.Left(headeroff));
	HeaderUnfoldDes(header, headerUf);

	//See if "\r\nMime-version:" is there (or "Mime-version:" at the very top.)
	if (headerUf.FindF(_L("\r\nMIME-VERSION:"))==KErrNotFound
		&& (headerUf.Size()<13 || headerUf.Left(13)==_L("MIME-VERSION:") )
		){
		delete [] headerUfBuf;
		iOplAPI.Push((TInt32) -2);
		return;
	}

	//Find "\r\nContent-Type:" (or "Content-Type:" at the very top.)
	TInt CTPosition=headerUf.FindF(_L("\r\nCONTENT-TYPE:"));
	if (CTPosition==KErrNotFound){
		if ( headerUf.Size()<13 || headerUf.Left(13).CompareF(_L("CONTENT-TYPE:"))!=0){
			delete [] headerUfBuf;
			iOplAPI.Push((TInt32) -2);
			return;
		}else{
			CTPosition=0;
		}
	}else{
		CTPosition+=2;
	}

	//Extract "Content-Type" line in CT.
	TInt lineEnd=headerUf.Right(headerUf.Size()-CTPosition-13).Find(_L("\r\n"));
	if (lineEnd==KErrNotFound)
		lineEnd=headerUf.Size()-CTPosition-13;
	HBufC* CTBuf= headerUf.Mid(CTPosition+13, lineEnd).AllocLC();
	delete [] headerUfBuf;

	//CT is used for "Content-type", and boundaryBuf is for "Boundary".
	//Since at the moment both are in CT, they have to be separated.
	TPtr CT=CTBuf->Des();
	CT.Trim();
	HBufC* boundaryBuf=CT.AllocLC(); //Copy CT to boundaryBuf.
	TInt separator=CT.Locate(';');
	if (separator==KErrNotFound)
		separator=CT.Size();
	CT.Delete(separator, CT.Size()-separator); //delete "Boundary" part
	CT.Trim();
	CT.UpperCase();
	_LIT(KMultipartIndicator, "MULTIPART");
	if ( (CT.Size()<9) || (CT.Left(9) != KMultipartIndicator) ){
		iOplAPI.Push((TInt32) 0);
		return;
	}

	TPtr boundary=boundaryBuf->Des();
	boundary.Delete(0,separator+1);
	boundary.Trim();
	TInt isBoundary=boundary.FindF(_L("BOUNDARY=")) ;
	if ( isBoundary==KErrNotFound ){
		iOplAPI.Push((TInt32) 1);
		return;
	}else{
		boundary.Delete(0, isBoundary+9);
	}
	boundary.Trim();
	if (boundary[0]=='"' && boundary[boundary.Size()-1]=='"'){
		boundary=boundary.Mid(1,boundary.Size()-2);
	}
	tempstring=boundary;
	boundary.Insert(0,_L("\r\n--"));
	boundary.Append(_L("\r\n"));
	TInt boundarysize=boundary.Size();
	// Here, the "boundary" sequence has been extracted.
	// Note that this definition of boundary requires that
	// any part is more than zero byte.

	TInt pos=0, num=0;
	while (1){
		TInt nextpos=src.Right(src.Size()-pos).Find(boundary);
		if (nextpos==KErrNotFound)
			break;
		pos+=nextpos+boundarysize;
		if (destMax<4*(num+1)){
			iOplAPI.Push((TInt32) -3);
			return;
		}

		iOplAPI.PutLong(destBuf+4*num, pos);
		num++;
	}

	if (num<=0) {
		iOplAPI.Push((TInt32) -4);
		return;
	}

	if (destMax<8*num)
		User::Leave(KErrGeneral);
	boundary.Insert(boundary.Size()-2,_L("--"));
	boundary.Delete(boundary.Size()-2,2);
	TInt nextpos=src.Right(src.Size()-pos).Find(boundary);
	if (nextpos==KErrNotFound){
		iOplAPI.Push((TInt32) -4);
		return;
	}
	pos+=(nextpos+boundarysize);
	iOplAPI.PutLong(destBuf+4*num, pos);

	for (TInt i=num; i>0; i--){
		TInt end=iOplAPI.GetLong(destBuf+4*i);
		TInt start=iOplAPI.GetLong(destBuf+4*(i-1));
		iOplAPI.PutLong(destBuf+8*(i-1), start);
		iOplAPI.PutLong(destBuf+8*i-4, end-start-boundarysize+2);
	}


	iOplAPI.Push((TInt32) num);
}



// The members of COpxRoot which are not language extension procedures
//
CMailerHelper::CMailerHelper(OplAPI& aOplAPI) : COpxBase(aOplAPI)
    {
     __DECLARE_NAME(_S("CMailerHelper"));
    }


CMailerHelper* CMailerHelper::NewLC(OplAPI& aOplAPI)
    {
    CMailerHelper* This=new(ELeave) CMailerHelper(aOplAPI);
    CleanupStack::PushL(This);
    This->ConstructL();
    return This;
    }


void CMailerHelper::ConstructL(){
	// Do whatever is required to constuct any component members
	// 

	tempstring=_L("");
	bin2b_table=_L("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");

	TPtr8 ptr = b2bin_table.Des();
	ptr.Zero();
//	for (TInt i=0; i<256; i++)
//		ptr.Append(0xF0); 
	ptr.Fill(0xF0, ptr.MaxSize()); // 0xF0 represents the illegal chars.
	for (TUint8 i='A'; i<='Z'; i++)
		ptr[i]=(TUint8) (i-'A');		//'A' to 'Z' --> 0 to 25
	for (i='a'; i<='z'; i++)
		ptr[i]=(TUint8) (i-'a'+26);	//'a' to 'z' --> 26 to 51
	for (i='0'; i<='9'; i++)
		ptr[i]=(TUint8) (i-'0'+52);	//'0' to '9' --> 52 to 61
	ptr['+']=62;			//'+' --> 62
	ptr['/']=63;			//'/' --> 63
	ptr['=']=0xFF;			//'=' --> pad char

} 

CMailerHelper::~CMailerHelper(){
	Dll::FreeTls();		// Required so that Tls is set to zero on unloading the OPX in UNLOADM
}

// COpxBase implementation
//
void CMailerHelper::RunL(TInt aProcNum){
// Run a language extension procedure
	switch (aProcNum){
		case EBufJ2SJ:
			Jis2SjisBuf();
			break;
		case EBufSJ2J:
			Sjis2JisBuf();
			break;
		case EBufBDecode:
			BDecodeBuf();
			break;
		case EBufBEncode:
			{
			BEncodeBuf(ETrue);
			break;
			}
		case EHeaderField:
			HeaderField();
			break;
		case EHeaderUnfold:
			HeaderUnfold();
			break;
		case EHeaderFold:
			HeaderFold();
			break;
		case EHeaderBDecode:
			BDecodeHeader();
			break;
		case EMIMEStructure:
			MIMEStructure();
			break;
		case EFieldNum:
			FieldNum(_L(","));
			break;
		case EFieldElement:
			FieldElement(_L(","));
			break;
		case EFieldNumWithSeparator:
			{
			TPtrC separator=iOplAPI.PopString8();
			FieldNum(separator);
			}
			break;
		case EFieldElementWithSeparator:
			{
			TPtrC separator=iOplAPI.PopString8();
			FieldElement(separator);
			}
			break;
		case ETruncateString:
			TruncateString();
			break;
		case EHeaderBEncode:
			BEncodeHeader();
			break;
		case EIs7bit:
			Is7bit();
			break;
		case ETrim:
			TrimString();
			break;
		case ESimpleScramble:
			SimpleScramble();
			break;
		case ESimpleUnscramble:
			SimpleUnscramble();
			break;
		case EGetBoundary:
			GetBoundary();
			break;
		case EBufQDecode:
			QDecodeBuf();
			break;
		case EThisThread:
			GetThisThread();
			break;
		case EIsStrictlyASCII:
			IsStrictlyASCII();
			break;
		case EBufBEncodeFlexibly:
			BEncodeBuf(EFalse);
			break;
		case EOPXVersion:
			iOplAPI.Push((TInt32) KOpxVersion);
			break;
		case EExtractForwardPath:
			ExtractForwardPath();
			break;

		default:
			User::Leave(KOplErrOpxProcNotFound);
	}
}

TBool CMailerHelper::CheckVersion(TInt aVersion)
// To check whether the opx is a compatible version
// *** Change as required ***
	{
	if ((aVersion & 0x0f00)>(KOpxVersion & 0xf00))	// major version must be <= OPX's version
		return EFalse; // bad version
	else
		return ETrue; // ok
	}


EXPORT_C COpxBase* NewOpxL(OplAPI& aOplAPI)
// Creates a COpxBase instance as required by the OPL runtime
// This object is to be stored in the OPX's TLS as shown below
	{
	CMailerHelper* tls=((CMailerHelper*)Dll::Tls());
	if (tls==NULL)		// tls is NULL on loading an OPX DLL (also after unloading it)
		{
        tls=CMailerHelper::NewLC(aOplAPI);
	    User::LeaveIfError(Dll::SetTls(tls));
		CleanupStack::Pop();	// tls
        }
    return (COpxBase *)tls;
	}

EXPORT_C TUint Version()
// ER5 and later: export the OPX version number.
	{
	return KOpxVersion;
	}

GLDEF_C TInt E32Dll(TDllReason /*aReason*/)
//
// DLL entry point
//
	{
	return(KErrNone);
	}

