// jpprintopx.h by ktkawabe@hi-ho.ne.jp
//
//
#if !defined(__MAILHELPEROPX_H__)
#define __MAILHELPEROPX_H__

#if !defined(__E32BASE_H__)
#include <e32base.h>
#endif
#if !defined(__OPLAPI_H__)
#include <oplapi.h>
#endif
#if !defined(__OPX_H__)
#include <opx.h>
#endif
#include <coeutils.h>
#include <coeccntx.h>
#include <coecntrl.h>

#include <apgicnfl.h>

#include <eikenv.h>
#include <eikconso.h>

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// The OPX's UID as used in the DECLARE OPX statement for your OPX
// NB. This UID must be reserved by contacting Psion
//
const TInt KUidOpxTemplate=0x10001607;


// The OPX's version number as used in the DECLARE OPX statement for your OPX
const TInt KOpxVersion=0x103;


// The root class of the OPX - add any members and/or component classes
// that your particular OPX requires to this class
//
// An instance of this class is created immediately after the OPX is loaded (using LOADM)
// and the object pointer must be stored in the Tls (Thread local static).
// See the 1st EXPORT function NewOpxL(), which does this for you.
// The Tls contains the single global (32-bit) value available to any EPOC32 DLL.
// No other non-const static data may be used.
//
class CMailerHelper : public COpxBase 
    {
public:
    static CMailerHelper* NewLC(OplAPI& aOplAPI);
	virtual void RunL(TInt aProcNum);
	virtual TInt CheckVersion(TInt aVersion);
	// Add any other members specific to your OPX
	// ...    

	
private:
	// the language extension procedures
	enum TExtensions
		{
		EBufJ2SJ=1,
		EBufSJ2J,
		EBufBDecode,
		EBufBEncode,
		EHeaderField,
		EHeaderUnfold,
		EHeaderFold,
		EHeaderBDecode,
		EMIMEStructure,
		EFieldNum,
		EFieldElement,
		EFieldNumWithSeparator,
		EFieldElementWithSeparator,
		ETruncateString,
		EHeaderBEncode,
		EIs7bit,
		ETrim,
		ESimpleScramble,
		ESimpleUnscramble,
		EGetBoundary,
		EBufQDecode,
		EThisThread,
		EIsStrictlyASCII,
		EBufBEncodeFlexibly,
		EOPXVersion,
		EExtractForwardPath
		};
	enum TLineBreakType{
		EMHLineBreakNever=0,
		EMHLineBreakCR,
		EMHLineBreakLF,
		EMHLineBreakCRLF,
		EMHLineBreakEPOC
	};
	void GetThisThread();
	void GetBoundary();
	TInt32 TruncateDes(const TDesC8& target, const TInt length);
	void TruncateString();
	void FieldElement(const TDesC8& separator);
	void FieldNum(const TDesC8& separator);
	TInt32 FieldNum(TDesC8& src, const TDesC8& keyword, const TDesC8& separator);
    void MIMEStructure();
	void Sjis2JisBuf();
	TInt Sjis2JisDes(const TDesC8& sjis, TDes8& jis, TInt& hankakuflag);
	TInt Jis2SjisDes(const TDesC8& src, TDes8& dest);
	void Jis2SjisBuf();
	void BDecodeBuf();
	TInt BDecodeDes(const TDesC8& src, TDes8& dest);
	void BEncodeBuf(const TBool isOldAPI);
	TInt BEncodeDes(const TDesC8& src, TDes8& dest);
	void QDecodeBuf();
	TInt QDecodeDes(const TDesC8& src, TDes8& dest);
	TInt HeaderFieldDes(TDesC8& src);
	TInt HeaderFieldDes(TDesC8& src, TDesC8& separator);
	void HeaderField();
	void HeaderUnfold();
	void HeaderUnfoldDes(TDesC8& src, TDes8& dest);
	void HeaderFold();
	TInt HeaderFoldDes(const TDesC8& src, TDes8& dest);
	void BDecodeHeader();
	void BEncodeHeader();
	TInt Is7bit(const TDesC8& src);
	void Is7bit();
	TInt IsStrictlyASCII(const TDesC8& src);
	void IsStrictlyASCII();
	void TrimString();
	TBool iskanji(const char ch);
	void SimpleScramble();
	void SimpleUnscramble();
	TBool InsideBraKet(const TDesC8& src, const TInt pos, const char bra, const char ket);
	void ExtractForwardPath();
	enum TMIMECharset
		{
		EISO2022JP=0,
		ESHIFT_JIS,
		EASCII
		};
private: 
	void ConstructL();
    CMailerHelper(OplAPI& aOplAPI);
    ~CMailerHelper() ;

private: // member data
	TBufC<64> bin2b_table;
	TBufC<256> b2bin_table;
	TBufC<255> tempstring;
};

// sundry derived classes

// OpxRoot() accesses the Tls which contains the COpxRoot*, created and stored there by NewOpxL()
//
// OpxRoot() is only required if you need to access your COpxRoot object
// in a deeply nested function which hasn't been passed this pointer directly
// Note that accessing the Tls in this way is relatively slow (about 4 microsecs) so
// it is often more efficient to pass the COpxRoot* down the chain of functions.
inline CMailerHelper* OpxRoot() { return((CMailerHelper *)Dll::Tls()); }

    
#endif __MAILHELPEROPX_H__
