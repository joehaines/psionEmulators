rem agn2addr: look up an address from an agenda entry
rem (or any current selection)
rem 
rem The first word of the selected text/entry
rem is stripped off, unless there is only one
rem word (i.e. no spaces). Thus this can be
rem used on "Call Bert" to look up Bert's 
rem address.
PROC macro:
	local srchky$(255), lspace%
	UseApp:( "Active" )
	GiPrint:( "Starting agn2addr macro..." )
	rem Copy Selection
	Psion:( %c )
	rem make it the Bring Server
	rem Is there a less visible way to do this?
	if CurrPid%: <> SrvPid%:
		ToBack:
		ToFront:
	endif
	srchky$ = GetText$:
	lspace% = loc( srchky$, " " )
	if lspace% <> 0 and lspace% <> len( srchky$ )
		srchky$ = mid$( srchky$, lspace%+1, len( srchky$ ) )
	endif
	if srchky$ = ""
		GiPrint:( "Empty current selection!")
		return
	endif
	GiPrint:( "Looking up "+mid$(srchky$,1,10)+"..." )
	rem Look up search key in address book
	if Fil2Pid%:( "addrs.dbf" ) <> 0
		UseFile:( "addrs.dbf" )
	else
		RunAppC:( "Data", "addrs.dbf" )
	endif
	if Fil2Pid%:( "addrs.dbf" ) = 0
		rem summat wrong, forget it
		GiPrint:( "Can't find address book!" )
		return
	endif
	Psion:( %F ) rem force Find mode
	SendText:( srchky$ )
	Enter:
	ToFront: rem show the result
	rem removed following - it irritated me!
	rem GiPrint:( "agn2addr macro completed" )
ENDP

