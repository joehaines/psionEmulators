rem set Agenda how I like it
rem 11 Mar 96

PROC macro:
	if Fil2Pid%:( "agenda.agn" ) = 0
  	RunApp:( "agenda", "agenda.agn" )
	endif
  UseApp:( "agenda" )
  GiPrint:( "Setting agenda prefs..." )
  rem Now, calculate the year few, and set
  rem a few preferences
  Psion:(%Y) rem Year view
  Psion:(%q) rem preferences
  Enter: rem year view prefs
  rem Get to top of month choice list
  rem (regardless of current month)
  Tab:
  SendKey:( up%, 0, 11 )
  rem why don't either of the following work?
  rem SendKey:(psion%+up%, 0, 1)
  rem Psion:(up%) : Psion:(up%)
  rem Now, know exactly how many keys to
  rem press to select a particular month,
  rem e.g. J for June, JJ for July.
  rem Do (eg):
  rem SendKey:(%S, 0, 1) rem select "September"
  rem do nothing = Leave at January for now.
  SendKey:( %J, 0, 2 ) rem July
  Enter: 
  Down: rem down arrow
  Key:(%e) rem select "show end time"
  Enter: rem accept change
  Psion:(%D) rem go to Day view
	GiPrint:("AgnPrefs finished")
ENDP
