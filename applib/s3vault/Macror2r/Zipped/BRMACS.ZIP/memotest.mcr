rem testing some ideas about memos
rem open a memo in agenda
rem switch to "most recent" word instance
rem and put something in it.
rem Finally got it to work!

PROC macro:
	local wrd%, wrd$(15), agn$(15)
	UseApp:( "Active" )
rem	agn$ = Pid2Fil$:( ActPid%: )
rem	GiPrint:( "Running memotest macro" )
	rem ought to check that it's an agenda!
	rem TO DO
	Psion:( %+ )
	wrd% = Fil2Pid%:( "AGENDA.AGN" )
	rem wrd% = Tsk2Pid%:( "Word" )
rem	wrd$ = Pid2Fil$:( wrd% )
rem	if wrd$ <> agn$
rem		GiPrint:( "Failed to find memo" )
		rem wrd% = Tsk2Pid%:( "Word" )
rem	endif
	UsePid:( wrd% )
rem	ToFront:
	SendText:( "Is this the memo I wanted?" )
	Enter:
rem	GiPrint:( "memotest finished" )
ENDP
