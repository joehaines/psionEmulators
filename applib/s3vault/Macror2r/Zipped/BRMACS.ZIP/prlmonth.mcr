rem 	MACRO PrLMonth: 
rem 	make a backup of last month's agenda
rem 	both as an agn file and as text

PROC macro:

local mnum%, mname$(3), yr%, fname$(32)

rem 	Use agenda.agn
UseFile:( "agenda.agn" )
ToFront:
GiPrint:( "Backing up last month..." )

rem 	Build filename from last month and year.
mnum% = month : yr% = year
if mnum% = 1
	mnum% = 12
	yr% = yr% - 1
else
	mnum% = mnum% - 1
endif
rem use last two digits of year
if yr% < 2000
	yr% = yr% - 1900
else
	yr% = yr% - 2000
endif
rem fname$ is just the root of the filename
rem (no path or extension)
fname$ = month$(mnum%)+gen$(yr%,2)

rem 	Check if lastmnth.agn exists
rem 	(Tidy asks for confirmation if it does, so avoid that)

if Exist( "LOC::M:\AGN\"+fname$+".agn" )
	dInit:( "Remove existing backup "+fname$+".agn?" )
	dText:( "", fname$+".agn exists", 2 )
	dText:( "", "Remove it, or abort backup?", 2 )
rem 	NOTE: I can't get dButtons to work for esc% and enter%,
rem 	even though there's an example in macro.dbf
rem 	dButtons:( "Abort,esc%,Remove,enter%" )
rem 	So I'm forced to use ordinary keys instead.
	dButtons:( "Abort,%a,Remove,%r" )
	if Dialog: = 1
		GiPrint:( "Backup aborted" )
		Return
	else
		Delete "LOC::M:\AGN\"+fname$+".agn"
	endif
endif

GiPrint:( "Changing printer to General..." )
rem 	Print setup:
Psion:( %y )
rem 		(might change paper size & margins here?)
rem 		change printer to General
Up: : Up: : Tab:
Key:( %g ) : Enter:
GiPrint:( "Setting print file to "+fname$+".txt..." )
rem			set print file to m:\agn\lastmnth.txt
Down: : Tab: : Key:( %f )
Down: : Down: : Down: : Tab: : Tab: : Down:
SendText:( "LOC::M:\AGN\" )
Enter: : Enter:
SendText:( fname$+".txt" )
Enter: : Enter:

GiPrint:( "Printing last month..." )
rem 	Print: 
Psion:( %p )
rem 		Last Month; 
Key:( %L ) : Key:( %L ) : Key:( %L )
rem 		?No annivs?
Up: : Tab: : Down: : Down: : Key:( %n )
Enter: : Enter:

GiPrint:( "Copying last month to "+fname$+".agn..." )
rem 	Tidy: 
Psion:( %t )
rem 		copy to file, m:\agn\lastmnth.agn
Key:( %c ) : Down:
SendText:( fname$+".agn" )
rem 		Last month
Down: : Down: : Key:( %L ) : Key:( %L )
Enter:

GiPrint:( "Changing printer to Postscript..." )
rem 	Reset printer to something proportional
rem 	Print Setup:
Psion:( %y )
rem 		set printer to Postscript
Up: : Up: : Tab:
Key:( %p ) : Enter: : Enter:

GiPrint:( "Last month backed up" )
ENDP

