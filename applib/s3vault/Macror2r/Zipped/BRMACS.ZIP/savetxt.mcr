rem savetxt macro
rem useful only in Word: save current
rem file blah.wrd as blah.txt
rem Brian Ritchie Fri 03 May 1996 02:17:40

PROC macro:

	local fname$(12) rem 8.3 filename structure
	local dotpos%
	UsePid:( ActPid%: )

	rem - check I'm using Word
	if Pid2App$:( ActPid%: ) <> "Word"
		GiPrint:( "savetxt macro: Not in Word" )
		return
	endif

	GiPrint:( "savetxt macro starting..." )

	rem - get the filename
	fname$ = Pid2Fil$:( ActPid%: )

	rem - convert .wrd end to .txt
	dotpos% = loc( fname$, "." )
	if dotpos% = 0
		GiPrint:( "savetxt: no dot in filename!" )
		return
	endif
	fname$ = left$( fname$, dotpos% ) + "TXT"

	rem I don't check for file existence here
	rem I don't know how to get the current directory
	rem and besides, the "confirm overwrite" dialog
	rem is the last thing that might happen here
	rem so no subsequent SendXs are confused by it

	rem - Fill in Save As dialog
	Psion:( %a ) rem Save As
	SendText:( fname$ ) rem with TXT extension
	Down: : Down: : Down: rem get to last field
	SendText:( "T" ) rem select Text
	Enter: rem complete dialog
	rem For debugging:
	rem Esc: rem abandon dialog
	rem GiPrint:( "savetxt test done for "+fname$ )

ENDP
