PROC macro:
rem
rem -- Toggle sound on/off
rem -- on turning sound off, add a reminder alarm
rem -- alarm code based on OPL manual page 136
rem -- seems to give silent alarms even when sound is on.
rem
local h%, a&(2),a$(64), d&, t&, a%, r%, s%, adv%
UseApp:("Active")
if var%(3)
	var%(3) = 0
	GiPrint:( "Setting sound OFF - reminder in 1 hour" )
	adv% = 60 rem number of mins ahead
	r% = IOOpen( h%, "ALM:", 0 )
	if r% < 0 : raise r% : endif
	d& = days( day, month, year ) rem today
	t& = dateToSecs( 1970, 1, 1, hour, minute, 0 )
	a&(1) = 86400*(d&-25567) + t& + (60*adv%)
	a&(2) = a&(1)
	a$ = "Sound back on?"+chr$(0)
	IOC( h%, 2, s%, a&(),#UADD(addr(a$),1) )
	IOCLOSE( h% )
else
	var%(3) = 1
	GiPrint:( "Setting sound ON - cancel reminder?" )
endif
SetSound:( var%(3),-1,-1,-1 )
ENDP

