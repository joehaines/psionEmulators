#include <plib.h>

/* Workaround for wonky console display under emulator */
P_RECT _DefScreenRect = {0,0,40,9};

int main(int argc, char *argv[])
{
  int i;

  for (i=0; i<argc; i++)
    p_printf("argv[%d]==|%s|",i,argv[i]);

  p_getch();
  return 0;
}

