/*
 * 04.dec.96	5.0	rudi
 *		bla bla
 * 04.jan.97	5.0a	jw
 *		Minimal gnu autoconf scripts added.
 * 06.jan.97	5.1a	jw
 *		Oops, moved to 5.1
 * 20.mai.97	5.2	rudi
 * 07.nov.97	5.3	Richard Panton / rudi
 *		S5 port
 * 07.mar.99	5.4	Next+FreeBSD+glibc
 * 10.mar.99	5.4a	
 */

#define VERSION "5.4a"
