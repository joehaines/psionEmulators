tsc /m nfsc
