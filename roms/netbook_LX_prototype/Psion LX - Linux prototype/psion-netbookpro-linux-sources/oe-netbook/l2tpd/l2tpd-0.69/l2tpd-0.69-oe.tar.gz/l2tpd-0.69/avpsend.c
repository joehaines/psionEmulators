/*
 * Layer Two Tunnelling Protocol Daemon
 * Copyright (C) 1998 Adtran, Inc.
 * Copyright (C) 2002 Jeff McAdams
 *
 * Mark Spencer
 *
 * This software is distributed under the terms
 * of the GPL, which you should have received
 * along with this source.
 *
 * Attribute Value Pair creating routines
 */

#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include "l2tp.h"

/* 
 * These routines should add avp's to a buffer
 * to be sent
 */


/* FIXME:  If SANITY is on, we should check for buffer overruns */

/* FIXME: Can't this be condensed alot? */

int add_message_type_avp (struct buffer *buf, _u16 type)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0);
    htons_to_chars (&raw[6], type);
    buf->len += 8;
    return 0;
}

int add_protocol_avp (struct buffer *buf)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);        /* Length and M bit */
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x2);       /* Value of our AVP */
    htons_to_chars (&raw[6], OUR_L2TP_VERSION);
    buf->len += 8;
    return 0;
}

int add_frame_caps_avp (struct buffer *buf, _u16 caps)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x3);
    htons_to_chars (&raw[6], 0);
    htons_to_chars (&raw[8], caps);
    buf->len += 10;
    return 0;
}

int add_bearer_caps_avp (struct buffer *buf, _u16 caps)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x4);
    htons_to_chars (&raw[6], 0);
    htons_to_chars (&raw[8], caps);
    buf->len += 10;
    return 0;
}

/* FIXME: I need to send tie breaker AVP's */

int add_firmware_avp (struct buffer *buf)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x6);
    htons_to_chars (&raw[6], FIRMWARE_REV);
    buf->len += 8;
    return 0;
}

/*
int add_hostname_avp(struct buffer *buf) {
	_u8 *raw = (_u8 *)(buf->start + buf->len);
	htons_to_chars (&raw[0], (0x6 + strlen(hostname)) | MBIT);
	htons_to_chars (&raw[2], VENDOR_ID);
	htons_to_chars (&raw[4], 0x7);
	strcpy((char *)(&raw[6]), hostname);
	buf->len += 6 + strlen(hostname);
	return 0;
}
*/

int add_hostname_avp (struct buffer *buf)
{
    char names[6] = "eriwan";
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xC | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x7);
    strcpy ((char *) (&raw[6]), names);
    buf->len += 12;
    return 0;
}

int add_vendor_avp (struct buffer *buf)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x6 + strlen (VENDOR_NAME));
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x8);
    strcpy ((char *) (&raw[6]), VENDOR_NAME);
    buf->len += 6 + strlen (VENDOR_NAME);
    return 0;
}

int add_tunnelid_avp (struct buffer *buf, _u16 tid)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x9);
    htons_to_chars (&raw[6], tid);
    buf->len += 8;
    return 0;
}

int add_avp_rws (struct buffer *buf, _u16 rws)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0xA);
    htons_to_chars (&raw[6], rws);
    buf->len += 8;
    return 0;
}

int add_challenge_avp (struct buffer *buf, char *c, int len)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], (0x6 + len) | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0xB);
    bcopy (c, (char *) (&raw[6]), len);
    buf->len += 6 + len;
    return 0;
}

int add_chalresp_avp (struct buffer *buf, char *c, int len)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], (0x6 + len) | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0xD);
    bcopy (c, (char *) (&raw[6]), len);
    buf->len += 6 + len;
    return 0;
}

int add_randvect_avp (struct buffer *buf, char *c, int len)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], (0x6 + len) | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x24);
    bcopy (c, (char *) (&raw[6]), len);
    buf->len += 6 + len;
    return 0;
}

int add_result_code_avp (struct buffer *buf, _u16 result, _u16 error,
                         char *msg, int len)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], (0xA + len) | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x1);
    htons_to_chars (&raw[6], result);
    htons_to_chars (&raw[8], error);
    bcopy (msg, (char *) &raw[10], len);
    buf->len += (10 + len);
    return 0;
}

#ifdef TEST_HIDDEN
int add_callid_avp (struct buffer *buf, _u16 callid, struct tunnel *t)
{
#else
int add_callid_avp (struct buffer *buf, _u16 callid)
{
#endif
    _u8 *raw = (_u8 *) (buf->start + buf->len);
#ifdef TEST_HIDDEN
    if (t->hbit)
        raw+=2;
#endif
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0xE);
    htons_to_chars (&raw[6], callid);
    buf->len += 8;
#ifdef TEST_HIDDEN
    if (t->hbit)
        encrypt_avp (buf, 8, t);
#endif
    return 0;
}

int add_serno_avp (struct buffer *buf, unsigned int serno)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0xF);
    htons_to_chars (&raw[6], (serno >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], serno & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_bearer_avp (struct buffer *buf, int bearer)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x12);
    htons_to_chars (&raw[6], (bearer >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], bearer & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_frame_avp (struct buffer *buf, int frame)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x13);
    htons_to_chars (&raw[6], (frame >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], frame & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_txspeed_avp (struct buffer *buf, int speed)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x18);
    htons_to_chars (&raw[6], (speed >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], speed & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_rxspeed_avp (struct buffer *buf, int speed)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x26);
    htons_to_chars (&raw[6], (speed >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], speed & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_physchan_avp (struct buffer *buf, unsigned int physchan)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x19);
    htons_to_chars (&raw[6], (physchan >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], physchan & 0xFFFF);
    buf->len += 10;
    return 0;
}

int add_ppd_avp (struct buffer *buf, _u16 ppd)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x8 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x14);
    htons_to_chars (&raw[6], ppd);
    buf->len += 8;
    return 0;
}

int add_seqreqd_avp (struct buffer *buf)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0x6 | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x27);
    buf->len += 6;
    return 0;
}

/* jz: options dor the outgoing call */

/* jz: Minimum BPS - 16 */
int add_minbps_avp (struct buffer *buf, int speed)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x10);
    htons_to_chars (&raw[6], (speed >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], speed & 0xFFFF);
    buf->len += 10;
    return 0;
}

/* jz: Maximum BPS - 17 */
int add_maxbps_avp (struct buffer *buf, int speed)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], 0xA | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x11);
    htons_to_chars (&raw[6], (speed >> 16) & 0xFFFF);
    htons_to_chars (&raw[8], speed & 0xFFFF);
    buf->len += 10;
    return 0;
}

/* jz: Dialed Number 21 */
int add_number_avp (struct buffer *buf, char *no)
{
    _u8 *raw = (_u8 *) (buf->start + buf->len);
    htons_to_chars (&raw[0], (0x6 + strlen (no)) | MBIT);
    htons_to_chars (&raw[2], VENDOR_ID);
    htons_to_chars (&raw[4], 0x15);
    strncpy ((char *) (&(raw[6])), no, strlen (no));
    buf->len += 6 + strlen (no);
    return 0;
}
