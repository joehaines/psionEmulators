/*
 * Layer 2 Tunnelling Protocol Daemon
 * Copyright (C) 2002 Jeff McAdams
 *
 * This software is distributed under the terms of the GPL, which you
 * should have receivede along with this source.
 *
 * Defines common to several different files
 */

#ifndef _COMMON_H_
typedef unsigned char _u8;
typedef unsigned short _u16;
typedef unsigned long long _u64;
int rand_source;
extern void htons_to_chars (_u8 *dst, _u16 val);
extern _u16 ntohs_from_chars (_u8 *src);
#define _COMMON_H_
#endif
