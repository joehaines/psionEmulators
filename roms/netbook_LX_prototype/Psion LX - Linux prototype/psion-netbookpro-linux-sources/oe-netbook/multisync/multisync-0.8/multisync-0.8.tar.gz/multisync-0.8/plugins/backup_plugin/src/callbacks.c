#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"

gboolean
backup_on_backup_window_delete_event   (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  backup_window_closed();
  return FALSE;
}


void
backup_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_ok();
}


void
backup_cancelbutton_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_cancel();
}


void
backup_restorebutton_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_restore_selected();
}


void
backup_restoreallbutton_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_restore_all();
}


void
backup_deletebutton_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_delete_ask();
}


void
backup_rebackupbutton_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
  backup_rebackup_all();
}

