#include <gnome.h>


gboolean
backup_on_backup_window_delete_event   (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
backup_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
backup_cancelbutton_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
backup_restorebutton_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
backup_backuplist_select_row           (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
backup_backuplist_unselect_row         (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
backup_restoreallbutton_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
backup_deletebutton_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
backup_rebackupbutton_clicked          (GtkButton       *button,
                                        gpointer         user_data);
