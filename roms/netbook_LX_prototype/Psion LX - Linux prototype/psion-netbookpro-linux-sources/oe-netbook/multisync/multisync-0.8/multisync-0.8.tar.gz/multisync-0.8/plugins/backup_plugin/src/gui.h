#ifndef GUI_H
#define GUI_H

#include <multisync.h>

GtkWidget* open_option_window(sync_pair *pair, connection_type type);
void backup_window_closed(void);
void backup_cancel(void);
void backup_ok(void);
void backup_get_selected_iter (GtkTreeModel *model, GtkTreePath *path,
			       GtkTreeIter *iter, gpointer data);
GList *backup_get_selected(void);
void backup_restore_selected(void);
void backup_restore_all(void);
void backup_show_list(void);
void backup_show_msg(char *msg);
gboolean backup_show_question(char *msg);
void backup_delete_ask(void); 
void backup_rebackup_all(void);
char *backup_conv_charset(char *value, char *from, char* to);
gboolean backup_find_model_iter(GtkTreeModel *model, GtkTreeIter *iter,
				int pos, gpointer data);


#endif
