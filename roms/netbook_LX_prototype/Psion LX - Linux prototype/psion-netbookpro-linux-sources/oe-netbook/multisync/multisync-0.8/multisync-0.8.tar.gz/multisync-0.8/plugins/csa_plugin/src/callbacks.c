#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"


void
csa_cancelbutton_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	csaoptions_cancel();
}


void
csa_okbutton_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	csaoptions_ok();
}

