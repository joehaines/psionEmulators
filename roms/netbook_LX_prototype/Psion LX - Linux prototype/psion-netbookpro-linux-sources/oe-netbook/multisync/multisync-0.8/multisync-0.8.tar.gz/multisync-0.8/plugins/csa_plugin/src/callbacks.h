#include <gnome.h>


void
csa_cancelbutton_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
csa_okbutton_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
