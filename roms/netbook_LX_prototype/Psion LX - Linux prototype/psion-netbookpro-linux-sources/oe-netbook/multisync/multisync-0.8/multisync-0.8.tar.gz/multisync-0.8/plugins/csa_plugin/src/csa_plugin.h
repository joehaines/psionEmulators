#ifndef CSA_PLUGIN_H
#define CSA_PLUGIN_H

#include <multisync.h>
#include <csa/csa.h>
#include <search.h>
#include <libnvpair.h>

typedef struct {
  client_connection commondata;
  sync_pair *sync_pair;
  connection_type conntype;
  char * csaserver;
  CSA_session_handle session;
  nvlist_t * csa_entries;
} csa_connection;

typedef struct {
  int count;
  CSA_attribute * attrs;
  CSA_attribute_value * values;
} csa_attribute_bundle;

void csa_load_config(csa_connection *conn);
void csa_save_config(csa_connection *conn);
void csa_load_state(csa_connection *conn, nvlist_t ** list);
void csa_save_state(csa_connection *conn);
void csa_get_entries(csa_connection *, GList **);
void csa_add_to_list(csa_connection * conn, CSA_entry_handle handle);
void csa_remove_from_list(csa_connection * conn, char * uid);
void csa_get_uid_from_handle(csa_connection * conn, CSA_entry_handle handle, char *uid);
int csa_entry_exists(nvlist_t * list, nvpair_t * pair);
int csa_entry_matches(nvlist_t * list, nvpair_t * pair);
int csa_get_entry_handle(csa_connection *conn, char * uid, CSA_entry_handle **);
GString * csa_get_entry_vcal(csa_connection *conn, nvpair_t * entry);
void add_attribute_to_vcal(GString **vcal, CSA_attribute attribute, int *);
void csa_add_vcal_entry(csa_connection *conn, char * vcal, char * uid);
void csa_update_vcal_entry(csa_connection *conn, char * vcal, char * uid);
void csa_vcal_to_attributes(char * vcal, csa_attribute_bundle * bundle, int newentry);
void csa_read_rr_entry_to_vcal(GString *vcal, char *csa_rrule);
void csa_read_rr_entry_from_vcal(char *vcal_data, GString *csa_rrule);
void csa_remove_end_from_vcal(GString *vcal);

#endif
