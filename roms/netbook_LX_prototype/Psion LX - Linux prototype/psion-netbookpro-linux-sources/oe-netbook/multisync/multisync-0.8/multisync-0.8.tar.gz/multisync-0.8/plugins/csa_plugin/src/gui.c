#include <stdlib.h>
#include <glib.h>
#include <gmodule.h>
#include <gtk/gtkmain.h>
#include <gtk/gtksignal.h>
#include <multisync.h>
#include <dirent.h>
#include "csa_plugin.h"
#include "gui.h"
#include "interface.h"
#include "support.h"
#include <iconv.h>

GtkWidget* csaoptions = NULL;
csa_connection *csaconn;

GtkWidget* open_option_window(sync_pair *pair, connection_type type)
{
  char *str;

  if(!csaoptions)
  {

    csaconn = g_malloc0(sizeof(csa_connection));

    csaconn->sync_pair = pair;
    csaconn->conntype = type;

    csa_load_config(csaconn);

    csaoptions = create_csa_options();

    gtk_widget_show (csaoptions);

    if(csaconn->csaserver == NULL)
      csaconn->csaserver = g_strdup("");

    gtk_entry_set_text(GTK_ENTRY(lookup_widget(csaoptions, "csaserver")), 
		       csaconn->csaserver);


  }

  return(csaoptions);
}

void csa_window_closed(void) 
{
  sync_plugin_window_closed();

  if(csaconn)
    g_free(csaconn);

  csaoptions = NULL;
  csaconn = NULL;
}


void csaoptions_cancel(void) 
{
  if(csaconn)
    g_free(csaconn);

  gtk_widget_destroy(csaoptions);
  csa_window_closed();
}

void csaoptions_ok(void)
{
  char *str;

  if(csaconn->csaserver)
    g_free(csaconn->csaserver);

  csaconn->csaserver = (char*)gtk_editable_get_chars(
		GTK_EDITABLE(lookup_widget(csaoptions, "csaserver")), 0, -1);

  csa_save_config(csaconn);

  if(csaconn)
    g_free(csaconn);

  gtk_widget_destroy(csaoptions);
  csa_window_closed();
}
