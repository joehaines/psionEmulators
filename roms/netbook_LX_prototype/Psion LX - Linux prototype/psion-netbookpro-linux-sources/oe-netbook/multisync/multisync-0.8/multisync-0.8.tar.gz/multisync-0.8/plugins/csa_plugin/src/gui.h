#ifndef GUI_H
#define GUI_H
 
#include <multisync.h>
 
GtkWidget* open_option_window(sync_pair *pair, connection_type type);

void csa_window_closed(void);
void csaoptions_cancel(void);
void csaoptions_ok(void);

#endif
