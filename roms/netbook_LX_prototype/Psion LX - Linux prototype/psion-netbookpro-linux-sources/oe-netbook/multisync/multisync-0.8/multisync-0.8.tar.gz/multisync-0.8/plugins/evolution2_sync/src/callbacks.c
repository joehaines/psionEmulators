#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"

gboolean
evo2_optwin_delete_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  evo2_window_closed();
  return FALSE;
}


void
evo2_cancelbutton_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
  evo2_window_cancel();
}


void
evo2_okbutton_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  evo2_window_ok();
}

