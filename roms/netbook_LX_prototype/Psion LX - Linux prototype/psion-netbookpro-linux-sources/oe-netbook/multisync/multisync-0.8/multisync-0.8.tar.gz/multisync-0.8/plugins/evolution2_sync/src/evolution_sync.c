#include <stdlib.h>
#include <glib.h>
#include <multisync.h>

/* 
   MultiSync Evolution2 Plugin
   Copyright (C) 2004 Tom Foottit <tom@foottit.com>
   Copyright (C) 2004 Bo Lincoln <lincoln@lysator.liu.se>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License version 2 as
   published by the Free Software Foundation;

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
   OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
   IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY
   CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN 
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF 
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

   ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
   COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS 
   SOFTWARE IS DISCLAIMED.
*/

/*
 *  $Id: evolution_sync.c,v 1.2.2.8 2004/04/17 02:30:35 irix Exp $
 */

#include "evolution_sync.h"
#include "sync_ecal.h"


/*
 * sync_connect
 */
eds_conn_t* sync_connect(sync_pair* handle, connection_type type, sync_object_type object_types) 
{
  eds_conn_t *conn;
  char *uri;

  printf ("%s\n", __func__);

  conn = g_malloc0(sizeof(eds_conn_t));
  g_assert(conn);

  conn->sync_pair = handle;
  conn->commondata.object_types = object_types;
  
  /* FIXME */
  /* set up the change IDs ... is this correct ... how unique does it need to be?? */
  conn->cal_change_id = g_strdup(sync_get_datapath(conn->sync_pair));
  conn->book_change_id = g_strdup(sync_get_datapath(conn->sync_pair));

  evo2_load_config(conn);
    
  /* FIXME pull the databases from the conn struct here */  
  /* uri = g_strdup_printf ("file://%s/.evolution/calendar/local/OnThisComputer/Personal", g_get_home_dir ()); */
  
  if(!conn->calendarpath)
  {
    sync_set_requestfailederror("no calendar specified inconfiguration", uri);  
  }
  else
  {
    uri = g_strdup_printf ("file://%s", conn->calendarpath);
    conn->cal_client = evo2_cal_open(uri);

    /* FIXME don't use the URI, use the NAME to be displayed to the user instead ... */
    if (!conn->cal_client)
      sync_set_requestfailederror("could not connect to calendar %s", uri);
    else
      sync_set_requestdone(conn->sync_pair);

    g_free (uri);
  }

  return conn;
}


/*
 * sync_disconnect
 */
void sync_disconnect(eds_conn_t *conn)
{
  printf ("%s\n", __func__);
  sync_pair *sync_pair = conn->sync_pair;
  g_free(conn);
  sync_set_requestdone(sync_pair);
}


/*
 * get_changes
 */
void get_changes(eds_conn_t *conn, sync_object_type newdbs)
{
  GList *changes = NULL;
  sync_object_type retnewdbs = 0;
  change_info *chinfo;

  if((conn->commondata.object_types & (SYNC_OBJECT_TYPE_CALENDAR)) ||
     (conn->commondata.object_types & (SYNC_OBJECT_TYPE_TODO)))
  {
    evo2_cal_get_changes(conn, newdbs, &changes);
  }
  
  if(conn->commondata.object_types & (SYNC_OBJECT_TYPE_PHONEBOOK)) 
  {
    /* FIXME */
    
  }
  
  /* Allocate the change_info struct */
  chinfo = g_malloc0(sizeof(change_info));
  chinfo->changes = changes;
  
  /* Did we detect any reset databases? */
  chinfo->newdbs = retnewdbs;
  sync_set_requestdata(chinfo, conn->sync_pair);

  return;
}


/*
 * syncobj_modify
 */
void syncobj_modify(eds_conn_t *conn, char* object, char *uid, sync_object_type objtype, char *returnuid, int *returnuidlen)
{
  printf ("%s\n", __func__);
  
  if((objtype & (SYNC_OBJECT_TYPE_CALENDAR)) ||
     (objtype & (SYNC_OBJECT_TYPE_TODO)))
  {
    if(NULL == uid)
    {
      /* create */
      if(!evo2_cal_create(conn, object, returnuid, returnuidlen))
      {
        sync_set_requestfailed(conn->sync_pair);
      }      
    }
    else
    {
      /* update */
      if(!evo2_cal_update(conn, uid, object))
      {
        sync_set_requestfailed(conn->sync_pair);
      }
    }
  }
  else if(objtype & (SYNC_OBJECT_TYPE_PHONEBOOK))
  {    
    /* FIXME */
    
  }
        
  sync_set_requestdone(conn->sync_pair);
}


/*
 * syncobj_delete
 */
void syncobj_delete(eds_conn_t *conn, char *uid, sync_object_type objtype, int softdelete)
{
  printf ("%s\n", __func__);
  
  if((objtype & (SYNC_OBJECT_TYPE_CALENDAR)) ||
     (objtype & (SYNC_OBJECT_TYPE_TODO)))
  {
    if(!evo2_cal_delete(conn, uid))
    {
      sync_set_requestfailed(conn->sync_pair);
    }
  }
  else if(objtype & (SYNC_OBJECT_TYPE_PHONEBOOK))
  {    
    /* FIXME */
    
  }
        
  sync_set_requestdone(conn->sync_pair);
}


/*
 * syncobj_get_recurring
 */
void syncobj_get_recurring(eds_conn_t *conn, changed_object *obj)
{
  printf ("%s\n", __func__);
  
  /* not implemented */
  
  sync_set_requestdata(NULL, conn->sync_pair);
}


/*
 * sync_done
 */
void sync_done(eds_conn_t *conn, gboolean success)
{
  printf ("%s\n", __func__);
  sync_set_requestdone(conn->sync_pair);
}



/*
 * sync_connect
 */
gboolean always_connected()
{
  printf ("%s\n", __func__);
  return TRUE;
}


/*
 * short_name
 */
char *short_name()
{
  printf ("%s\n", __func__);
  return("evolution2-sync");
}


/*
 * long_name
 */
char *long_name()
{
  printf ("%s\n", __func__);
  return "Ximan Evolution 2";
}


/*
 * plugin_info
 */
char *plugin_info(void)
{
  printf ("%s\n", __func__);
  return "This plugin allows you to sync with Ximian Evolution 2.";
}


/*
 * plugin_init
 */
void plugin_init(void)
{
  printf ("%s\n", __func__);
  evo2_init_config();
}


/*
 * object_types
 */
sync_object_type object_types()
{
  printf ("%s\n", __func__);
  return SYNC_OBJECT_TYPE_CALENDAR | SYNC_OBJECT_TYPE_PHONEBOOK | SYNC_OBJECT_TYPE_TODO;
}


/*
 * plugin_API_version
 */
int plugin_API_version(void)
{
  printf ("%s\n", __func__);
  return 3; 
}
