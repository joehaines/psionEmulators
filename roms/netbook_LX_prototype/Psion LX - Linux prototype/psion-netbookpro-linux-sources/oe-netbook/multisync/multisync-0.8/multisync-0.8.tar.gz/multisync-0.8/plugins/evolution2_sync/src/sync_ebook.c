/* 
   MultiSync Evolution2 Plugin
   Copyright (C) 2004 Tom Foottit <tom@foottit.com>
   Copyright (C) 2004 Bo Lincoln <lincoln@lysator.liu.se>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License version 2 as
   published by the Free Software Foundation;

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
   OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
   IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY
   CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN 
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF 
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

   ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
   COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS 
   SOFTWARE IS DISCLAIMED.
*/

/*
 *  $Id: sync_ebook.c,v 1.1.2.3 2004/05/05 04:17:30 irix Exp $
 *
 * The libebook API is (sort of) documented at:
 * http://www.gnome.org/projects/evolution/developer-doc/libebook/EBook.html
 */


#include "sync_ebook.h"

/*
 * get the UID from a vcard
 * caller must free the string
 */
char* evo2_addr_get_uid(char *vcard) 
{
  char *pos = vcard;
  while (pos) 
  {
    if (!strncmp(pos, "UID:", 4)) 
    {
      char uid[256];
      if (sscanf(pos, "UID:%255[^\r\n]", uid) > 0) 
        return(g_strdup(uid));
    }
    pos = strstr(pos, "\n");
    if (pos)
      pos++;
  }
  return(NULL);
}


/*
 * evo2_addrbook_open
 */
EBook* evo2_addrbook_open(const char *uri)
{
  GError *error = NULL;
  EBook *client;

  client = e_book_new();
  if(!client) 
  {
    printf ("failed new open addressbook\n");
    return NULL;
  }

  if(!e_book_load_uri(client, uri, FALSE, &error)) 
  {
    printf ("failed to open addressbook: %s\n", error->message);
    g_error_free(error);
    return NULL;
  }

  return client;
}


/*
 * evo2_addrbook_get_changes
 */
gboolean evo2_addrbook_get_changes(eds_conn_t *conn, sync_object_type newdbs, GList **changes)
{
  GList *local_changes, *l;
  GError *error = NULL;
  
  if (!conn->book_client)
    return FALSE;

  /* The API is (I think...):
     gboolean    e_book_get_changes         (EBook *book,
                                             char *changeid,
                                             GList **changes,
                                             GError **error);
     with change_id being the change identifier for this sync pair??
     need to test this and see if it works at all...
   */
                                             
  if (!e_book_get_changes(conn->book_client, 
                          conn->book_change_id, 
                          &local_changes, 
                          &error)) 
  {
    printf ("e_book_get_changes failed: %s\n", error->message);
    g_error_free(error);
    return FALSE;
  }

  printf ("%d entries found\n", g_list_length (local_changes));

  for (l = local_changes; l; l = l->next) 
  {
    EBookChange *ccc = l->data;
    EContact *contact = ccc->contact;
    changed_object* change = NULL;
    char *uid = NULL;
    char* vcard = NULL;
    
    if (!contact)
      continue;

    /* FIXME - this is a guess... */
    vcard = e_vcard_to_string((EVCard*)contact, EVC_FORMAT_VCARD_30);
    printf("----- %s\n", vcard);

    change = g_malloc0(sizeof(changed_object));
    g_assert(change);
    
    change->uid = evo2_addr_get_uid(vcard);
    change->comp = vcard;
    change->object_type = SYNC_OBJECT_TYPE_PHONEBOOK;

	  if (ccc->change_type & E_BOOK_CHANGE_CARD_DELETED)
	    change->change_type = SYNC_OBJ_HARDDELETED;
	  else if (ccc->change_type & E_BOOK_CHANGE_CARD_MODIFIED)
	    change->change_type = SYNC_OBJ_MODIFIED;
	  else if (ccc->change_type & E_BOOK_CHANGE_CARD_ADDED)
	    change->change_type = SYNC_OBJ_ADDED;
    else
      printf("unknown change type\n");
    

    *changes = g_list_append(*changes, change);
  }

  return TRUE;
}


/*
 * evo2_addrbook_delete
 */
gboolean evo2_addrbook_delete(eds_conn_t *conn, char* uid)
{
  GError *error = NULL;
  
  gboolean rc = e_book_remove_contact(conn->book_client,
                                      uid,
                                      &error);
  
  if(!rc)
  {
    printf("e_book_remove_contact failed: %s\n", error->message);
    g_error_free(error);
  }
  
  return rc; 
}


/*
 * evo2_addrbook_create
 */
gboolean evo2_addrbook_create(eds_conn_t *conn, char* object, char* returnuid, int *returnuidlen)
{
  GError *error = NULL;  
  EContact *contact = e_contact_new_from_vcard(object);
  
  if(!contact)
    return FALSE;
  
  gboolean rc = e_book_add_contact(conn->book_client,
                                   contact,
                                   &error);
  
  if(rc)
  {
    /* FIXME 
     * need to set returnuid and returnuidlen here ... how?
     */  
  }
  else
  {
    printf("e_book_add_contact failed: %s\n", error->message);
    g_error_free(error);
  }
  
  return rc;
}


/*
 * evo2_addrbook_update
 */
gboolean evo2_addrbook_update(eds_conn_t *conn, char* uid, char* object)
{
  GError *error = NULL;  
  EContact *contact = e_contact_new_from_vcard(object);
  
  if(!contact)
    return FALSE;
  
  /* FIXME - is this call correct? */
  gboolean rc = e_book_commit_contact(conn->book_client,
                                      contact,
                                      &error);
  
  if(!rc)
  {
    printf("e_book_commit_contact failed: %s\n", error->message);
    g_error_free(error);
  }
  
  return rc;
}



