/* 
   MultiSync Evolution2 Plugin
   Copyright (C) 2004 Tom Foottit <tom@foottit.com>
   Copyright (C) 2004 Bo Lincoln <lincoln@lysator.liu.se>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License version 2 as
   published by the Free Software Foundation;

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
   OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
   IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY
   CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN 
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF 
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

   ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
   COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS 
   SOFTWARE IS DISCLAIMED.
*/

/*
 *  $Id: sync_ecal.c,v 1.3.2.5 2004/05/05 04:17:30 irix Exp $
 *
 * The libecal API is (sort of) documented at:
 * http://www.gnome.org/projects/evolution/developer-doc/libecal/ECal.html
 */


#include "sync_ecal.h"

/*
 * evo2_cal_object_type_from_component
 */
sync_object_type evo2_cal_object_type_from_component(ECalComponent *comp)
{
  sync_object_type type;

  if (!comp)
    return SYNC_OBJECT_TYPE_UNKNOWN;

  switch(e_cal_component_get_vtype(comp)) 
  {
    case E_CAL_COMPONENT_EVENT:
      type = SYNC_OBJECT_TYPE_CALENDAR;
      break;
    case E_CAL_COMPONENT_TODO:
      type = SYNC_OBJECT_TYPE_TODO;
      break;
    default:
      type = SYNC_OBJECT_TYPE_UNKNOWN;
      break;
  }

  return type;
}


/*
 * evo2_cal_open
 */
ECal* evo2_cal_open(const char *uri)
{
  GError *error = NULL;
  ECal *client;

  client = e_cal_new_from_uri (uri, E_CAL_SOURCE_TYPE_EVENT);
  if(!client) 
  {
    printf ("failed new open calendar\n");
    return NULL;
  }

  if(!e_cal_open (client, FALSE, &error)) 
  {
    printf ("failed to open calendar\n");
    return NULL;
  }

  return client;
}


/*
 * evo2_cal_get_changes
 */
int evo2_cal_get_changes(eds_conn_t *conn, sync_object_type newdbs, GList **changes)
{
  GList *local_changes, *l;
  GError *error = NULL;
  
  if (!conn->cal_client)
    return -1;

  /* The API is (I think...):
     boolean    e_cal_get_changes           (ECal *ecal,
                                             const char *change_id,
                                             GList **changes,
                                             GError **error);
     with change_id being the change identifier for this sync pair??
     need to test this and see if it works at all...
   */
                                             
  if (!e_cal_get_changes(conn->cal_client, 
                         conn->cal_change_id, 
                         &local_changes, 
                         &error)) 
  {
    printf("e_cal_get_changes failed: %s\n", error->message);
    g_error_free(error);
    return 0;
  }

  printf ("%d entries found\n", g_list_length (local_changes));

  for (l = local_changes; l; l = l->next) 
  {
    ECalChange *ccc = l->data;
    ECalComponent *comp = ccc->comp;
    icalcomponent *icomp;
    changed_object* change;
    char *uid = NULL;

    if (!comp)
      continue;

    icomp = e_cal_component_get_icalcomponent(comp);
    printf ("----- %s\n", icalcomponent_as_ical_string (icomp));

    change = g_malloc0(sizeof(changed_object));
    g_assert(change);
    e_cal_component_get_uid(comp, (const char**) &uid);

    if (uid)
      change->uid = g_strdup(uid);

    change->comp = e_cal_get_component_as_string (conn->cal_client, icomp);

    /* FIXME */
	  if (ccc->type & E_CAL_CHANGE_DELETED)
	    change->change_type = SYNC_OBJ_HARDDELETED;
	  else if (ccc->type & E_CAL_CHANGE_MODIFIED)
	    change->change_type = SYNC_OBJ_MODIFIED;
	  else if (ccc->type & E_CAL_CHANGE_ADDED)
	    change->change_type = SYNC_OBJ_ADDED;
    else
      printf("unknown change type\n");
    
    change->object_type = evo2_cal_object_type_from_component(comp);

    *changes = g_list_append(*changes, change);
  }

  return 0;
}


/*
 * evo2_cal_delete
 */    
gboolean evo2_cal_delete(eds_conn_t *conn, char* uid)
{
  GError *error = NULL;
  
  gboolean rc = e_cal_remove_object(conn->cal_client,
                                    uid,
                                    &error);
  
  if(!rc)
  {
    printf("e_cal_remove_object failed: %s\n", error->message);
    g_error_free(error);
  }
    
  return rc; 
}


/*
 * evo2_cal_create
 */    
gboolean evo2_cal_create(eds_conn_t *conn, char* object, char* returnuid, int *returnuidlen)
{
  GError *error = NULL;  
  icalcomponent *icomp = icalcomponent_new_from_string(object);
  
  if(!icomp)
    return FALSE;
  
  gboolean rc = e_cal_create_object(conn->cal_client,
                                    icomp,
                                    &returnuid,
                                    &error);
  if(returnuid)
  {
    *returnuidlen = strlen(returnuid);
  }
  else
  {
    *returnuidlen = 0; 
  }
  
  if(!rc)
  {
    printf("e_cal_create_object failed: %s\n", error->message);
    g_error_free(error);
  }
  
  return rc;
}


/*
 * evo2_cal_update
 */    
gboolean evo2_cal_update(eds_conn_t *conn, char* uid, char* object)
{
  GError *error = NULL;  
  icalcomponent *icomp = icalcomponent_new_from_string(object);
  
  if(!icomp)
    return FALSE;
  
  gboolean rc = e_cal_modify_object(conn->cal_client,
                                    icomp,
                                    CALOBJ_MOD_ALL,
                                    &error);
    
  if(!rc)
  {
    printf("e_cal_modify_object failed: %s\n", error->message);
    g_error_free(error);
  }
  
  return rc;
}
