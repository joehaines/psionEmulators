#ifndef ADDR_SYNC_H
#define ADDR_SYNC_H

#include "config.h"
#include <gtk/gtkmain.h>
#include <gtk/gtksignal.h>
#include <ebook/e-book.h>
#include <ebook/e-card-simple.h>

char* evo_addr_get_uid(char *vcard);
void evo_addr_bookloaded_cb(EBook *book, EBookStatus status, gpointer data);
void evo_addr_disconnect(evolution_connection *conn);
void evo_addr_connect(evolution_connection *conn);
void evo_addr_removed_cb (EBookView *book_view, GList *ids, 
			  gpointer data);
void evo_addr_added_cb  (EBookView *book_view, GList *cards,
			 gpointer data);
void evo_addr_changed_cb (EBookView *book_view, GList *cards,
			  gpointer data);
void evo_addr_view_cb (EBook *book, EBookStatus status, EBookView *book_view, 
		       gpointer data);
void evo_addr_change(evolution_connection *conn, GList *ids, GList *cards,
		     int change_type);
void evo_addr_get_changes(GList *changes,
			  evolution_connection *conn, evo_sync_cb cb);
void evo_addr_get_all(GList *changes,
		      evolution_connection *conn, evo_sync_cb cb);
gboolean evo_addr_modify(gpointer data);
char *evo_addr_set_uid(char *vcard, char* uid);
void evo_addr_seqcompl_cb (EBookView *book_view, 
			   EBookViewStatus status, 
			   gpointer data);
void evo_addr_modify_cb (EBook *book, EBookStatus status, gpointer data);
void evo_addr_add_cb (EBook *book, EBookStatus status, const char *id, 
		      gpointer data);
void evo_addr_modify_next(evolution_connection *conn, gboolean tryadd);


#endif
