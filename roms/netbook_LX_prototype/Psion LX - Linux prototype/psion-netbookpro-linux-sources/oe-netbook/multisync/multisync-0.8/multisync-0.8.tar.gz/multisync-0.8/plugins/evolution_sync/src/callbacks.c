#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"

gboolean
evo_optwin_delete_event                 (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  evo_window_closed();
  return FALSE;
}



void
evo_okbutton_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
  evo_window_ok();

}


void
evo_cancelbutton_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
  evo_window_cancel();

}

