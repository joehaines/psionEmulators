#include <gnome.h>


gboolean
on_optwin_delete_event                 (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_okbutton_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancelbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
evo_okbutton_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
evo_cancelbutton_clicked               (GtkButton       *button,
                                        gpointer         user_data);

gboolean
evo_optwin_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
