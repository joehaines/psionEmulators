#ifndef ENTRY_DB_H
#define ENTRY_DB_H

void gnokii_load_entries(gnokii_connection *);
void gnokii_save_entries(gnokii_connection *);
#endif
