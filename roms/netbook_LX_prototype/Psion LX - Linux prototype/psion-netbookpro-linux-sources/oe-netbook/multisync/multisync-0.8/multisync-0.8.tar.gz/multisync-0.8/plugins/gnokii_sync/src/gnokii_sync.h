#ifndef BACKUP_PLUGIN_H
#define BACKUP_PLUGIN_H

#include <gnokii.h>
#include <multisync.h>

// Memory type and location together gives uid 
typedef struct {
	gn_memory_type mem_type;	//< Memory type, where entry is stored
	int location;		//< Entry's position in memory
	sync_object_type object_type;
	int changed;
	char *vobj;		//< Objects stored as vCard or vCalendar string
} gnokii_sync_object;

/**
 * XML parser states
 */
typedef  enum {
	START,
	INSIDE_ENTRY,
	UNKNOWN,
	FINISH
} entry_parser_state ;


typedef struct {
	client_connection commondata;
	sync_pair *sync_pair;
	connection_type conntype;
	struct gn_statemachine gnokii_state;
	gn_data gnokii_data;
	char *lockfile;
	GList *entries;		//< The entries we already have in the phone
	entry_parser_state parser_state; //< Actual state of parser
} gnokii_connection;


void gnokii_free_entries(gnokii_connection * conn);

void gnokii_modify_or_delete(gnokii_connection * conn,
			     char *comp,
			     char *uid, sync_object_type objtype,
			     char *uidret, int *uidretlen,
			     gboolean softdelete);

void gnokii_free_connection(gnokii_connection * conn);

gboolean gnokii_do_connect(gpointer data);

gnokii_connection *sync_connect(sync_pair * handle, connection_type type,
				sync_object_type object_types);

void sync_disconnect(gnokii_connection * conn);

void sync_done(gnokii_connection * conn, gboolean success);

void syncobj_modify(gnokii_connection * conn,
		    char *comp,
		    char *uid, sync_object_type objtype,
		    char *uidret, int *uidretlen);

void syncobj_delete(gnokii_connection * conn, char *uid,
		    sync_object_type objtype, int softdelete);

gboolean gnokii_do_get_changes(gpointer data);

void get_changes(gnokii_connection * conn, sync_object_type newdbs);


#endif
