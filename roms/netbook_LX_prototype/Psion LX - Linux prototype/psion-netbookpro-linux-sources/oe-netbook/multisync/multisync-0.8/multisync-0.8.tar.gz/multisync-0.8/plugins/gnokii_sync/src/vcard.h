#ifndef VCARD_H
#define VCARD_H

#include <gnokii.h>
API int gn_phonebook2vcard2(FILE * , gn_phonebook_entry *, char *);
API int gn_phonebook2vcard_str(char**, gn_phonebook_entry *, char *);
API int gn_vcard_str2phonebook(char*, gn_phonebook_entry *);
API int gn_vcard2phonebook2(FILE *, gn_phonebook_entry *);

#endif
