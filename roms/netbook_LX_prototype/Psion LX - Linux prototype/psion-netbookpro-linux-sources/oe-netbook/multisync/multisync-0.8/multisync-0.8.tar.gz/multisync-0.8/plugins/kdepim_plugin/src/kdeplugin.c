/*********************************************************************** 
MultiSync Plugin for KDE 3.x
Copyright (C) 2004 Stewart Heitmann <sheitmann@users.sourceforge.net>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License version 2 as
published by the Free Software Foundation;

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY
CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN 
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF 
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS 
SOFTWARE IS DISCLAIMED.
*************************************************************************/

#include <multisync.h> 
#include "kaddrbook.h"

typedef struct 
    {
    client_connection commondata;
    sync_pair *syncpair;
    void *kaddrbook;
    } kde_connection;


kde_connection* sync_connect(sync_pair* handle, connection_type type, sync_object_type object_types) 
    {
    kde_connection *conn;

    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s() datapath=%s\n",__FUNCTION__,sync_get_datapath(handle));

    /* Allocate and initialise a kde_connection object. */
    conn = (kde_connection *)g_malloc0(sizeof(kde_connection));
    conn->commondata.object_types = object_types;
    conn->syncpair = handle;
    conn->kaddrbook = kaddrbook_connect(sync_get_datapath(handle));

    if (!(conn->kaddrbook))
        sync_set_requestmsgerror(SYNC_MSG_CONNECTIONERROR, "Couldn't connect to KDE addressbook", conn->syncpair);
    else
        sync_set_requestdone(conn->syncpair);

    /* Return kde_connection object to the sync engine */
    return(conn);
    }


void sync_disconnect(kde_connection *conn)
    {
    sync_pair *syncpair;

    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s()\n",__FUNCTION__);

    kaddrbook_disconnect(conn->kaddrbook);
    sync_set_requestdone(conn->syncpair);
    g_free(conn);
    }


void get_changes(kde_connection *conn, sync_object_type newdbs)
    {
    change_info *chinfo;
    
    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s(conn,newdbs=%d)\n",__FUNCTION__,newdbs);

    /* Allocate and initialise change_info object */
    chinfo = (change_info*)g_malloc0(sizeof(change_info));
    chinfo->changes = NULL;
    chinfo->newdbs  = (sync_object_type)0;

    if (conn->commondata.object_types & (SYNC_OBJECT_TYPE_CALENDAR))
        {
        }

    if (conn->commondata.object_types & (SYNC_OBJECT_TYPE_TODO))
        {
        }
    
    if (conn->commondata.object_types & SYNC_OBJECT_TYPE_PHONEBOOK)
        {
        int reset = (newdbs & SYNC_OBJECT_TYPE_PHONEBOOK) ? 1 : 0;
        int err = kaddrbook_get_changes(conn->kaddrbook, &(chinfo->changes), reset);
        if (err)
            {
            sync_set_requestmsgerror(SYNC_MSG_REQFAILED, "Couldn't access KDE addressbook", conn->syncpair);
            return;
            }
        }
  
    sync_set_requestdata(chinfo, conn->syncpair);
    return;
    }



void syncobj_modify_list(kde_connection *conn, GList *changes)
    {
    GList *results=NULL;
    int err;

    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s()\n",__FUNCTION__);

    err = kaddrbook_modify_list(conn->kaddrbook, changes, &results); 
    if (err)
        sync_set_requestmsgerror(SYNC_MSG_REQFAILED, "Couldn't update KDE addressbook", conn->syncpair);
    else 
        sync_set_requestdata(results, conn->syncpair);
    }


void sync_done(kde_connection *conn, gboolean success)
    {
    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s(conn,success=%d)\n",__FUNCTION__,success);

    kaddrbook_sync_done(conn->kaddrbook, success);
    sync_set_requestdone(conn->syncpair);
    }


gboolean always_connected(void)
    {return(TRUE);}


char* short_name(void)
    {return("kdeplugin");}


char* long_name(void)
    {return("KDE Addressbook");}


char* plugin_info(void) 
    {
    return("Plugin for the KDE 3.x Addressbook.");
    }


void plugin_init(void)
    {
    static char *argv[]={"multisync[kde_plugin]"};
    int argc = sizeof(argv)/sizeof(argv[0]);
    
    if (getenv ("MULTISYNC_DEBUG"))
        printf("kdepim_plugin: %s()\n",__FUNCTION__);

    kaddrbook_init(argc,argv);
    }


sync_object_type object_types(void)
    {return(SYNC_OBJECT_TYPE_PHONEBOOK);}


int plugin_API_version(void)
    { return(3); }

