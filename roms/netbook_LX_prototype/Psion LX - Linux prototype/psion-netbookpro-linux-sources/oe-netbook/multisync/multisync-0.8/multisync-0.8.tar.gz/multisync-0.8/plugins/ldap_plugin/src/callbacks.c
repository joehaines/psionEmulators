#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_window1_destroy                     (GtkObject       *object,
                                        gpointer         user_data)
{

}


void
on_btn_ok_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btn_cancel_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btn_test_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_wnd_options_destroy                 (GtkObject       *object,
                                        gpointer         user_data)
{

}


void
on_btn_auth_mechs_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_chk_write_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_btn_auth_mechs_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_btn_test_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

