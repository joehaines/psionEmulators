#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"


void
on_ok_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{
  opie_ok();
}


void
on_cancel_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
  opie_cancel();
}


gboolean
on_opie_config_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{

  opie_window_closed();
  return FALSE;
}

