#ifndef BASE64_H
#define BASE64_H

int syncml_encode64(const char *_in, unsigned inlen,
		    char *_out, unsigned outmax, unsigned *outlen);
int syncml_decode64(const char *in, unsigned inlen, 
		    char *out, unsigned *outlen);



#endif
