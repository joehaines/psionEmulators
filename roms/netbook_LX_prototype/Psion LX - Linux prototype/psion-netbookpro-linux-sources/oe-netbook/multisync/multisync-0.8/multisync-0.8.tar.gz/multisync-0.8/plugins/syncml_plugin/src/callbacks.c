#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gui.h"


gboolean
on_syncml_optwin_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  syncml_cancel();
  return FALSE;
}


void
syncml_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
  syncml_ok();
}


void
syncml_cancelbutton_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  syncml_cancel();
}


void
syncml_devinfobutton_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
  syncml_gui_get_devinfo();
}

