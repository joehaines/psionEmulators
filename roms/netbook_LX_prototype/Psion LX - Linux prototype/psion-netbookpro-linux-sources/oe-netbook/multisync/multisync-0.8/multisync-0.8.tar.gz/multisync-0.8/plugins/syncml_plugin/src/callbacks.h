#include <gnome.h>


gboolean
on_syncmloptwin_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_okbutton_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancelbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_syncml_optwin_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
syncml_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
syncml_cancelbutton_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
syncml_devinfobutton_clicked           (GtkButton       *button,
                                        gpointer         user_data);
