#ifndef GUI_H
#define GUI_H

#include <multisync.h>
#include "syncml_engine.h"
#include "syncml_plugin.h"

GtkWidget* open_option_window(sync_pair *pair, connection_type type);
void syncml_window_closed(void);
void syncml_cancel(void);
gboolean syncml_get_window_data(void);
void syncml_ok(void);
void syncml_show_msg(char *msg);
gboolean syncml_show_question(char *msg);
void syncml_async_msg(char *msg);
gboolean syncml_do_show_msg(gpointer msg);

void syncml_server_selected(GtkMenuItem *menuitem);
void syncml_client_selected(GtkMenuItem *menuitem);
void syncml_conn_type_selected(GtkMenuItem *menuitem, syncml_conn_type type);
void syncml_gui_get_devinfo(void);
void syncml_gui_devinfo_received(syncml_devinfo *devinfo, char* error);


#endif
