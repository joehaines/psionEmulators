#ifndef SYNCML_SSL_H
#define SYNCML_SSL_H

#include "syncml_engine.h"


int syncml_ssl_read(syncml_state *state, char *data, int len, int timeout);
int syncml_ssl_write(syncml_state *state, char *data, int len, int timeout);
void syncml_ssl_disconnect(syncml_state *state);
void syncml_ssl_exit(syncml_state *state);
gboolean syncml_ssl_server_connect(syncml_state *state);
gboolean syncml_ssl_client_connect(syncml_state *state);
gboolean syncml_ssl_init_server(syncml_state *state);
gboolean syncml_ssl_init_client(syncml_state *state);
void syncml_ssl_init(void);














#endif
