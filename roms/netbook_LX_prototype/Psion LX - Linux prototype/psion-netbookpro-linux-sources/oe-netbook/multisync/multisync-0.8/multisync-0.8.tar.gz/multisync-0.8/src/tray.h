#ifndef TRAY_H
#define TRAY_H

void init_tray();

#endif

