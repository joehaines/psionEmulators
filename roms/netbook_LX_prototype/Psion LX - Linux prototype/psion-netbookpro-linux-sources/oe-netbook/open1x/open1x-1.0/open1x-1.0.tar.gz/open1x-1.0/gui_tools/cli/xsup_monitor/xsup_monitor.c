/*******************************************************************
 *
 * File: xsup_monitor.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: xsup_monitor.c,v 1.4 2004/09/18 04:41:31 chessing Exp $
 * $Date: 2004/09/18 04:41:31 $
 * $Log: xsup_monitor.c,v $
 * Revision 1.4  2004/09/18 04:41:31  chessing
 * Fixes for TTLS-MSCHAPv2 for bugs found by Chris Zimmerman.  Also, a couple of small updates to try to get IPC back to where it needs to be.
 *
 * Revision 1.3  2004/09/09 23:11:35  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.2  2004/03/20 03:57:50  chessing
 *
 * A couple of small updates to xsup_monitor, and gui_interface.
 *
 * Revision 1.1  2004/03/19 23:43:55  chessing
 *
 * Lots of changes.  Changed the password prompting code to no longer require the EAP methods to maintain their own stale frame buffer.  (Frame buffer pointers should be moved out of generic_eap_data before a final release.)  Instead, EAP methods should set need_password in generic_eap_data to 1, along with the variables that identify the eap type being used, and the challenge data (if any -- only interesting to OTP/GTC at this point).  Also fixed up xsup_set_pwd.c, and got it back in CVS.  (For some reason, it was in limbo.)  Added xsup_monitor under gui_tools/cli.  xsup_monitor will eventually be a cli program that will monitor XSupplicant (running as a daemon) and display status information, and request passwords when they are not in the config.
 *
 *
 *******************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>


#include "../../common/gui_interface.h"

int connected;
char activeint[16];

/*******************************************************************
 *
 * Make sure that XSupplicant is running.  If it isn't, then block and
 * check every so often.
 *
 *******************************************************************/
void block_while_not_xsup()
{
  int disp=0;

  while (is_xsup_running() == FALSE)
    {
      if (disp == 0)
	{
	  printf("XSupplicant isn't running.  We will block, and check again every second!\n");
	  disp = 1;
	}

      if (connected == 1)
	{
	  gui_interface_disconnect();
	  connected = 0;
	}

      sleep(1);
    }
}

void do_password(char *eaptype, char *challenge)
{
  char *passwd, buffer[1520], result[256];
  int bufptr, dlen, done = FALSE, i;

  bzero((char *)&buffer, 1520);
  
  if (gui_interface_build_header((char *)&buffer, &bufptr, (char *)&activeint, 
				 IPC_SET) != ERR_NONE)
    {
      printf("Error! Couldn't build header!\n");
      return;
    }

  passwd = getpass("Please enter your password : ");
 
  if (passwd == NULL)
    {
      printf("No password set!\n");
      return;
    }

  gui_interface_set_password((char *)&buffer, &bufptr, passwd);

  switch (gui_interface_send_packet((char *)&buffer, bufptr))
    {
    case ERR_PKT_BAD:
      printf("Error! Packet appears to be bad!\n");
      return;
      break;
    case ERR_SOCK:
      printf("Error! There was a socket error!\n");
      return;
      break;
    }

  // Flush extra request packets.
  bzero((char *)&buffer, 1520);
  while (!done)
    {
      bufptr = 1520;
      if (gui_interface_get_packet((char *)&buffer, &bufptr, TRUE) == ERR_SOCK)
	{
	  done = TRUE;
	  continue;
	}

      //      bufptr = sizeof(struct ipc_interface)-1;
      bufptr = 0;

      i = gui_interface_parse_packet((char *)&buffer, &bufptr, (char *)&result,
				     &dlen, (char *)&activeint);

      if (i != PASSWORD)
	{
	  done = TRUE;
	}
    }

  if (result[0] == ACK) 
    {
      printf("Your password has been successfully submitted to the XSupplicant daemon.\n");
    } else {
      printf("Error!  Password not set!\n");
    }
}

void handle_password(char *packet)
{
  int bufptr=0;
  char eaptype[128], challenge[256];

  strcpy((char *)&eaptype[0], (char *)&packet[bufptr]);
  printf("EAP Type : %s\n",eaptype);
  bufptr += strlen(eaptype)+1;

  if (challenge[0] != 0x00)
    {
      strcpy((char *)&challenge[0], (char *)&packet[bufptr]);
      printf("Challenge : %s\n", challenge);
    }

  do_password(eaptype, challenge);
}

int main(int argc, char *argv[])
{
  char buffer[1520], result[256];
  int bufptr, dlen, i;


  while (1)
    {
      // Make sure that we have something to connect to.
      block_while_not_xsup();

      // If we have not connected before, or if we need to reconnect.
      if (connected != 1)
	{
	  if (gui_interface_connect() != ERR_NONE)
	    {
	      printf("Error!  Couldn't get a handle to the daemon!\n");
	      exit(0);
	    }
	  connected = 1;
	}

      bzero(&buffer, 1520);
      bufptr = 1520;

      gui_interface_get_packet((char *)&buffer, (int *)&bufptr, TRUE);

      if (bufptr > 0)
	{
	  // Process the message we have been given.
	  bufptr = 0;
	  i=gui_interface_parse_packet((char *)&buffer, &bufptr, 
				       (char *)&result, &dlen, 
				       (char *)&activeint);

	  switch (i)
	    {
	    case ERR_PKT_BAD:
	      // We have a bad packet!
	      printf("Got a bad packet from the Supplicant!\n");
	      break;
	    case PASSWORD:
	      handle_password((char *)&result[0]);
	    }
	} 

      sleep(1);
    }
}
