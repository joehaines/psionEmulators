/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license. (See LICENSE file for more info.)
 *
 * File: gui_interface.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: gui_interface.c,v 1.10 2004/09/10 22:22:59 chessing Exp $
 * $Date: 2004/09/10 22:22:59 $
 * $Log: gui_interface.c,v $
 * Revision 1.10  2004/09/10 22:22:59  chessing
 * More updates to IPC.  We now speak IPC with the messages being version 2, instead of version 1.  Because version 1 messages were only allowed across the loopback interface, they have been deprecated, and will result in an error from Xsupplicant!
 *
 * Revision 1.9  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.8  2004/03/29 21:57:13  chessing
 *
 * Changed the socket number we use for communication with the daemon from 10240 (which seems like a bad choice) to 26798 (which seems a little more random ;).  Also changed our debug code so that it doesn't output to the console when we are running in daemon mode.  The only way to get debug info while in daemon mode is to set a log file!!!
 *
 * Revision 1.7  2004/03/22 00:40:59  chessing
 *
 * Added logfile option to the global config options in the config file.  The logfile is where output will go when we are running in daemon mode.  If no logfile is defined, output will go to the console that started xsupplicant.   Added forking to the code, so that when started, the process can daemonize, and run in the background.  If there is a desire to force running in the foreground (such as for debugging), the -f option was added.
 *
 * Revision 1.6  2004/03/20 03:57:51  chessing
 *
 * A couple of small updates to xsup_monitor, and gui_interface.
 *
 * Revision 1.5  2004/03/19 23:43:56  chessing
 *
 * Lots of changes.  Changed the password prompting code to no longer require the EAP methods to maintain their own stale frame buffer.  (Frame buffer pointers should be moved out of generic_eap_data before a final release.)  Instead, EAP methods should set need_password in generic_eap_data to 1, along with the variables that identify the eap type being used, and the challenge data (if any -- only interesting to OTP/GTC at this point).  Also fixed up xsup_set_pwd.c, and got it back in CVS.  (For some reason, it was in limbo.)  Added xsup_monitor under gui_tools/cli.  xsup_monitor will eventually be a cli program that will monitor XSupplicant (running as a daemon) and display status information, and request passwords when they are not in the config.
 *
 * Revision 1.4  2004/01/20 00:07:06  chessing
 *
 * EAP-SIM fixes.
 *
 * Revision 1.3  2004/01/18 06:31:19  chessing
 *
 * A few fixes here and there.  Added support in EAP-TLS to wait for a password to be entered from a "GUI" interface.  Added a small CLI utility to pass the password in to the daemon. (In gui_tools/cli)  Made needed IPC updates/changes to support passing in of a generic password to be used.
 *
 * Revision 1.2  2004/01/15 23:45:10  chessing
 *
 * Fixed a segfault when looking for wireless interfaces when all we had was a wired interface.  Fixed external command execution so that junk doesn't end up in the processed string anymore.  Changed the state machine to call txRspAuth even if there isn't a frame to process.  This will enable EAP methods to request information from a GUI interface (such as passwords, or supply challenge information that might be needed to generate passwords).  EAP methods now must decide what to do when they are handed NULL for the pointer to the in frame.  If they don't need any more data, they should quietly exit.
 *
 * Revision 1.1  2003/12/23 04:57:10  chessing
 *
 * IPC additions, GUI client routines.
 *
 *
 *******************************************************************/
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include "gui_interface.h"

#define XSUP_SOCKET "/tmp/xsupplicant.sock"
#define DEBUG  0

char pidfileName[] = "/var/run/xsupplicant";

static int skfd;

/*******************************************************************
 *
 * Establish a handler to talk to the supplicant.
 *
 *******************************************************************/
int gui_interface_connect()
{
  int sockErr;
  struct sockaddr_un sa;

  skfd = socket(PF_UNIX, SOCK_STREAM, 0);
  if (skfd < 0)
    {
#if DEBUG
      printf("Error getting socket!\n");
#endif
      return ERR_SOCK;
    }

  strncpy(sa.sun_path, XSUP_SOCKET, sizeof(sa.sun_path)-1);
  sa.sun_family = AF_LOCAL;
  
  sockErr = connect(skfd, (struct sockaddr *)&sa, sizeof(sa));
  if (sockErr < 0) 
    {
#if DEBUG
      printf("Socket Error : %d -- %s  (%s:%d)\n", sockErr, strerror(sockErr),
	     __FUNCTION__, __LINE__);
#endif
      return errno;
    }

  return ERR_NONE;
}

/******************************************************************
 *
 * Disconnect from the daemon.
 *
 ******************************************************************/
int gui_interface_disconnect()
{
  close(skfd);
  return 0;
}

/******************************************************************
 *
 * See if we have any data.  If we aren't blocking, we will wait here
 * forever until we get something back!
 *
 ******************************************************************/
int gui_interface_get_packet(char *buffer, int *bufsize, int block)
{
  int readStat = -1;
  fd_set tset;
  struct timeval tv;
  struct ipc_header *header;

  FD_ZERO(&tset);
  FD_SET(skfd, &tset);
  tv.tv_sec = 0;
  tv.tv_usec = 0;

  if (block != 1)
    {
      readStat = select(skfd+1, &tset, NULL, NULL, &tv);
      if (readStat <= 0) return ERR_NONE;
    }

  readStat = recv(skfd, buffer, *bufsize, 0);
 
  if (readStat < 0) 
    {
      printf("Socket error : %s\n",strerror(errno));
      *bufsize = 0;
      return ERR_SOCK;
    }

  /* Make sure we have valid packet.  If we don't, then act like we didn't
     get a packet.  */
  header = (struct ipc_header *)buffer;

  if (header->version != 2)
    {
      *bufsize = 0;
      return ERR_PKT_BAD;
    }

  *bufsize = readStat;

  return ERR_NONE;
}

/******************************************************************
 *
 * Validate, and send a packet.
 *
 ******************************************************************/
int gui_interface_send_packet(char *buffer, int bufptr)
{
  struct ipc_header *header;
  int i;

  header = (struct ipc_header *)buffer;

  if (header->version != 2) return ERR_PKT_BAD;

  i=send(skfd, buffer, bufptr, 0);
  if (i < 0)
    {
      printf("Socket error! (%d : %d)\n",i, errno);
      return ERR_SOCK;
    }

  return ERR_NONE;
}

/******************************************************************
 *
 * bufptr should point to the next command record to be processed. We
 * will pull the record out, copy the data for the record in to the
 * *data, and return the value of the record we are using.
 *
 * The caller should check that *bufptr < buffer length.
 *
 ******************************************************************/
int gui_interface_parse_packet(char *buffer, int *bufptr, char *data, 
			       int *datalen, char * workint)
{
  struct ipc_header *header;
  struct ipc_cmd *cmd;
  char intname[32];

  header = (struct ipc_header *)&buffer[0];

  if (header->version != 2) 
    {
#if DEBUG
      printf("Invalid header version!\n");
#endif
      return ERR_PKT_BAD;
    }

  if (if_indextoname(header->int_idx, intname) == NULL)
    {
#if DEBUG
      printf("Invalid interface requested!  (Index : %d)\n", header->int_idx);
#endif
      return ERR_PKT_BAD;
    }

  strcpy(workint, intname);

  if (*bufptr <= 0) 
    {
      *bufptr = sizeof(struct ipc_header);
    } 

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  /* zero out the buffer, just to be safe. */
  bzero(data, cmd->len+1);

  *bufptr += sizeof(struct ipc_cmd);  /* Skip the command structure. */

  memcpy(data, (char *)&buffer[*bufptr], cmd->len);

  *datalen = cmd->len;

  return cmd->attribute;
}

/******************************************************************
 *
 * Build a header for our packet.
 *
 ******************************************************************/
int gui_interface_build_header(char *buffer, int *bufptr, char *intName, 
			       int getset)
{
  struct ipc_header *header;

  header = (struct ipc_header *)buffer;
  
  header->version = 2;
  header->int_idx = 0;
  if (intName != NULL) 
    {
      header->int_idx = if_nametoindex(intName);
    }

  *bufptr = sizeof(struct ipc_header);
  
  return ERR_NONE;
}

/*****************************************************************
 *
 * Request a list of all known interfaces.
 *
 *****************************************************************/
int gui_interface_get_interfaces(char *buffer, int *bufptr)
{
  struct ipc_cmd *cmd;

  cmd = (struct ipc_cmd *)&buffer[*bufptr];
  cmd->attribute = INTERFACES;
  cmd->getset = IPC_GET;
  cmd->len = 0;
  *bufptr += 2;

  return ERR_NONE;
}

/*****************************************************************
 *
 * Request the authentication state of an interface.
 *
 *****************************************************************/
int gui_interface_get_state(char *buffer, int *bufptr)
{
  struct ipc_cmd *cmd;

  cmd = (struct ipc_cmd *)&buffer[*bufptr];
  cmd->attribute = AUTH_STATE;
  cmd->getset = IPC_GET;;
  cmd->len = 0;
  *bufptr += sizeof(struct ipc_cmd);

  return ERR_NONE;
}

/****************************************
 *
 * Send in a password set command.
 *
 ****************************************/
int gui_interface_set_password(char *buffer, int *bufptr, char *password)
{
  struct ipc_cmd *cmd;

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  cmd->attribute = TEMPPASSWORD;
  cmd->getset = IPC_SET;
  cmd->len = strlen(password);
  *bufptr += sizeof(struct ipc_cmd);

  strcpy((char *)&buffer[*bufptr], password);
  *bufptr += strlen(password);
  
  return ERR_NONE;
}

/****************************************
 *
 * Test for a PID file, and return an error if something seems to be running.
 *
 ****************************************/
int is_xsup_running()
{
  FILE *pidfile;

  pidfile = fopen(pidfileName, "r");
  if (pidfile)
    {
      fclose(pidfile);
      return TRUE;
    }
  return FALSE;
}
