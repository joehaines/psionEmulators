/*******************************************************************
 * Card driver specific interface.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_H_
#define _CARDIF_H_

#include "../profile.h"

// Alg methods to use when doing WPA.
#define WPA_NONE 0
#define WPA_WEP  1
#define WPA_TKIP 2
#define WPA_CCMP 3

int cardif_init(struct interface_data *);
int cardif_deinit(struct interface_data *);
int cardif_get_socket(struct interface_data *);
int cardif_start_wireless_scan(struct interface_data *);
int set_wireless_key(struct interface_data *, u_char *, int, int);
void cardif_clock_tick(struct interface_data *);
void cardif_associate(struct interface_data *, void *);
int SetSSID(struct interface_data *, char *);
int GetSSID(struct interface_data *, char *);
int cardif_check_ssid(struct interface_data *);
int GetBSSID(struct interface_data *, char *);
int sendframe(struct interface_data *, char *, int);
int getframe(struct interface_data *, char *, int *);
int get_if_state(struct interface_data *);
int cardif_get_int(int, char *);
void cardif_reset_keys(struct interface_data *);
int cardif_valid_dest(struct interface_data *);
int cardif_check_dest(struct interface_data *);
int frameavail(struct interface_data *);
int cardif_validate(char *);
int cardif_int_is_wireless(char *);

#endif
