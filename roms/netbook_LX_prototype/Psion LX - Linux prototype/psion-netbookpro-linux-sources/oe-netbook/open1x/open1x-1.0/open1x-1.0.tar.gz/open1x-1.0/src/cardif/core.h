/*******************************************************************
 * The core linux event loop.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: linux_core.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CORE_H_
#define _CORE_H_

void event_core_setup();
void event_core_clock_tick(struct interface_data *);
void event_core(struct interface_data **);
void event_core_cleanup();

#endif

