/*******************************************************************
 * The core generic OS event loop.
 * File: generic_core.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: generic_core.c,v 1.1 2004/09/02 18:45:24 chessing Exp $
 * $Date: 2004/09/02 18:45:24 $
 * $Log: generic_core.c,v $
 * Revision 1.1  2004/09/02 18:45:24  chessing
 *
 * Couple small bug fixes.  Added a generic frame handler.  The new handler needs to be tested once I can get back to a place that has 802.1X on wired ports. ;)
 *
 *
 *******************************************************************/

#ifdef GENERIC_FRAMER

#include <dnet.h>
#include <pcap.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "profile.h"
#include "config.h"
#include "eap.h"
#include "statemachine.h"
#include "xsup_debug.h"
#include "xsup_err.h"
#include "eapol.h"
#include "cardif/cardif.h"
#include "cardif/core.h"

/*****************************************************************
 *
 * Do any setup that is needed for our event loop.  This is called only
 * once!  (And not once per interface.)  If you need to initalize something
 * per interface, is should either be included in cardif_init(), or using
 * some checks in event_core()!
 *
 *****************************************************************/
void event_core_setup()
{
  debug_printf(DEBUG_INT, "Called event_core_setup()!\n");
}

/*****************************************************************
 *
 * Called every time the clock ticks.  (Once per second.)
 *
 *****************************************************************/
void event_core_clock_tick(struct interface_data *intdata)
{
}

/*****************************************************************
 *
 * Do any event processing that needs to happen.  This *MUST* include
 * executing the statemachine for each interface we know of, and sending
 * and receiving of frames.
 *
 *****************************************************************/
void event_core(struct interface_data **ppintcur)
{
  int framewaiting = 0;
  struct interface_data *cur;
  
  cur = *ppintcur;

  while (cur != NULL)
    {
      debug_printf(DEBUG_EVERYTHING, "Processing interface %s...\n", cur->intName);

      if (cur->userdata == NULL)
	{
	  debug_printf(DEBUG_NORMAL, "Userdata is NULL!  We will probably have problems!\n");
	}

      eapol_execute(cur);
      
      // If we have a frame available on any interface, we won't
      // sleep.  Instead we will keep looping through to keep things
      // moving as fast as possible.
      if (frameavail(cur) == TRUE) framewaiting = 1;
      cur = cur->next;
    }

  if (framewaiting == 0)
    {
      usleep(500000);
    }
  framewaiting = 0;
}

/******************************************************************
 *
 * Clean up anything that we initialized in event_core_setup().
 *
 ******************************************************************/
void event_core_cleanup()
{
  debug_printf(DEBUG_INT, "Called event_core_cleanup()!\n");
}

#endif
