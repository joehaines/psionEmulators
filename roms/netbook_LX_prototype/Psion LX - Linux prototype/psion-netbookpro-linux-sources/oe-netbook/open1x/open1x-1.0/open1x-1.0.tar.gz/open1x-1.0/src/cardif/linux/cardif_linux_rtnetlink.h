/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_linux_rtnetlink.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_LINUX_RTNETLINK_H_
#define _CARDIF_LINUX_RTNETLINK_H_

void cardif_linux_rtnetlink_init();
void cardif_linux_rtnetlink_cleanup();
void cardif_linux_rtnetlink_check_event(struct interface_data **);
void cardif_linux_rtnetlink_do_link(struct interface_data **,
				    struct nlmsghdr *, int, int);
void cardif_linux_rtnetlink_ifla_ifname(struct interface_data **, int, int);
void cardif_linux_rtnetlink_ifla_wireless();
void cardif_linux_rtnetlink_do_newlink(struct interface_data **,
				       struct nlmsghdr *, int);
void cardif_linux_rtnetlink_do_dellink(struct interface_data **,
				       struct nlmsghdr *, int);

#endif
