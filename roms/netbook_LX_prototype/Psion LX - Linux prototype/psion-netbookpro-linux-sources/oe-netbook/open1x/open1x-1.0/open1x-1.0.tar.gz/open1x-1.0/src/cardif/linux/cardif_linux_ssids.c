/*******************************************************************
 * File: cardif_linux_ssids.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: cardif_linux_ssids.c,v 1.11 2004/09/18 04:41:32 chessing Exp $
 * $Date: 2004/09/18 04:41:32 $
 * $Log: cardif_linux_ssids.c,v $
 * Revision 1.11  2004/09/18 04:41:32  chessing
 * Fixes for TTLS-MSCHAPv2 for bugs found by Chris Zimmerman.  Also, a couple of small updates to try to get IPC back to where it needs to be.
 *
 * Revision 1.10  2004/09/02 18:45:25  chessing
 *
 * Couple small bug fixes.  Added a generic frame handler.  The new handler needs to be tested once I can get back to a place that has 802.1X on wired ports. ;)
 *
 * Revision 1.9  2004/09/02 17:17:23  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.8  2004/08/30 03:13:45  chessing
 *
 * Some small changes.  We no longer generate the cardif library.  (It was a good idea that didn't turn out as planned. ;)
 *
 * Revision 1.7  2004/08/27 20:56:00  chessing
 * Some bug fixes, and more work toward getting WPA working.
 *
 * Revision 1.6  2004/08/19 02:28:07  chessing
 * First piece of WPA patch.  (The patch is growing fast, and this commit is to save what is done so far.)
 *
 * Revision 1.5  2004/08/16 23:36:28  chessing
 * Cosmetic fixes and trapping of an error that popped up.
 *
 * Revision 1.4  2004/08/16 01:56:44  chessing
 *
 * A few more updates to last nights patch.
 *
 * Revision 1.3  2004/08/15 04:29:35  chessing
 *
 * Completed support for scanning and joining wireless networks.  If your interface isn't configured, we will scan to gather information about all known wireless networks.  If a network in the list has a configuration, we will join it.  (Including turning on needed encryption.)  There are still a few rough edges that need to be hammered out.  But the overall user experience should be improved.
 *
 * Revision 1.2  2004/08/12 01:40:06  chessing
 *
 * Added "association" option to the global configuration file sections.  It can be set to either auto, or manual.  Setting "association" to auto means that XSupplicant will attempt to associate to a network with the lowest value in the "priority" setting.  The default for "association" is auto.  The other option added is "priority" which is a numeric value from 1..256.  A value of 1 is the highest priority, and will be the first network chosen.  (Assuming the network can be found in a scan.)  The default value for "priority" is 0, which means that network will be checked last.   --  Although the options are now in the config file, the actual functionality for auto association/priority is not yet complete.  (So, basically these options don't do anything yet. ;)
 *
 * Revision 1.1  2004/08/05 23:56:21  chessing
 *
 * Added basic support for scanning for broadcast SSIDs.  This is another step closer to WPA/11i support. ;)
 *
 *
 *******************************************************************/

#ifdef LINUX_FRAMER

#include <string.h>
#include <strings.h>

#include "profile.h"
#include "config.h"
#include "cardif/cardif.h"
#include "xsup_debug.h"
#include "xsup_err.h"
#include "cardif/linux/cardif_linux_ssids.h"

/*******************************************************************
 *
 * Dump everything we know about the SSIDs in our catalog.
 *
 *******************************************************************/
void cardif_linux_ssids_dump(struct interface_data *intdata)
{
  struct ssids_list *curlist;

  debug_printf(DEBUG_INT, "Dumping SSID information structure.\n");

  curlist = (struct ssids_list *)intdata->ssid_list;

  while (curlist != NULL)
    {
      debug_printf(DEBUG_INT, "SSID : %s    Flags : %02X\n",
		   curlist->ssidName, curlist->flags);
      
      curlist = curlist->next;
    }
}

/*******************************************************************
 *
 * Clear out EVERYTHING that is included in the SSID list.
 *
 *******************************************************************/
void cardif_linux_ssids_clear(struct interface_data *intdata)
{
  struct ssids_list *curlist, *toclear;

  curlist = (struct ssids_list *)intdata->ssid_list;

  if (curlist == NULL)
    {
      debug_printf(DEBUG_EVERYTHING, "No SSIDs to clear!\n");
      return;
    }

  while (curlist != NULL)
    {
      toclear = curlist;
      curlist = curlist->next;

      if (toclear->ssidName != NULL)
	{
	  free(toclear->ssidName);
	  toclear->ssidName = NULL;
	}

      toclear->flags = 0;
      free(toclear);
    }

  intdata->ssid_list = NULL;
}

/*******************************************************************
 *
 * Add an SSID to the list.  (We will check to make sure that it doesn't
 * exist first.)
 *
 *******************************************************************/
void cardif_linux_ssids_add(struct interface_data *intdata, char *ssidName,
			    unsigned char flags, char *wpaie, int wpaielen,
			    char *rsnie, int rsnielen)
{
  struct ssids_list *curlist;

  curlist = (struct ssids_list *)intdata->ssid_list;

  if (cardif_linux_ssids_included(intdata, ssidName) == FALSE)
    {
      if (curlist == NULL)
	{
	  // This is our first addition.  So, it will be slightly different.
	  intdata->ssid_list = (void *)malloc(sizeof(struct ssids_list));
	  if (intdata->ssid_list == NULL)
	    {
	      debug_printf(DEBUG_EVERYTHING, "Memory allocation error!\n");
	      return;
	    }
	  curlist = (struct ssids_list *)intdata->ssid_list;
	} else {
	  // Find the end of the list, and work from there.
	  while (curlist->next != NULL)
	    {
	      curlist = curlist->next;
	    }

	  curlist->next = (struct ssids_list *)malloc(sizeof(struct ssids_list));
	  if (curlist->next == NULL)
	    {
	      debug_printf(DEBUG_EVERYTHING, "Memory allocation error!\n");
	      return;
	    }

	  curlist = curlist->next;
	}

      curlist->ssidName = (char *)malloc(strlen(ssidName)+1);
      if (curlist->ssidName == NULL)
	{
	  debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for curlist->ssidName in %s!\n", __FUNCTION__);
	  curlist->flags = 0;
	  curlist->next = NULL;
	  return;
	}

      bzero(curlist->ssidName, strlen(ssidName)+1);

      strcpy(curlist->ssidName, ssidName);
      curlist->flags = flags;

      if (wpaie != NULL)
	{
	  curlist->wpa_ie_len = wpaielen;
	  curlist->wpa_ie = (char *)malloc(wpaielen);
	  if (curlist->wpa_ie == NULL)
	    {
	      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for curlist->wpa_ie in %s!\n", __FUNCTION__);
	      return;
	    }

	  bzero(curlist->wpa_ie, wpaielen);
	  memcpy(curlist->wpa_ie, wpaie, wpaielen);
	  debug_printf(DEBUG_INT, "WPA IE = ");
	  debug_hex_printf(DEBUG_INT, curlist->wpa_ie, curlist->wpa_ie_len);
	}

      if (rsnie != NULL)
	{
	  curlist->rsn_ie_len = rsnielen;
	  curlist->rsn_ie = (char *)malloc(rsnielen);
	  if (curlist->rsn_ie == NULL)
	    {
	      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for curlist->rsn_ie in %s!\n", __FUNCTION__);
	      return;
	    }

	  bzero(curlist->rsn_ie, rsnielen);
	  memcpy(curlist->rsn_ie, rsnie, rsnielen);
	  debug_printf(DEBUG_INT, "RSN IE = ");
	  debug_hex_printf(DEBUG_INT, curlist->rsn_ie, curlist->rsn_ie_len);
	}

      curlist->next = NULL;
    }
}

/*******************************************************************
 *
 * Get information about the wireless network we are using.
 *
 *******************************************************************/
struct ssids_list *cardif_linux_ssids_find(struct interface_data *intdata)
{
  struct ssids_list *curlist;

  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed to %s!\n", __FUNCTION__);
      return NULL;
    }

  if (intdata->cur_essid == NULL)
    {
      debug_printf(DEBUG_INT, "No valid SSID currently known!\n");
      return NULL;
    }

  curlist = (struct ssids_list *)intdata->ssid_list;

  while ((curlist != NULL) && (strcmp(intdata->cur_essid, curlist->ssidName) == 0))
    {
      curlist = curlist->next;
    }

  return curlist;
}

/*******************************************************************
 *
 * Check to see if the SSID named is already included in our list.
 * Return TRUE if it is, FALSE if it isn't.
 *
 *******************************************************************/
int cardif_linux_ssids_included(struct interface_data *intdata, char *ssidName)
{
  struct ssids_list *curlist = NULL;

  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid interface data passed in to cardif_linux_ssids_included()!\n");
      return TRUE;
    }

  if (ssidName == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid ssidName in %s!\n", __FUNCTION__);
      return TRUE;
    }

  curlist = (struct ssids_list *)intdata->ssid_list;

  if (curlist == NULL) return FALSE;  

  while ((curlist != NULL) && (curlist->ssidName != NULL) &&
	 (strcmp(ssidName, curlist->ssidName) != 0))
    {
      curlist = curlist->next;
    }

  if ((curlist != NULL) && (curlist->ssidName != NULL) &&
      (strcmp(ssidName, curlist->ssidName) == 0))
    {
      debug_printf(DEBUG_EVERYTHING, "The SSID was already in the list!\n");
      return TRUE;
    } else {
      debug_printf(DEBUG_EVERYTHING, "The SSID was NOT already in the list!\n");
      return FALSE;
    }
}

/************************************************************************
 *
 *  A scan was completed, and we have some data about the SSIDs/APs that we
 *  can see.  So, find the SSID with the best priority and try to 
 *  associate to it.
 *
 ************************************************************************/
void cardif_linux_ssids_join_network(struct interface_data *intdata)
{
  struct ssids_list *best_choice=NULL, *curlist, *zero_choice=NULL;
  int priority, highpri = 257;

  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid interface data passed in to %s!\n",
		   __FUNCTION__);

      // Clear the scan done flag.
      intdata->flags &= (~SCAN_DONE);
      return;
    }

  curlist = (struct ssids_list *)intdata->ssid_list;

  if (curlist == NULL) 
    {
      intdata->flags &= (~SCAN_DONE);
      return;  
    }

  while (curlist != NULL)
    {
      priority = config_get_priority(curlist->ssidName);

      if (priority == 0)
	{
	  if (zero_choice == NULL)
	    {
	      zero_choice = curlist;
	    }
	} else if (priority < highpri)
	  {
	    highpri = priority;
	    best_choice = curlist;
	    debug_printf(DEBUG_INT, "Highest priority = %d with ESSID = %s\n",
			 highpri, best_choice->ssidName);
	  }

      curlist = curlist->next;
    }

  if (best_choice == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No valid configurations for found networks!\n");
      intdata->flags &= (~SCAN_DONE);

      return;
    } else {
      if (!config_get_association())
	{
	  debug_printf(DEBUG_NORMAL, "Found configuration data for network %s.  Attempting to associate!\n",
		       best_choice->ssidName);
	} else {
	  debug_printf(DEBUG_INT, "Best wireless network is %s!\n", 
		       best_choice->ssidName);
	}
    }

  // Otherwise, attempt to associate.
  intdata->flags &= (~SCAN_DONE);

  if (!config_get_association()) 
    {
      debug_printf(DEBUG_INT, "Attempting to associate.\n");
      cardif_associate(intdata, best_choice);
    } else {
      debug_printf(DEBUG_INT, "Association is set to manual!\n");
    }
}

#endif
