/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_linux_ssids.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_LINUX_SSIDS_H_
#define _CARDIF_LINUX_SSIDS_H_

struct ssids_list {
  // The name of the SSIDs we see.  (We don't care about BSSIDs for now.)
  char *ssidName;

  // Mostly used for tracking what the AP can do.  (Such as support for
  // WPA, RSN, and other IEs.)
  unsigned char flags;

  // These are the location we will store the IE that the AP provides us.
  char *wpa_ie;
  unsigned char wpa_ie_len;
  char *rsn_ie;
  unsigned char rsn_ie_len;

  // And the actual flags.
  #define MANAGED   0x01   // Is this a managed network?
  #define WEP       0x02
  #define WPA_IE    0x04
  #define RSN_IE    0x08

  struct ssids_list *next;
};

void cardif_linux_ssids_dump(struct interface_data *);
void cardif_linux_ssids_clear(struct interface_data *);
void cardif_linux_ssids_add(struct interface_data *, char *, unsigned char,
			    char *, int, char *, int);
int cardif_linux_ssids_included(struct interface_data *, char *);
void cardif_linux_ssids_join_network(struct interface_data *);
struct ssids_list *cardif_linux_ssids_find(struct interface_data *);
#endif
