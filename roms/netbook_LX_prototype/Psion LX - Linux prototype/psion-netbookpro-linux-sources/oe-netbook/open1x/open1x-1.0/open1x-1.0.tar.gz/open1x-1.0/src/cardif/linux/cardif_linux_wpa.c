/*******************************************************************
 * File: cardif_linux_wpa.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: cardif_linux_wpa.c,v 1.7 2004/09/04 01:02:39 chessing Exp $
 * $Date: 2004/09/04 01:02:39 $
 * $Log: cardif_linux_wpa.c,v $
 * Revision 1.7  2004/09/04 01:02:39  chessing
 * A few fixes to the WPA code.  We now attempt to set the key.
 *
 * Revision 1.6  2004/09/02 18:45:25  chessing
 *
 * Couple small bug fixes.  Added a generic frame handler.  The new handler needs to be tested once I can get back to a place that has 802.1X on wired ports. ;)
 *
 * Revision 1.5  2004/09/02 17:17:23  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.4  2004/08/30 03:13:45  chessing
 *
 * Some small changes.  We no longer generate the cardif library.  (It was a good idea that didn't turn out as planned. ;)
 *
 * Revision 1.3  2004/08/20 04:42:28  chessing
 * Set all of the new scanning and WPA code to be disabled by default, so that a 1.0.1 release can be made.  Added additional error message output to AKA code.  Fixed a few memory leaks in the AKA code.
 *
 * Revision 1.2  2004/08/19 02:33:31  chessing
 * A few follow-ups from the last patch.
 *
 * Revision 1.1  2004/08/19 02:28:07  chessing
 * First piece of WPA patch.  (The patch is growing fast, and this commit is to save what is done so far.)
 *
 *
 *******************************************************************/
#ifdef LINUX_FRAMER

#include "xsup_debug.h"
#include "profile.h"
#include "config.h"
#include "cardif/linux/wpa_hostap_driver.h"

int cardif_linux_wpa_set_wpa_ie(struct interface_data *intdata, char *wpa_ie, 
				int wpa_ie_len)
{
#ifdef EXPERIMENTAL
  debug_printf(DEBUG_NORMAL, "Called %s!\n", __FUNCTION__);
  return wpa_hostap_driver_set_wpa_ie(intdata->intName, wpa_ie, wpa_ie_len);
#else
  return 0;
#endif
}

int cardif_linux_wpa_enable(struct interface_data *intdata)
{
#ifdef EXPERIMENTAL
  debug_printf(DEBUG_NORMAL, "Called %s!\n", __FUNCTION__);
  return wpa_hostap_driver_wpa_enable(intdata->intName);
#else
  return 0;
#endif
}

int cardif_linux_wpa_disable(struct interface_data *intdata)
{
#ifdef EXPERIMENTAL
  debug_printf(DEBUG_NORMAL, "Called %s!\n", __FUNCTION__);
  return wpa_hostap_driver_wpa_disable(intdata->intName);
#else
  return 0;
#endif
}

int cardif_linux_wpa_set_key(struct interface_data *intdata, int alg, 
			     unsigned char *addr, int key_idx, int set_tx, 
			     char *seq, int seq_len, char *key, int key_len)
{
#ifdef EXPERIMENTAL
  return wpa_hostap_driver_set_key(intdata->intName, alg, addr, key_idx,
				   set_tx, seq, seq_len, key, key_len);
#else
  return 0;
#endif
}

#endif
