/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_linux_wpa.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_LINUX_WPA_H_
#define _CARDIF_LINUX_WPA_H_

int cardif_linux_wpa_set_wpa_ie(struct interface_data *, char *, int);
int cardif_linux_wpa_enable(struct interface_data *);
int cardif_linux_wpa_disable(struct interface_data *);
int cardif_linux_wpa_set_key(struct interface_data *, int, unsigned char *,
			     int, int, char *, int, char *, int);
#endif
