/*******************************************************************
 * File: wpa_hostap_driver.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: wpa_hostap_driver.c,v 1.10 2004/09/09 23:11:37 chessing Exp $
 * $Date: 2004/09/09 23:11:37 $
 * $Log: wpa_hostap_driver.c,v $
 * Revision 1.10  2004/09/09 23:11:37  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.9  2004/09/09 04:26:53  chessing
 *
 * Fixed a problem with the MIC code.  We now get to sending the 4th packet of the handshake, and we apply the key.  For some reason, we don't get the first packet of the GTK exchange.  (But, getting closer! ;)
 *
 * Revision 1.8  2004/09/04 01:02:39  chessing
 * A few fixes to the WPA code.  We now attempt to set the key.
 *
 * Revision 1.7  2004/09/02 18:45:25  chessing
 *
 * Couple small bug fixes.  Added a generic frame handler.  The new handler needs to be tested once I can get back to a place that has 802.1X on wired ports. ;)
 *
 * Revision 1.6  2004/09/02 17:17:23  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.5  2004/08/30 03:13:45  chessing
 *
 * Some small changes.  We no longer generate the cardif library.  (It was a good idea that didn't turn out as planned. ;)
 *
 * Revision 1.4  2004/08/20 04:42:28  chessing
 * Set all of the new scanning and WPA code to be disabled by default, so that a 1.0.1 release can be made.  Added additional error message output to AKA code.  Fixed a few memory leaks in the AKA code.
 *
 * Revision 1.3  2004/08/19 04:11:48  chessing
 * More updates to get closer to WPA support.  We can now associate to an AP that has WPA, however we are using a static WPA IE, so that needs to be fixed.  There is also still a fair bit of other things that need to be cleaned up, but we are closer.
 *
 * Revision 1.2  2004/08/19 02:33:31  chessing
 * A few follow-ups from the last patch.
 *
 * Revision 1.1  2004/08/19 02:28:07  chessing
 * First piece of WPA patch.  (The patch is growing fast, and this commit is to save what is done so far.)
 *
 *
 *******************************************************************/

#ifdef LINUX_FRAMER
#ifdef EXPERIMENTAL

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/wireless.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>

typedef uint64_t u64;
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;
typedef int64_t s64;
typedef int32_t s32;
typedef int8_t s8;

#include "xsup_debug.h"
#include "xsup_err.h"
#include "cardif/cardif.h"
#include "cardif/linux/ieee80211_crypto.h"
#include "cardif/linux/ieee80211_ioctl.h"
#include "cardif/linux/hostap_common.h"

char generic_wpa_ie[24] = {0xdd, 0x16, 0x00, 0x50, 0xf2, 0x01, 0x01, 0x00,
			   0x00, 0x50, 0xf2, 0x02, 0x01, 0x00, 0x00, 0x50, 
			   0xf2, 0x02, 0x01, 0x00, 0x00, 0x50, 0xf2, 0x02};

// Taken from wpa_supplicant.
static int hostapd_ioctl(const char *dev, struct prism2_hostapd_param *param,
			 int len, int show_err)
{
	int s;
	struct iwreq iwr;

	s = socket(PF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		debug_printf(DEBUG_NORMAL, "socket");
		return -1;
	}

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, dev, IFNAMSIZ);
	iwr.u.data.pointer = (caddr_t) param;
	iwr.u.data.length = len;

	if (ioctl(s, PRISM2_IOCTL_HOSTAPD, &iwr) < 0) {
		int ret;
		close(s);
		ret = errno;
		if (show_err) 
			debug_printf(DEBUG_NORMAL, "ioctl[PRISM2_IOCTL_HOSTAPD] %s\n", strerror(ret));
		return ret;
	}
	close(s);

	return 0;
}

// Taken from WPA supplicant.
static int
set80211param(const char *dev, int op, int arg, int show_err)
{
        struct iwreq iwr;
	int sd;

	sd = socket(PF_INET, SOCK_DGRAM, 0);
	if (sd < 0)
	  {
	    debug_printf(DEBUG_NORMAL, "Couldn't allocate socket in %s!\n",
			 __FUNCTION__);
	    return -1;
	  }

        memset(&iwr, 0, sizeof(iwr));
        strncpy(iwr.ifr_name, dev, 16);
        iwr.u.mode = op;
        memcpy(iwr.u.name+sizeof(unsigned int), &arg, sizeof(arg));

        if (ioctl(sd, IEEE80211_IOCTL_SETPARAM, &iwr) < 0) {
                if (show_err)
                        debug_printf(DEBUG_NORMAL, "ioctl[IEEE80211_IOCTL_SETPARAM]\n");
                return -1;
        }
        return 0;
}

// Taken from WPA supplicant
int wpa_hostap_driver_set_wpa_ie(const char *ifname, const char *wpa_ie,
				 size_t wpa_ie_len)
{
	struct prism2_hostapd_param *param;
	int res;
	//	size_t blen = PRISM2_HOSTAPD_GENERIC_ELEMENT_HDR_LEN + wpa_ie_len;
	size_t blen = PRISM2_HOSTAPD_GENERIC_ELEMENT_HDR_LEN + 24;
	if (blen < sizeof(*param))
		blen = sizeof(*param);

	param = (struct prism2_hostapd_param *) malloc(blen);
	if (param == NULL)
		return -1;

	memset(param, 0, blen);
	param->cmd = PRISM2_HOSTAPD_SET_GENERIC_ELEMENT;
	//	param->u.generic_elem.len = wpa_ie_len;
	//	memcpy(param->u.generic_elem.data, wpa_ie, wpa_ie_len);
	param->u.generic_elem.len = 24;
	memcpy(param->u.generic_elem.data, generic_wpa_ie, 24);
	res = hostapd_ioctl(ifname, param, blen, 1);

	free(param);

	return res;
}

int wpa_hostap_driver_wpa_enable(char *intname)
{
  if (set80211param(intname, IEEE80211_PARAM_ROAMING, 1, 1) < 0)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't enable roaming on interface %s!\n",
		   intname);
    }

  if (set80211param(intname, IEEE80211_PARAM_PRIVACY, 1, 1) < 0)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't enable privacy on interface %s!\n",
		   intname);
    }

  if (set80211param(intname, IEEE80211_PARAM_WPA, 1, 1) < 0)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't enable WPA on interface %s!\n",
		   intname);
    }

  if (set80211param(intname, IEEE80211_PARAM_COUNTERMEASURES, 1, 1) < 0)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't enable counter measures for interface %s!\n",
		   intname);
    }

  if (set80211param(intname, IEEE80211_PARAM_DROPUNENCRYPTED, 1, 1) < 0)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't enable \"drop unencrypted packets\" on interface %s!\n",
		   intname);
    }

  return XENONE;
}

int wpa_hostap_driver_wpa_disable(char *intname)
{
  return XENONE;
}

// Taken from wpa_supplicant.
static void show_set_key_error(struct prism2_hostapd_param *param)
{
	switch (param->u.crypt.err) {
	case HOSTAP_CRYPT_ERR_UNKNOWN_ALG:
		debug_printf(DEBUG_NORMAL, "Unknown algorithm '%s'.",
			     param->u.crypt.alg);
		debug_printf(DEBUG_NORMAL, "You may need to load kernel module to "
			   "register that algorithm.");
		debug_printf(DEBUG_NORMAL, "E.g., 'modprobe hostap_crypt_wep' for "
			   "WEP.");
		break;
	case HOSTAP_CRYPT_ERR_UNKNOWN_ADDR:
		debug_printf(DEBUG_NORMAL, "Unknown address " MACSTR ".",
			   MAC2STR(param->sta_addr));
		break;
	case HOSTAP_CRYPT_ERR_CRYPT_INIT_FAILED:
		debug_printf(DEBUG_NORMAL, "Crypt algorithm initialization failed.");
		break;
	case HOSTAP_CRYPT_ERR_KEY_SET_FAILED:
		debug_printf(DEBUG_NORMAL, "Key setting failed.");
		break;
	case HOSTAP_CRYPT_ERR_TX_KEY_SET_FAILED:
		debug_printf(DEBUG_NORMAL, "TX key index setting failed.");
		break;
	case HOSTAP_CRYPT_ERR_CARD_CONF_FAILED:
		debug_printf(DEBUG_NORMAL, "Card configuration failed.");
		break;
	default:
	  debug_printf(DEBUG_NORMAL, "Unknown error (%d)\n", param->u.crypt.err);
	  break;
	}
}

int wpa_hostap_driver_set_key(char *intname, int alg, unsigned char *addr,
			      int key_idx, int set_tx, char *seq, int seq_len,
			      char *key, int key_len)
{
  struct prism2_hostapd_param *param;
  int blen;
  int ret = XENONE;
  char *buf;
  char *alg_name;

  switch (alg)
    {
    case WPA_NONE:
      alg_name = "none";
      break;

    case WPA_WEP:
      alg_name = "WEP";
      break;

    case WPA_TKIP:
      alg_name = "TKIP";
      break;

    case WPA_CCMP:
      alg_name = "CCMP";
      break;
      
    default:
      debug_printf(DEBUG_NORMAL, "Invalid encryption type requested! (%d)\n",
		   alg);
      return -1;
    }

  debug_printf(DEBUG_NORMAL, "alg=%s  key_idx=%d set_tx=%d seq_len=%d key_len=%d\n", alg_name, key_idx, set_tx, seq_len, key_len);

  debug_printf(DEBUG_NORMAL, "KeyRSC = ");
  debug_hex_printf(DEBUG_NORMAL, seq, seq_len);

  if (seq_len > 8)
    {
      debug_printf(DEBUG_NORMAL, "seq_len > 8!\n");
      return -1;
    }

  blen = sizeof(*param) + key_len;
  buf = malloc(blen);
  if (buf == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory! (%s:%d)\n",
		   __FUNCTION__, __LINE__);
      return -1;
    }

  bzero(buf, blen);

  param = (struct prism2_hostapd_param *)buf;
  param->cmd = PRISM2_SET_ENCRYPTION;

  memset(param->sta_addr, 0xff, ETH_ALEN);

  strncpy(param->u.crypt.alg, alg_name, HOSTAP_CRYPT_ALG_NAME_LEN);
  param->u.crypt.flags = set_tx ? HOSTAP_CRYPT_FLAG_SET_TX_KEY : 0;
  param->u.crypt.idx = key_idx;
  memcpy(param->u.crypt.seq, seq, seq_len);
  param->u.crypt.key_len = key_len;
  memcpy((u8 *)(param+1), key, key_len);

  if (hostapd_ioctl(intname, param, blen, 1))
    {
      debug_printf(DEBUG_NORMAL, "Unable to set encryption key! (%s:%d)\n",
		   __FUNCTION__, __LINE__);
      show_set_key_error(param);
      ret = -1;
    }

  free(buf);

  return ret;
}

#endif
#endif
