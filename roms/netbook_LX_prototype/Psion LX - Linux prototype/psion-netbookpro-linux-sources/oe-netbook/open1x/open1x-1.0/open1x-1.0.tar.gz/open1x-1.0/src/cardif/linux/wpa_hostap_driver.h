/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: wpa_hostap_driver.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _WPA_HOSTAP_DRIVER_H_
#define _WPA_HOSTAP_DRIVER_H_

int wpa_hostap_driver_set_wpa_ie(char *, char *, int);
int wpa_hostap_driver_wpa_enable(char *);
int wpa_hostap_driver_wpa_disable(char *);
int wpa_hostap_driver_set_key(char *, int, unsigned char *, int, int, char *,
			      int, char *, int);

#endif
