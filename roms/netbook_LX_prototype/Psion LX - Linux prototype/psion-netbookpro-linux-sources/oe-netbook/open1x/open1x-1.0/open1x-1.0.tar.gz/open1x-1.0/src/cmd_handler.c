/*******************************************************************
 * cmd_handler.c - Handle execution of external programs, with variable
 *                 subsitituions where needed.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: cmd_handler.c,v 1.9 2004/09/02 17:17:21 chessing Exp $
 * $Date: 2004/09/02 17:17:21 $
 * $Log: cmd_handler.c,v $
 * Revision 1.9  2004/09/02 17:17:21  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.8  2004/08/13 04:20:00  chessing
 *
 * Accepted fork() patch from i3keba.  (Slightly modified version of patch.)
 *
 * Revision 1.7  2004/07/27 01:04:39  chessing
 * Small update to the patch to fix execution of commands.
 *
 * Revision 1.6  2004/07/26 18:53:35  chessing
 * Added patch submitted by mjrider to fix problem where commands weren't always executed correctly.
 *
 * Revision 1.5  2004/06/17 22:56:58  chessing
 *
 * Fixed the problem where an attempt to execute an invalid program would result in a second instance of XSupplicant running.  (Which would then cause all kinds of interesting problems. ;)  Also added a bunch of additional debugging to the TLS code to try to resolve the strange stalls that sometimes happen in authentications that use TLS for phase 1.
 *
 * Revision 1.4  2004/06/15 03:22:16  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "config.h"
#include "profile.h"
#include "cmd_handler.h"
#include "xsup_err.h"
#include "xsup_debug.h"

//extern int errno;

/*******************************************************************
 *
 * Find all places that we have a %i, and replace it with the current
 * interface name.
 *
 *******************************************************************/
int cmd_handler_do_int(struct interface_data *intdata, char *cmdin, 
			char *cmdout)
{
  char *str1, *str2, intname[16];

  if (cmdin == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No command to execute!\n");
      return XENONE;
    }

  if (cmdout == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No response buffer available in cmd_handler_do_int()!\n");
      return XEMALLOC;
    }

  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No valid interface data in cmd_handler_do_int()!\n");
      return XEMALLOC;
    }

  // First, copy our string to cmdout.  This is where we will work with it.
  strcpy(cmdout, cmdin);

  // We make use of intdata->intName in the loop below, make sure it is valid!
  if (intdata->intName == NULL)
    {
      debug_printf(DEBUG_NORMAL, "intdata->intName is NULL in cmd_handler_do_int()!\n");
      return XEMALLOC;
    }

  while ((str1 = strstr(cmdout, "%i")) != NULL)
    {
      // We have a string we need to work with.  So, allocate some memory.
      // We need to allocate the length of the string, -2 (for the %i), 
      // + enough memory to stick thisint->intName in to. +1 for a NULL.

      str2 = (char *)malloc((strlen(cmdout)-2)+(strlen(intdata->intName))+1);
      if (str2 == NULL)
	{
	  debug_printf(DEBUG_NORMAL, "Couldn't allocate enough memory to process command string!\n");

	  return XEMALLOC;
	}

      bzero(str2, ((strlen(cmdout)-2)+(strlen(intdata->intName))+1));

      str1[0] = '\0';
      str1++;

      // Now, copy the first part of the string to our destination buffer.
      strncpy(str2, cmdout, strlen(cmdout));

      bzero((char *)&intname, 16);
      strcpy((char *)&intname, intdata->intName);

      // Then, cat the interface name on.
      strcat(str2, (char *)&intname);

      // And cat that on.
      strcat(str2, (char *)&str1[1]);

      // And copy it all back to cmdout.
      bzero(cmdout, strlen(str2)+1);
      strcpy(cmdout, str2);

      // And free str2
      free(str2);
      str2 = NULL;
    }

  return XENONE;
}


/*******************************************************************
 *
 *  This function expands the command variables that we can have in the
 * config file.   Things such as %i for interface.  (And, others later
 * on.)
 *
 *******************************************************************/
int cmd_handler_subst(struct interface_data *intdata, char *cmd_to_exec,
		      char *expanded_cmd_to_exec)
{
  int retval;

  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No valid interface data provided in cmd_handler_subst()!\n");
      return XEMALLOC;
    }

  if (cmd_to_exec == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Nothing to do in cmd_handler_subst()!\n");
      return XENONE;
    }

  if (expanded_cmd_to_exec == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No available buffer in cmd_handler_subst()!\n");
      return XEMALLOC;
    }

  debug_printf(DEBUG_EVERYTHING, "Processing command : %s\n",cmd_to_exec);

  // Now, process the command.
  retval = cmd_handler_do_int(intdata, cmd_to_exec, expanded_cmd_to_exec);
  if (retval != XENONE) return retval;

  debug_printf(DEBUG_EVERYTHING, "Returning command : %s\n",expanded_cmd_to_exec);

  return XENONE;
}

/*******************************************************************
 *
 * This is the function that should be called when we need to execute some
 * kind of a program outside of the normal functioning of XSupplicant.
 * Programs that could be executed include dhcp client daemons, VPN
 * connections, etc.  (Large chunks of this code is from the original
 * XSupplicant codebase.  Not sure if it was written by Nick, or Bryan.)
 *
 *******************************************************************/
int cmd_handler_exec(struct interface_data *intdata, char *cmd_to_exec)
{
  char *execme;
  char *args[255];
  char *p;
  int index = 0;
  int i;
  int retval;
  int pid;

  if (!cmd_to_exec) return -1;
  if (intdata == NULL)
    {
      debug_printf(DEBUG_NORMAL, "No interface data provided in cmd_handler_exec()!\n");
      return XEMALLOC;
    }
  execme = (char *)malloc(255*sizeof(char));
	if(execme == NULL){
		debug_printf(DEBUG_NORMAL,"Malloc failed");
		return XEMALLOC;
	}

  cmd_handler_subst(intdata, cmd_to_exec, execme);

  p = strtok(execme, " ");
  args[index++] = strdup(p);
  while (p && (p = strtok(NULL, " ")) != NULL && index < 10) {
    args[index++] = strdup(p);
  }
  args[index] = NULL;
  debug_printf(DEBUG_EVERYTHING, "Actual command being called is %s\n",execme);

  // Fork, so we don't die when we call this program.
  pid = fork();

  if (pid == 0)
    {
      // We are the child, so execute the command.
      retval = execvp(execme, args);

      if (retval < 0)
	{
	  // We got an error.
	  debug_printf(DEBUG_NORMAL, "Couldn't execute command : %s\n", execme);
	  debug_printf(DEBUG_NORMAL, "Error was:%s\n",strerror(errno));
	  exit(EXIT_FAILURE);
	}
    } else {
	// We are the parent, do nothing. Just wait
	wait(NULL);
      retval = 0;
    }

  for (i = 0; i < index; i++) {
    free(args[i]);
  }
  free(execme);
  return  retval  == -1? retval : 0;
}
