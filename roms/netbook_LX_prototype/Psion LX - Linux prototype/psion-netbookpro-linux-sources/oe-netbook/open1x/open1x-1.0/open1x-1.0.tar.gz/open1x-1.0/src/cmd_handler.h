/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CMD_HANDLER_H_
#define _CMD_HANDLER_H_

int cmd_handler_exec(struct interface_data *, char *);

#endif
