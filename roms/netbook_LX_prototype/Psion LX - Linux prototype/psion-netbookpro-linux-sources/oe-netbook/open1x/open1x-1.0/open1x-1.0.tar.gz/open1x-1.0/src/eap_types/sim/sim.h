/*******************************************************************
 * EAPOL Function implementations for supplicant
 * 
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: sim.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

/*******************************************************************
 *
 * The development of the EAP/SIM support was funded by Internet
 * Foundation Austria (http://www.nic.at/ipa)
 *
 *******************************************************************/

#ifdef EAP_SIM_ENABLE

#ifndef _SIM_H_
#define _SIM_H_

#include "profile.h"
#include "eapsim.h"

int sim_build_start(struct eaptypedata *, u_char *, int *);
int sim_build_fullauth(char *, u_char *, int *, u_char *, int *);
int sim_at_version_list(char *, struct eaptypedata *, u_char *, int *, 
			u_char *, int *);
int sim_do_at_mac(struct generic_eap_data *, struct eaptypedata *, u_char *, 
		  int, int *, u_char *, int *, char *);
int sim_do_v1_response(struct generic_eap_data *, char *, int *, char *, 
		       char *);
int sim_do_at_rand(struct eaptypedata *, char *, char *, u_char *, int *,
		   u_char *, int *, char *);
int sim_skip_not_implemented(u_char *, int *);

#endif

#endif
