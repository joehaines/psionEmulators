/*******************************************************************
 * 
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 * 
 * File: simd11.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

/*******************************************************************
 *
 * The development of the EAP/SIM support was funded by Internet
 * Foundation Austria (http://www.nic.at/ipa)
 *
 *******************************************************************/


#ifndef SIMD11_H_
#define SIMD11_H_

int do_v1_at_mac(struct generic_eap_data *, char *, char *, int, int, char *, char *, int, uint16_t, char *);

#endif

