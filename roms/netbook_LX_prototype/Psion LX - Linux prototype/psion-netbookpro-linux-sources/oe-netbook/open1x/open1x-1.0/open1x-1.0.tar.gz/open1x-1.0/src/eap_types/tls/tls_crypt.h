/*******************************************************************
 * TLS En/Decrypt Function header
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: tls_crypt.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _TLS_CRYPT_H_
#define _TLS_CRYPT_H_

#include "../../profile.h"

int tls_crypt_decrypt(struct generic_eap_data *, u_char *, int, u_char *, int *);
int tls_crypt_encrypt(struct generic_eap_data *, u_char *, int, u_char *, int *);
char *tls_crypt_gen_keyblock(struct generic_eap_data *, char *, int);
int tls_crypt_encrypt_nolen(struct generic_eap_data *, u_char *, int, u_char *, int *);
#endif
