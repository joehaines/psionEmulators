/*******************************************************************
 * Handle keying for type 1 (RC4, non-TKIP) EAPOL Keys
 * File: eapol_key_type1.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: eapol_key_type1.c,v 1.18 2004/09/02 17:17:22 chessing Exp $
 * $Date: 2004/09/02 17:17:22 $
 * $Log: eapol_key_type1.c,v $
 * Revision 1.18  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.17  2004/08/27 23:39:36  chessing
 *
 * Framework is now in place to complete the 4-way handshake for WPA.  The code for the 3rd key message is currently identical to the 1st key message, but will be changed when I can get to an AP that really supports WPA. ;)  WPA support is now *REALLY* close!
 *
 * Revision 1.16  2004/08/27 20:55:59  chessing
 * Some bug fixes, and more work toward getting WPA working.
 *
 * Revision 1.15  2004/07/15 04:15:35  chessing
 *
 * True/false int values are now bit flags in a byte.  PEAP now calls back in to functions from eap.c for phase 2 methods.  This allows for any phase 1 EAP type to work.  This resulted in some major changes the functions in eap.c, and in peap_phase2.c.  PEAP has been tested using both MS-CHAPv2, and EAP-MD5 as inner types.  More types need to be tested, and enabled.
 *
 * Revision 1.14  2004/06/15 03:35:19  chessing
 *
 * New updates including fixes to LEAP (keying now works with wireless) and adding EAP-AKA.
 *
 * Revision 1.13  2004/06/15 03:22:29  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/

#include <stdio.h>
#include <openssl/hmac.h>
#include <string.h>
#include <netinet/in.h>
#include "xsup_debug.h"
#include "xsup_err.h"
#include "frame_structs.h"
#include "cardif/cardif.h"
#include "key_statemachine.h"
#include "eapol_key_type1.h"
#include "config.h"

int eapol_dump_keydata(char *inframe, int framesize)
{
  struct key_packet *keydata;
  int length;

  if (!inframe)
    {
      debug_printf(DEBUG_NORMAL, "Invalid frame passed to eapol_dump_keydata()!\n");
      return XEMALLOC;
    }

  keydata = (struct key_packet *)inframe;

  debug_printf(DEBUG_INT, "Key Descriptor   = %d\n",keydata->key_descr);

  memcpy(&length, keydata->key_length,2);
  debug_printf(DEBUG_INT, "Key Length       = %d\n",ntohs(length));
  debug_printf(DEBUG_INT, "Replay Counter   = ");
  debug_hex_printf(DEBUG_INT, keydata->replay_counter, 8);
  debug_printf(DEBUG_INT, "Key IV           = ");
  debug_hex_printf(DEBUG_INT, keydata->key_iv, 16);
  debug_printf(DEBUG_INT, "Key Index (RAW)  = %02X\n",keydata->key_index);
  debug_printf(DEBUG_INT, "Key Signature    = ");
  debug_hex_printf(DEBUG_INT, keydata->key_signature, 16);

  return XENONE;
}

/************************************
 *
 * Check the HMAC on the key packet we got.  If we can't validate the
 * HMAC, then we return FALSE, indicating an error.
 *
 ************************************/
int eapol_key_type1_check_hmac(struct interface_data *thisint, char *inframe,
			       int framesize)
{
  struct key_packet *keydata;
  char *framecpy, *calchmac;
  int outlen, retVal, length;

  framecpy = NULL;
  calchmac = NULL;
  keydata = NULL;
  outlen = 0;
  retVal = 0;
  length = 0;

  if ((!thisint) || (!inframe))
    {
      debug_printf(DEBUG_NORMAL, "Bad data passed in to eapol_key_type1_check_hmac()!\n");
      return XEMALLOC;
    }

  if (thisint->keyingMaterial == NULL)
    {
      debug_printf(DEBUG_EVERYTHING, "No keying material available!  Ignoring key frame!\n");
      return XEMALLOC;
    }

  // First, make a copy of the frame.
  framecpy = (char *)malloc(framesize);
  if (framecpy == NULL) return XEMALLOC;

  memcpy(framecpy, inframe, framesize);

  // Now, we want to zero out the HMAC.
  keydata = (struct key_packet *)&framecpy[4];

  memcpy(&length, keydata->key_length, 2);

  bzero((char *)&keydata->key_signature, 16);

  // Once we have done that, we need to calculate the HMAC.
  calchmac = (char *)malloc(16);   // The resulting MAC is 16 bytes long.
  if (calchmac == NULL) return XEMALLOC;

  HMAC(EVP_md5(), thisint->keyingMaterial+32, 
       thisint->keyingLength, framecpy, framesize, calchmac, &outlen);

  // Now, we need to compare the calculated HMAC to the one sent to us.
  keydata = (struct key_packet *)&inframe[4];

  eapol_dump_keydata((char *)keydata, framesize);

  if (memcmp(calchmac, keydata->key_signature, 16) == 0)
    {
      // The HMAC is valid.
      retVal = TRUE;
    } else {
      retVal = FALSE;
    }

  // Clean up after ourselves.
  free(framecpy);
  framecpy = NULL;
  free(calchmac);
  calchmac = NULL;

  return retVal;
}

int eapol_key_type1_get_rc4(struct interface_data *thisint, u_char *enckey, 
			    u_char *deckey, int keylen, u_char *iv, int ivlen)
{
  u_char *wholekey = NULL;
  RC4_KEY key;

  if ((thisint == NULL) || (enckey == NULL) || (deckey == NULL) ||
      (iv == NULL))
    {
      debug_printf(DEBUG_NORMAL, "Some value passed in to eapol_key_type1_get_rc4() is NULL!\n");
      return XEMALLOC;
    }

  wholekey = (u_char *)malloc(sizeof(u_char) * (ivlen + thisint->keyingLength));
  if (wholekey == NULL) return XEMALLOC;

  memcpy(wholekey, iv, ivlen);

  if (!thisint->keyingMaterial)
    {
      debug_printf(DEBUG_NORMAL, "Invalid keying material!  Keys will not be handled correctly!\n");
      return XEMALLOC;
    }

  memcpy(wholekey + ivlen, thisint->keyingMaterial, thisint->keyingLength);

  RC4_set_key(&key, ivlen + thisint->keyingLength, wholekey);
  RC4(&key, keylen, enckey, deckey);

  if (wholekey)
    {
      free(wholekey);
      wholekey = NULL;
    }

  return XENONE;
}

/*********************************
 *
 * Decrypt the key, and set it on the interface.  If there isn't a key to
 * decrypt, then use the peer key.
 *
 *********************************/
int eapol_key_type1_decrypt(struct interface_data *thisint, char *inframe,
			    int framesize)
{
  struct key_packet *keydata = NULL;
  int keylen, rc=0, length;
  u_char *newkey = NULL, *enckey = NULL;

  if ((!thisint) || (!inframe))
    {
      debug_printf(DEBUG_NORMAL, "Bad data passed in to eapol_key_type1_decrypt()!\n");
      return XEMALLOC;
    }

  keydata = (struct key_packet *)&inframe[0];

  //  keylen = framesize - sizeof(*keydata) - 2;
  memcpy(&length, keydata->key_length, 2);
  keylen = ntohs(length);

  debug_printf(DEBUG_INT, "EAPoL Key Processed: %s [%d] %d bytes.\n",
	       keydata->key_index & UNICAST_KEY ? "unicast" : "broadcast",
	       (keydata->key_index & KEY_INDEX)+1, keylen);

  //  debug_printf(DEBUG_NORMAL, "Blah : %d >= %d\n", ((framesize)-sizeof(*keydata)), keylen);
  if ((keylen != 0) && ((framesize)-sizeof(*keydata) >= keylen))
    {
      newkey = (u_char *)malloc(sizeof(u_char) * keylen);
      if (newkey == NULL) return XEMALLOC;

      enckey = (u_char *)&inframe[sizeof(struct key_packet)];

      debug_printf(DEBUG_INT, "Key before decryption : ");
      debug_hex_printf(DEBUG_INT, enckey, keylen);

      if (eapol_key_type1_get_rc4(thisint, enckey, newkey, keylen, 
				  keydata->key_iv, 16) != XENONE)
	{
	  debug_printf(DEBUG_NORMAL, "Couldn't decrypt new key!\n");
	  return XEBADKEY;
	}

      debug_printf(DEBUG_INT, "Key after decryption : ");
      debug_hex_printf(DEBUG_INT, newkey, keylen);

      if (set_wireless_key(thisint, newkey, keylen, keydata->key_index) != 0)
	{
	  rc = FALSE;
	} else {
	  rc = TRUE;
	  UNSET_FLAG(thisint->flags, ZERO_KEYS);
	}

      free(newkey);
      newkey = NULL;
    } else {
      debug_printf(DEBUG_INT, "Using peer key!\n");
      memcpy(&length, keydata->key_length, 2);
      length = ntohs(length);
      if (set_wireless_key(thisint, thisint->keyingMaterial, length, keydata->key_index) != 0)
	{
	  rc = FALSE;
	} else {
	  rc = TRUE;
	}
    }

  return rc;
}

/**********************************
 *
 * We are handed in an EAPoL key frame.  From that frame, we check the frame
 * to make sure it hasn't been changed in transit.  We then determine the 
 * correct key, and make the call to set it.
 *
 **********************************/
void eapol_key_type1_process(struct interface_data *thisint, char *inframe,
			     int framesize)
{
  struct key_packet *keydata;
  struct eapol_header *eapolheader;
  int framelen;

  if ((!thisint) || (!inframe))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to eapol_key_type1_process()!\n");
      return;
    }

  eapolheader = (struct eapol_header *)&inframe[OFFSET_PAST_MAC];

  framelen = ntohs(eapolheader->eapol_length);

  keydata = (struct key_packet *)&inframe[OFFSET_TO_EAPOL+4];

  if (keydata->key_descr != RC4_KEY_TYPE)
    {
      debug_printf(DEBUG_NORMAL, "Key type isn't RC4!\n");
      return;
    }

  if (eapol_key_type1_check_hmac(thisint, (char *)&inframe[OFFSET_TO_EAPOL], framelen+4)==FALSE)
    {
      debug_printf(DEBUG_NORMAL, "HMAC failed on key data!  This key will be discarded.\n");
      return;
      }

  if (eapol_key_type1_decrypt(thisint, (char *)&inframe[OFFSET_TO_EAPOL+4],
			      (framelen)) != TRUE)
    {
      debug_printf(DEBUG_NORMAL, "Failed to set wireless key!\n");
      return;
    }
}
