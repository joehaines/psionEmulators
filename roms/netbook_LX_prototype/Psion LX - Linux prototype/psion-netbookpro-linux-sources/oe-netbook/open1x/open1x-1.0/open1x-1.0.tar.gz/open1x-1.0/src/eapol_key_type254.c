/*******************************************************************
 * Handle keying for WPA keys.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: eapol_key_type254.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: eapol_key_type254.c,v 1.15 2004/09/15 03:10:26 chessing Exp $
 * $Date: 2004/09/15 03:10:26 $
 * $Log: eapol_key_type254.c,v $
 * Revision 1.15  2004/09/15 03:10:26  chessing
 * Cleanups for various compiler warnings, etc.
 *
 * Revision 1.14  2004/09/15 01:33:48  chessing
 * Updates to IPC and logging functionality.  The config file command 'ipc_group' can be set to the name of the group that users need to be a member of in order to use IPC with the daemon.  Also, an update to an older patch.  If the config file value for 'logfile' is set to 'syslog', then we will log to the syslog daemon.  A new command 'log_facility' specifies the log facility that should be used when in syslog mode.  If not in syslog mode, log_facility does nothing.
 *
 * Revision 1.13  2004/09/10 05:26:41  chessing
 * More WPA patches.  We now complete the 4-way handshake, but we are doing something wrong, and not starting the Group Key handshake. :-/
 *
 * Revision 1.12  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.11  2004/09/09 04:26:53  chessing
 *
 * Fixed a problem with the MIC code.  We now get to sending the 4th packet of the handshake, and we apply the key.  For some reason, we don't get the first packet of the GTK exchange.  (But, getting closer! ;)
 *
 * Revision 1.10  2004/09/04 01:02:38  chessing
 * A few fixes to the WPA code.  We now attempt to set the key.
 *
 * Revision 1.9  2004/09/02 21:26:59  chessing
 *
 * A few MIC updates, and some WPA key updates.  We should be able to answer the 3rd packet in the 4 way handshake now.  (Still needs to be tested.)  However, before it will work, we need to be able to do an MLME.setkeys.
 *
 * Revision 1.8  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.7  2004/09/02 04:28:13  chessing
 *
 * Few small code fixes.  We are now able to get to the third packet of the 4 way handshake for WPA-PSK.  (The MIC is failing, because the code needs to be modified to calcluate the MIC over the right piece of the packet. ;)
 *
 * Revision 1.6  2004/08/31 04:49:20  chessing
 *
 * We now have the functions needed to do PRF-X, and compute the MIC.  We attempt to answer the first packet of the 4-way handshake, but appear to be getting something wrong. :-/
 *
 * Revision 1.5  2004/08/30 03:13:44  chessing
 *
 * Some small changes.  We no longer generate the cardif library.  (It was a good idea that didn't turn out as planned. ;)
 *
 * Revision 1.4  2004/08/27 23:39:36  chessing
 *
 * Framework is now in place to complete the 4-way handshake for WPA.  The code for the 3rd key message is currently identical to the 1st key message, but will be changed when I can get to an AP that really supports WPA. ;)  WPA support is now *REALLY* close!
 *
 * Revision 1.3  2004/08/27 20:55:59  chessing
 * Some bug fixes, and more work toward getting WPA working.
 *
 * Revision 1.2  2004/08/20 04:42:27  chessing
 * Set all of the new scanning and WPA code to be disabled by default, so that a 1.0.1 release can be made.  Added additional error message output to AKA code.  Fixed a few memory leaks in the AKA code.
 *
 * Revision 1.1  2004/08/19 04:11:47  chessing
 * More updates to get closer to WPA support.  We can now associate to an AP that has WPA, however we are using a static WPA IE, so that needs to be fixed.  There is also still a fair bit of other things that need to be cleaned up, but we are closer.
 *
 *
 ******************************************************************/

#include <string.h>

#include "xsup_debug.h"
#include "profile.h"
#include "config.h"
#include "key_statemachine.h"
#include "eapol_key_type254.h"
#include "eapol.h"
#include "frame_structs.h"
#include "wpa.h"
#include "psk.h"
#include "mic.h"
#include "cardif/cardif.h"
#include "cardif/linux/cardif_linux_wpa.h"
#include "eap_types/mschapv2/mschapv2.h"

void eapol_key_type254_dump(char *framedata)
{
  int value16=0;
  int need_comma = 0;
  struct wpa_key_packet *keydata;

  keydata = (struct wpa_key_packet *)&framedata[OFFSET_TO_EAPOL+4];

  debug_printf(DEBUG_INT, "Key Descriptor      = %d\n", keydata->key_descriptor);
  memcpy(&value16, keydata->key_information, 2);
  debug_printf(DEBUG_INT, "Key Information     = %04X  (Flags : ", ntohs(value16));
  if (ntohs(value16) & WPA_PAIRWISE_KEY)
    {
      debug_printf_nl(DEBUG_INT, "Pairwise Key");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_INSTALL_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "Install Key");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_KEY_ACK_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "Key Ack");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_KEY_MIC_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "MIC");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_SECURE_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "Secure");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_ERROR_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "Error");
      need_comma = 1;
    }
  if (ntohs(value16) & WPA_REQUEST_FLAG)
    {
      if (need_comma) debug_printf_nl(DEBUG_INT, ", ");
      debug_printf_nl(DEBUG_INT, "Request");
      need_comma = 1;
    }

  debug_printf_nl(DEBUG_INT, ")\n");

  switch (ntohs(value16) & WPA_KEYTYPE_MASK)
    {
    case 1:
      debug_printf(DEBUG_INT, "Key Descriptor Version : HMAC-MD5 for MIC and RC4 for encryption.\n");
      break;

    case 2:
      debug_printf(DEBUG_INT, "Key Descriptor Version : HMAC-SHA1-128 for MIC and AES for encryption.\n");
      break;
    }

  memcpy(&value16, keydata->key_length, 2);
  debug_printf(DEBUG_INT, "Key Length          = %d\n", ntohs(value16));

  debug_printf(DEBUG_INT, "Key Replay Counter  = ");  
  debug_hex_printf(DEBUG_INT, keydata->key_replay_counter, 8);

  debug_printf(DEBUG_INT, "Key NONCE           = ");
  debug_hex_printf(DEBUG_INT, keydata->key_nonce, 32);

  debug_printf(DEBUG_INT, "Key IV              = ");
  debug_hex_printf(DEBUG_INT, keydata->key_iv, 16);
  
  debug_printf(DEBUG_INT, "Key RSC             = ");
  debug_hex_printf(DEBUG_INT, keydata->key_rsc, 8);
  
  debug_printf(DEBUG_INT, "Key ID              = ");
  debug_hex_printf(DEBUG_INT, keydata->key_id, 8);

  debug_printf(DEBUG_INT, "Key MIC             = ");
  debug_hex_printf(DEBUG_INT, keydata->key_mic, 16);

  memcpy(&value16, keydata->key_material_len, 2);
  value16 = ntohs(value16);
  debug_printf(DEBUG_INT, "Key Material Length = %d\n", value16);

  if (value16 > 0)
    {
      debug_printf(DEBUG_INT, "Key Data : (%d)\n", value16);
      debug_hex_dump(DEBUG_INT, 
		     (char *)&framedata[sizeof(struct wpa_key_packet)+OFFSET_TO_EAPOL+4],
		     value16);
    }
}

void eapol_key_type254_eapol_header(struct interface_data *intdata,
				    char *outframe, int *outsize, int length)
{
  struct eapol_header *eapolheader;

  eapolheader = (struct eapol_header *)&outframe[OFFSET_PAST_MAC];

  eapolheader->eapol_length = htons(length);
  eapolheader->frame_type = htons(0x888e);
  eapolheader->eapol_version = 1;
  eapolheader->eapol_type = EAPOL_KEY;
}  

char *eapol_key_type254_gen_ptk(struct interface_data *intdata, char *Anonce)
{
  char prfdata[76];  // 6*2 (MAC addrs) + 32*2 (nonces)
  char *retval;

  bzero((char *)&prfdata, 76);

  if (memcmp((char *)&intdata->source_mac, (char *)&intdata->dest_mac, 6) < 0)
    {
      memcpy((char *)&prfdata[0], (char *)&intdata->source_mac, 6);
      memcpy((char *)&prfdata[6], (char *)&intdata->dest_mac, 6);
    } else if (memcmp((char *)&intdata->source_mac, (char *)&intdata->dest_mac,
		      6) > 0)
      {
	memcpy((char *)&prfdata[0], (char *)&intdata->dest_mac, 6);
	memcpy((char *)&prfdata[6], (char *)&intdata->source_mac, 6);
      } else {
	debug_printf(DEBUG_NORMAL, "Source and Destination MAC addresses "
		     "match!  The PTK won't be valid!\n");
	return NULL;
      }

  if (memcmp(intdata->statemachine->SNonce, Anonce, 32) < 0)
    {
      memcpy((char *)&prfdata[12], intdata->statemachine->SNonce, 32);
      memcpy((char *)&prfdata[44], Anonce, 32);
    } else if (memcmp(intdata->statemachine->SNonce, Anonce, 32) > 0)
      {
	memcpy((char *)&prfdata[12], Anonce, 32);
	memcpy((char *)&prfdata[44], intdata->statemachine->SNonce, 32);
      } else {
	debug_printf(DEBUG_NORMAL, "ANonce and SNonce match!  The PTK won't"
		     " be valid!\n");
	return NULL;
      }
  
  retval = (char *)malloc(80);
  if (retval == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for retval in %s "
		   "at %d!\n", __FUNCTION__, __LINE__);
      return NULL;
    }

  wpa_PRF(intdata->statemachine->PMK, 32, "Pairwise key expansion", 22,
	  (char *)&prfdata, 76, retval, 64);

  return retval;
}

void eapol_key_type254_do_type1(struct interface_data *intdata, char *inframe,
				int insize, char *outframe, int *outsize)
{
  struct wpa_key_packet *inkeydata, *outkeydata;
  uint16_t keyflags, len, value16;
  int i, version;
  char key[16];
  char generic_wpa_ie2[24] = {0xdd, 0x16, 0x00, 0x50, 0xf2, 0x01, 0x01, 0x00,
			      0x00, 0x50, 0xf2, 0x02, 0x01, 0x00, 0x00, 0x50, 
			      0xf2, 0x02, 0x01, 0x00, 0x00, 0x50, 0xf2, 0x02};

  inkeydata = (struct wpa_key_packet *)&inframe[OFFSET_TO_EAPOL+4];
  outkeydata = (struct wpa_key_packet *)&outframe[OFFSET_TO_EAPOL+4];

  // Clear everything out.
  bzero(&outframe[OFFSET_TO_EAPOL+4], sizeof(struct wpa_key_packet));

  // XXX Need to do this better.  Tie it in with Nonce code from SIM/AKA.
  for (i=0;i<32;i++)
    {
      outkeydata->key_nonce[i] = rand();
    }
  intdata->statemachine->SNonce = (char *)malloc(32);
  if (intdata->statemachine->SNonce == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for SNonce in "
		   "%s at %d!\n", __FUNCTION__, __LINE__);
      return;
    }
  memcpy(intdata->statemachine->SNonce, (char *)&outkeydata->key_nonce[0],
	 32);

  // Calculate the PTK.
  if (intdata->statemachine->PTK != NULL)
    {
      free(intdata->statemachine->PTK);
      intdata->statemachine->PTK = NULL;
    }
  intdata->statemachine->PTK = eapol_key_type254_gen_ptk(intdata,
							 (char *)&inkeydata->key_nonce);

  // XXX Do we need to store the nonce from the in packet?

  outkeydata->key_descriptor = WPA_KEY_TYPE;

  memcpy(&value16, inkeydata->key_information, 2);
  value16 = ntohs(value16);

  keyflags = 0;
  keyflags = (value16 & WPA_KEYTYPE_MASK);
  version = keyflags;
  keyflags |= (WPA_PAIRWISE_KEY | WPA_KEY_MIC_FLAG);
  keyflags = htons(keyflags);
  memcpy(&outkeydata->key_information, &keyflags, 2);
  
  len = sizeof(struct wpa_key_packet);
  *outsize = len+OFFSET_TO_EAPOL+4;

  memcpy(&outkeydata->key_length, &inkeydata->key_length, 2);

  memcpy(&outkeydata->key_replay_counter, &inkeydata->key_replay_counter, 8);

  memcpy(&outframe[OFFSET_TO_EAPOL+4+sizeof(struct wpa_key_packet)], (char *)&generic_wpa_ie2, 24);
  value16 = 24;
  value16 = htons(value16);
  *outsize += 24;

  memcpy(&outkeydata->key_material_len, &value16, 2);

  eapol_key_type254_eapol_header(intdata, outframe, outsize, 
				 *outsize-OFFSET_TO_EAPOL-4);

  memcpy(key, intdata->statemachine->PTK, 16);
  mic_wpa_populate(outframe, *outsize+4, key, 16);

  // Dump what we built.
  eapol_key_type254_dump(outframe);
}


void eapol_key_type254_do_type3(struct interface_data *intdata, char *inframe,
				int insize, char *outframe, int *outsize)
{
  struct wpa_key_packet *inkeydata, *outkeydata;
  uint16_t keyflags, len, value16;
  char key[16];

  bzero(key, 16);

  inkeydata = (struct wpa_key_packet *)&inframe[OFFSET_TO_EAPOL+4];
  outkeydata = (struct wpa_key_packet *)&outframe[OFFSET_TO_EAPOL+4];

  // Clear everything out.
  bzero(&outframe[OFFSET_TO_EAPOL], sizeof(struct wpa_key_packet)+28);

  outkeydata->key_descriptor = WPA_KEY_TYPE;

  memcpy(&value16, inkeydata->key_information, 2);
  value16 = ntohs(value16);
  
  keyflags = 0;
  keyflags = (value16 & WPA_KEYTYPE_MASK);
  keyflags |= (WPA_PAIRWISE_KEY | WPA_KEY_MIC_FLAG);

  // If the authenticator sets the secure flag, we need to do the same.
  if (value16 & WPA_SECURE_FLAG) keyflags |= WPA_SECURE_FLAG;
  keyflags = htons(keyflags);

  memcpy(&outkeydata->key_information, &keyflags, 2);
  
  len = sizeof(struct wpa_key_packet);
  *outsize = len+OFFSET_TO_EAPOL+4;

  memcpy(&outkeydata->key_length, &inkeydata->key_length, 2);

  memcpy(&outkeydata->key_replay_counter, &inkeydata->key_replay_counter, 8);
  memcpy(&outkeydata->key_nonce, intdata->statemachine->SNonce, 32);

  memcpy(outkeydata->key_nonce, intdata->statemachine->SNonce,
	 32);


  eapol_key_type254_eapol_header(intdata, outframe, outsize, 
				 *outsize-OFFSET_TO_EAPOL-4);

  memcpy(key, intdata->statemachine->PTK, 16);
  mic_wpa_populate(outframe, *outsize+4, key, 16);  

  // Dump what we built.
  eapol_key_type254_dump(outframe);

  // Get TK1
  memcpy(&value16, inkeydata->key_length, 2);
  value16 = ntohs(value16);
  memcpy(key, (char *)&intdata->statemachine->PTK[32], value16);
  
  debug_printf(DEBUG_INT, "TK1 : ");
  debug_hex_printf(DEBUG_INT, key, value16);
  
  sendframe(intdata, outframe, *outsize);
  *outsize = 0;

  debug_printf(DEBUG_INT, "Setting PTK1!\n");
  cardif_linux_wpa_set_key(intdata, WPA_TKIP, NULL, 0, 1, inkeydata->key_rsc,
      sizeof(inkeydata->key_rsc), key, value16);
}

void eapol_key_type254_determine_key(struct interface_data *intdata,
				     char *inframe, int insize, char *outframe,
				     int *outsize)
{
  struct wpa_key_packet *keydata;
  int keyflags;

  keydata = (struct wpa_key_packet *)&inframe[OFFSET_TO_EAPOL+4];  
  memcpy(&keyflags, keydata->key_information, 2);

  keyflags = ntohs(keyflags);

  if (keyflags & WPA_KEY_MIC_FLAG)
    {
      if (mic_wpa_validate(inframe, insize, intdata->statemachine->PTK, 16)
	  == FALSE)
	{
	  intdata->statemachine->MICVerified = TRUE;
	  intdata->statemachine->IntegrityFailed = TRUE;
	  debug_printf(DEBUG_INT, "MIC failure!\n");
       	  return;   // Silently discard.
	} else {
	  intdata->statemachine->IntegrityFailed = FALSE;
	  intdata->statemachine->MICVerified = TRUE;
	}
    }
  if ((keyflags & WPA_PAIRWISE_KEY) && (keyflags & WPA_KEY_ACK_FLAG) &&
      (keyflags & WPA_KEY_MIC_FLAG) && (keyflags & WPA_INSTALL_FLAG))
    {
      debug_printf(DEBUG_NORMAL, "Key Packet #3 (response) :\n");
      eapol_key_type254_do_type3(intdata, inframe, insize, outframe, outsize);
    } else if ((keyflags & WPA_PAIRWISE_KEY) && (keyflags & WPA_KEY_ACK_FLAG))
    {
      debug_printf(DEBUG_INT, "Key Packet #1 (response) :\n");
      eapol_key_type254_do_type1(intdata, inframe, insize, outframe, outsize);
    } else if ((keyflags & WPA_KEY_MIC_FLAG) && (keyflags & WPA_PAIRWISE_KEY))
    {
      debug_printf(DEBUG_NORMAL, "Got Key Packet #2 or #4!  (This shouldn't happen!)\n");
    }

  if (*outsize > 0)
    {
      eapol_key_type254_eapol_header(intdata, outframe, outsize, 
				     (*outsize-(OFFSET_TO_EAPOL+4)));
    }      
}

void eapol_key_type254_process(struct interface_data *intdata, char *inframe,
			       int insize, char *outframe, int *outsize)
{
  struct eapol_header *eapolheader;
  struct wpa_key_packet *keydata;
  struct config_wpa_psk *psk;
  int framelen;
  char tpmk[32];

  debug_printf(DEBUG_NORMAL, "Processing WPA key!  (Not complete!)\n");

  if (intdata->statemachine->PMK == NULL)
    {
      psk = (struct config_wpa_psk *)intdata->userdata->methods->method_data;
      if (psk->key)
	{
	  // We have an ASCII password, so calculate it.
	  if (psk_wpa_pbkdf2(psk->key, intdata->cur_essid, 
			     strlen(intdata->cur_essid), (char *)&tpmk) == TRUE)
	    {
	      intdata->statemachine->PMK = (char *)malloc(32);
	      if (intdata->statemachine->PMK == NULL)
		{
		  debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for "
			       "intdata->statemachine->PMK in %s at %d!\n",
			       __FUNCTION__, __LINE__);
		  return;
		}

	      memcpy(intdata->statemachine->PMK, (char *)&tpmk, 32);
	    }
	} else {
	  // We have a hex key, we need to convert it from ASCII to real
	  // hex.
	  if (strlen(psk->hex_key) != 64)
	    {
	      debug_printf(DEBUG_NORMAL, "Invalid HEX key defined for WPA-PSK!\n");
	      return;
	    }
	  process_hex(psk->hex_key, strlen(psk->hex_key), (char *)&tpmk);
	  intdata->statemachine->PMK = (char *)malloc(32);
	  if (intdata->statemachine->PMK == NULL)
	    {
	      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for "
			   "intdata->statemachine->PMK in %s at %d!\n",
			   __FUNCTION__, __LINE__);
	      return;
	    }
	}
    }

  debug_printf(DEBUG_NORMAL, "WPA-Key Frame :\n");
  debug_hex_dump(DEBUG_NORMAL, inframe, insize);

  eapolheader = (struct eapol_header *)&inframe[OFFSET_PAST_MAC];
  framelen = ntohs(eapolheader->eapol_length);

  keydata = (struct wpa_key_packet *)&inframe[OFFSET_TO_EAPOL+4];
  eapol_key_type254_dump(inframe);

  eapol_key_type254_determine_key(intdata, inframe, insize, outframe, outsize);
}
