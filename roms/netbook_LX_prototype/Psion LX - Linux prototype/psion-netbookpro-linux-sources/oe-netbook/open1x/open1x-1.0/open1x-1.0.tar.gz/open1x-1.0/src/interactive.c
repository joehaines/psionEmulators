/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: interactive.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: interactive.c,v 1.13 2004/09/21 21:47:14 chessing Exp $
 * $Date: 2004/09/21 21:47:14 $
 * $Log: interactive.c,v $
 * Revision 1.13  2004/09/21 21:47:14  chessing
 * Fixes for IPC interface. xsup_monitor works correctly now.
 *
 * Revision 1.12  2004/09/18 04:41:32  chessing
 * Fixes for TTLS-MSCHAPv2 for bugs found by Chris Zimmerman.  Also, a couple of small updates to try to get IPC back to where it needs to be.
 *
 * Revision 1.11  2004/09/10 22:23:00  chessing
 * More updates to IPC.  We now speak IPC with the messages being version 2, instead of version 1.  Because version 1 messages were only allowed across the loopback interface, they have been deprecated, and will result in an error from Xsupplicant!
 *
 * Revision 1.10  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.9  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.8  2004/08/21 03:19:56  galimorerpg
 * Caught an error where a null interface name would cause a crash.  We now catch and report the error (and line number).
 *
 * Revision 1.7  2004/07/15 04:15:35  chessing
 *
 * True/false int values are now bit flags in a byte.  PEAP now calls back in to functions from eap.c for phase 2 methods.  This allows for any phase 1 EAP type to work.  This resulted in some major changes the functions in eap.c, and in peap_phase2.c.  PEAP has been tested using both MS-CHAPv2, and EAP-MD5 as inner types.  More types need to be tested, and enabled.
 *
 * Revision 1.6  2004/06/15 03:22:29  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/

#include <stdlib.h>
#include <string.h>
#include <net/if.h>
#include "xsup_err.h"
#include "xsup_debug.h"
#include "config.h"
#include "profile.h"
#include "eap.h"
#include "xsup_ipc.h"
#include "ipc_callout.h"
#include "interactive.h"

/*******************************************************************
 *
 * Check to see if we need to poke the GUI to ask for a password.  If we do,
 * then send the GUI a message, and return.  If we determine we have a 
 * password, then we should set procReady to TRUE.
 *
 * The caller should check the return to see if it is XPROMPT, or XENONE.
 * If it is XPROMPT, the caller may choose to check if the frame buffer 
 * contains anything.  If it does, it should call the 
 * interactive_store_frame() function.
 *
 * When called, **password should point to a pointer to the password for
 * the calling EAP type.  *tempPwd should point to thisint->tempPwd, and
 * eapType should point to a string that identifies the EAP type that is
 * calling the function.  (The EAP type string will be passed to the GUI
 * to be displayed in the box that prompts for a password.)  Optionally,
 * the caller may fill in a value for challenge.  This is a string that
 * will be sent to the GUI to be used to create the correct return value.
 * For EAP types like OTP and GTC, it should contain the challenge string
 * to be displayed to the user.  (Or it could be used with an OTP front-end
 * that simply requires the users password be typed, and it generates the
 * correct response sequence.  If there is no challenge data to be passed
 * up, this value should be NULL!
 *
 *******************************************************************/
int interactive_gui_prompt(char *interface, char *tempPwd, char *eapType, 
			   char *challenge)
{
  char packet[1512];
  struct ipc_header *header;
  int bufptr = 0;

  if (tempPwd == NULL)
    {
      // Ask the GUI to prompt for a password.
      debug_printf(DEBUG_AUTHTYPES, "Asking the GUI for a password.\n");
      debug_printf(DEBUG_AUTHTYPES, "EAP type is %s, challenge is %s\n",
		   eapType, challenge);

      bzero((char *)&packet[0], 512);
      header = (struct ipc_header *)&packet[0];
      header->version = 2;
      bufptr = sizeof(struct ipc_header);

      if(interface)
	{
	  header->int_idx = if_nametoindex(interface);
	  debug_printf(DEBUG_AUTHTYPES, "Interface : %s  Index : %d\n",
		       interface, header->int_idx);
	  //	  strcpy(&header->interface[0], interface);
	}
      else
	{
	  debug_printf(DEBUG_NORMAL, "Invalid interface data in interactive.c  Line: %d\n", __LINE__);
	  return XEBADCONFIG;
	}

      ipc_callout_request_password(&bufptr, (char *)&packet[0], 512, eapType, 
				   challenge);
      debug_printf(DEBUG_AUTHTYPES, "Sending : \n");
      debug_hex_dump(DEBUG_AUTHTYPES, packet, bufptr);
      xsup_ipc_send_all((char *)&packet, bufptr);
      
      // Let the caller know we are asking for a password.
      return XPROMPT;
    }

  return XENONE;
}

/***********************************************************************
 *
 * This function stores a frame in to an EAP type's data structure to be used
 * at a later time, once the needed interactive piece is complete.  (Usually
 * after the user has entered a password to the GUI.)  If there is no frame
 * to pass in, the cur_frame value should be NULL (or *NULL) and cur_size 
 * should be 0.  **frame_hook should be a pointer to a memory buffer that
 * we can allocate to store the frame passed in through cur_frame.  It should
 * be assumed that this buffer will be destroyed, and refilled in a new 
 * request frame comes in!  (Which is why we allocate the buffer in here. ;)
 * hook_size should be a pointer to an int that can hold the numeric 
 * representation of the size of frame_hook.
 *
 * In general, if the value for **cur_frame is NULL, there is no need to call
 * this function.  (It will simply waste a few cycles calling, and returning.)
 * However, calling this function with a NULL value will not fail, it will
 * simply return XENONE.
 *
 ***********************************************************************/
int interactive_store_frame(char *cur_frame, int cur_size, 
			    struct generic_eap_data *thisint)
{
  if (!thisint)
    {
      debug_printf(DEBUG_NORMAL, "Bad interface struct passed in to interactive_store_frame()\n");
      return XEMALLOC;
    }

  // First, make sure we have what we need!
  if (cur_size == 0) 
    {
      return XENONE;
    }
  if (cur_frame == NULL) 
    {
      return XENONE;
    }

  if (thisint->staleFrame != NULL)
    {
      free(thisint->staleFrame);
      thisint->staleFrame = NULL;
    }
  
  thisint->staleFrame = (char *)malloc(cur_size);
  if (thisint->staleFrame == NULL) return XEMALLOC;

  // Store the frame.
  memcpy(thisint->staleFrame, cur_frame, cur_size);
  thisint->staleSize = cur_size;
  // There were no errors to report.
  return XENONE;
}

