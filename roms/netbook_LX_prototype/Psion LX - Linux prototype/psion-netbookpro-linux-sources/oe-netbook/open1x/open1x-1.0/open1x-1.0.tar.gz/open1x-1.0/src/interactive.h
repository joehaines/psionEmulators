/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: interactive.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _INTERACTIVE_H_
#define _INTERACTIVE_H_

#include "profile.h"
#include "config.h"
#include "eap.h"

int interactive_gui_prompt(char *, char *, char *, char *);
int interactive_store_frame(char *, int, struct generic_eap_data *);
int interactive_return_frame(char **, int *, char *, int *);

#endif
