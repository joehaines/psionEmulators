/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: ipc_callout.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: ipc_callout.c,v 1.18 2004/09/21 21:47:14 chessing Exp $
 * $Date: 2004/09/21 21:47:14 $
 * $Log: ipc_callout.c,v $
 * Revision 1.18  2004/09/21 21:47:14  chessing
 * Fixes for IPC interface. xsup_monitor works correctly now.
 *
 * Revision 1.17  2004/09/18 04:41:32  chessing
 * Fixes for TTLS-MSCHAPv2 for bugs found by Chris Zimmerman.  Also, a couple of small updates to try to get IPC back to where it needs to be.
 *
 * Revision 1.16  2004/09/15 03:10:26  chessing
 * Cleanups for various compiler warnings, etc.
 *
 * Revision 1.15  2004/09/10 22:23:00  chessing
 * More updates to IPC.  We now speak IPC with the messages being version 2, instead of version 1.  Because version 1 messages were only allowed across the loopback interface, they have been deprecated, and will result in an error from Xsupplicant!
 *
 * Revision 1.14  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.13  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.12  2004/07/15 04:15:35  chessing
 *
 * True/false int values are now bit flags in a byte.  PEAP now calls back in to functions from eap.c for phase 2 methods.  This allows for any phase 1 EAP type to work.  This resulted in some major changes the functions in eap.c, and in peap_phase2.c.  PEAP has been tested using both MS-CHAPv2, and EAP-MD5 as inner types.  More types need to be tested, and enabled.
 *
 * Revision 1.11  2004/06/15 03:22:29  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/
#include <netinet/in.h>
#include <strings.h>
#include <string.h>

#include "profile.h"
#include "config.h"
#include "xsup_debug.h"
#include "xsup_ipc.h"
#include "ipc_callout.h"

/*******************************************************************
 *
 * Fill in the next command record with the authentication state of the
 * selected interface.
 *
 *******************************************************************/
void ipc_callout_auth_state(struct interface_data *thisint, int *bufptr,
			    char *buffer, int bufsize, char *resbuf, 
			    int *resbufptr)
{
  struct ipc_cmd *cmd;

  if ((!thisint) || (!bufptr) || (!buffer) || (!resbuf) || (!resbufptr) ||
      (!thisint->statemachine))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_auth_state()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  if (cmd->attribute != AUTH_STATE) 
    {
      debug_printf(DEBUG_NORMAL, "Incorrect call to ipc_callout_auth_state!"
		   "\n");
      *bufptr = bufsize;
      return;
    }

  if (cmd->getset != IPC_GET)
    {
      debug_printf(DEBUG_NORMAL, "Attempt to SET authentication state!? "
		   "Skipping!\n");
      *bufptr += (sizeof(struct ipc_cmd)+cmd->len);
      return;
    }

  if (cmd->len != 0)
    {
      debug_printf(DEBUG_NORMAL, "Invalid length!  This will be the last"
		   " request we answer!\n");
      *bufptr = bufsize;
      return;
    }
  *bufptr+=sizeof(struct ipc_cmd);

  // Build the actual answer.
  cmd = (struct ipc_cmd *)&resbuf[*resbufptr];
  cmd->attribute = AUTH_STATE;
  cmd->getset = IPC_RESPONSE;
  cmd->len = 1;
  *resbufptr+=sizeof(struct ipc_cmd);

  resbuf[*resbufptr] = thisint->statemachine->curState;
  *resbufptr+=1;
}

/*****************************************************************
 *
 * Get or set config values.
 *
 *****************************************************************/
void ipc_callout_process_conf(struct interface_data *thisint, int *bufptr,
			      char *buffer, int bufsize, char *resbuf, 
			      int *resbufptr)
{
  // XXXX Finish this at some point!
  struct ipc_cmd *cmd;

  if ((!thisint) || (!bufptr) || (!buffer) || (!resbuf) || (!resbufptr))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_process_conf()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  if (cmd->attribute != CONFIG) 
    {
      debug_printf(DEBUG_NORMAL, "Incorrect call to ipc_callout_process_conf!\n");
    }

  *bufptr += sizeof(struct ipc_cmd);

  debug_printf(DEBUG_NORMAL, "Configuration value modification is not "
	       "implemented yet!\n");
}

/****************************************************************
 *
 *  Return a comma seperated list of interfaces we know about.
 *
 ****************************************************************/
void ipc_callout_get_ints(struct interface_data *startint, 
			  struct interface_data *thisint, int *bufptr,
			  char *buffer, int bufsize, char *resbuf, 
			  int *resbufptr)
{
  struct ipc_cmd *cmd;
  struct interface_data *cur;
  int interfaces;
  char *retlist;

  if ((!startint) || (!thisint) || (!bufptr) || (!buffer) || (!resbuf) ||
      (!resbufptr))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_get_ints()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  if (cmd->attribute != INTERFACES) 
    {
      debug_printf(DEBUG_NORMAL, "Incorrect call to ipc_callout_get_ints!\n");
      *bufptr = bufsize;
      return;
    }

  if (cmd->getset != IPC_GET)
    {
      debug_printf(DEBUG_NORMAL, "Can't SET an interface list!\n");
      *bufptr += (sizeof(struct ipc_cmd)+cmd->len);
      return;
    }

  if (cmd->len != 0)
    {
      debug_printf(DEBUG_NORMAL, "Invalid length!  This will be the last "
		   "request we answer!\n");
      *bufptr = bufsize;
      return;
    }
  *bufptr+=sizeof(struct ipc_cmd);


  interfaces = 0;

  cur = startint;
  while (cur != NULL)
    {
      interfaces++;
      cur = cur->next;
    }

  retlist = (char *)malloc(interfaces*16);
  if (retlist == NULL) return;             // We won't answer.

  bzero(retlist, (interfaces*16));

  // Build the answer.
  cmd = (struct ipc_cmd *)&resbuf[*resbufptr];
  cmd->attribute = INTERFACES;

  *resbufptr += 2;
  
  cur = startint;
  while (cur != NULL)
    {
      strcat(retlist, cur->intName);
      cur = cur->next;
      if (cur != NULL) strcat(retlist, ",");
    }

  debug_printf(DEBUG_EVERYTHING, "Returning interface list of : %s\n", 
	       retlist);

  cmd->len = strlen(retlist);

  strncpy((char *)&resbuf[*resbufptr], retlist, strlen(retlist));
  *resbufptr += strlen(retlist);
}

/******************************************************************
 *
 * Build a message to be sent.  This should be used *ONLY* as a call
 * internal to the ipc_callout.c file!
 *
 ******************************************************************/
void ipc_callout_build_msg(struct interface_data *thisint, int *bufptr,
			   char *buffer, int bufsize, int msgtype, 
			   char *message)
{
  struct ipc_cmd *cmd;

  if ((!thisint) || (!bufptr) || (!buffer) || (!message))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_build_msg()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  cmd->attribute = msgtype;
  cmd->len = strlen(message);

  *bufptr += 2;

  strcpy((char *)&buffer[*bufptr], message);

  *bufptr += strlen(message);
}

/****************************************************************
 *
 * Send an error message to a client.
 *
 ****************************************************************/
void ipc_callout_send_error(struct interface_data *thisint, int *bufptr,
			    char *buffer, int bufsize, char *message)
{
  if ((!thisint) || (!bufptr) || (!buffer) || (!message))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_send_error()!\n");
      return;
    }

  ipc_callout_build_msg(thisint, bufptr, buffer, bufsize, ERROR_MSG, message);
}

/****************************************************************
 *
 * Send a notification to the client.
 *
 ****************************************************************/
void ipc_callout_send_notify(struct interface_data *thisint, int *bufptr,
			     char *buffer, int bufsize, char *message)
{
  if ((!thisint) || (!bufptr) || (!buffer) || (!message))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_send_notify()!\n");
      return;
    }

  ipc_callout_build_msg(thisint, bufptr, buffer, bufsize, NOTIFY, message);
}

/****************************************************************
 *
 * Get or set the profile we are using.
 *
 ****************************************************************/
void ipc_callout_getset_profile(struct interface_data *thisint, int *bufptr,
				char *buffer, int bufsize, char *resbuf, 
				int *resbufptr)
{
  //  struct ipc_cmd *cmd;

  if ((!thisint) || (!bufptr) || (!buffer) || (!resbuf) || (!resbufptr))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_getset_profile()!\n");
      return;
    }

  debug_printf(DEBUG_NORMAL, "Get/Set Profile Not Implemented!\n");
}

/***************************************************************
 *
 * Set a temporary password.  This password will be used by the first EAP
 * method that needs it.  Once it has been used, the EAP method should
 * bzero, and free the memory, in order to keep the password from sitting
 * in memory too long.
 *
 ***************************************************************/
void ipc_callout_set_password(struct interface_data *thisint, int *bufptr,
			      char *buffer, int bufsize, char *resbuf, 
			      int *resbufptr)
{
  struct ipc_cmd *cmd;

  if ((!thisint) || (!bufptr) || (!buffer) || (!resbuf) || (!resbufptr))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_set_password()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  if (cmd->attribute != TEMPPASSWORD)
    {
      debug_printf(DEBUG_NORMAL, "Invalid call to %s!\n", __FUNCTION__);
      *bufptr = bufsize;
      return;
    }

  if (cmd->getset != IPC_SET)
    {
      debug_printf(DEBUG_NORMAL, "Cannot GET a temp password value!\n");
      *bufptr = bufsize;
      return;
    }

  // If we already have a temp password, we need to get rid of it.
  if (thisint->tempPassword != NULL)
    {
      free(thisint->tempPassword);
      thisint->tempPassword = NULL;
    }
  
  thisint->tempPassword = (char *)malloc(cmd->len+1);
  if (thisint->tempPassword == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory for temporary password!\n");
      return;
    }

  bzero(thisint->tempPassword, cmd->len+1);
  *bufptr += sizeof(struct ipc_cmd);
  strcpy(thisint->tempPassword, (char *)&buffer[*bufptr]);

  *bufptr += strlen(thisint->tempPassword);

  cmd = (struct ipc_cmd *)&resbuf[*resbufptr];

  cmd->attribute = TEMPPASSWORD;
  cmd->getset = IPC_RESPONSE;
  cmd->len = 1;
  
  *resbufptr += sizeof(struct ipc_cmd);

  resbuf[*resbufptr] = ACK;
  *resbufptr += 1;
}

/***********************************************************************
 *
 * Ask any attached clients for a password.  In this message, we will
 * also pass the EAP type that is requesting the password, and any
 * challenge string that the EAP type may need.
 *
 ***********************************************************************/
void ipc_callout_request_password(int *bufptr, char *buffer, int bufsize,
				  char *eapname, char *challenge)
{
  struct ipc_cmd *cmd;

  if ((!bufptr) || (!buffer) || (!eapname))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to ipc_callout_request_password()!\n");
      return;
    }

  cmd = (struct ipc_cmd *)&buffer[*bufptr];

  cmd->attribute = PASSWORD;
  cmd->getset = IPC_GET;
  if (challenge != NULL)
    {
      cmd->len = strlen(eapname)+strlen(challenge)+2;  // The string, with a NULL.
    } else {
      cmd->len = strlen(eapname)+2;
    }

  *bufptr += sizeof(struct ipc_cmd);

  bzero((char *)&buffer[*bufptr],cmd->len);
  strcpy((char *)&buffer[*bufptr], eapname);
  *bufptr += (strlen(eapname)+1);

  if (challenge != NULL)
    {
      strcpy((char *)&buffer[*bufptr], challenge);
      *bufptr += (strlen(challenge)+1);
    }
}
