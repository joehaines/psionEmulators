/*******************************************************************
 * Handle the EAPOL keying state machine.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: key_statemachine.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: key_statemachine.c,v 1.10 2004/09/02 17:17:22 chessing Exp $
 * $Date: 2004/09/02 17:17:22 $
 * $Log: key_statemachine.c,v $
 * Revision 1.10  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.9  2004/08/27 23:39:36  chessing
 *
 * Framework is now in place to complete the 4-way handshake for WPA.  The code for the 3rd key message is currently identical to the 1st key message, but will be changed when I can get to an AP that really supports WPA. ;)  WPA support is now *REALLY* close!
 *
 * Revision 1.8  2004/08/27 20:55:59  chessing
 * Some bug fixes, and more work toward getting WPA working.
 *
 * Revision 1.7  2004/08/20 04:42:27  chessing
 * Set all of the new scanning and WPA code to be disabled by default, so that a 1.0.1 release can be made.  Added additional error message output to AKA code.  Fixed a few memory leaks in the AKA code.
 *
 * Revision 1.6  2004/08/19 04:11:47  chessing
 * More updates to get closer to WPA support.  We can now associate to an AP that has WPA, however we are using a static WPA IE, so that needs to be fixed.  There is also still a fair bit of other things that need to be cleaned up, but we are closer.
 *
 * Revision 1.5  2004/06/15 03:22:29  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/

#include "key_statemachine.h"
#include "eapol_key_type1.h"
#include "eapol_key_type254.h"
#include "xsup_debug.h"
#include "frame_structs.h"

/*************************************************
 *
 * Call the processKey() function defined in the 802.1x standard.  Here, we
 * need to determine what type of key it is, and call the correct handler.
 * Currently, the only type of key we can have, is RC4, but that will
 * change soon. ;)
 *
 *************************************************/
void processKey(struct interface_data *thisint, char *inframe,
		int insize, char *outframe, int *outsize)
{
  struct key_packet *keydata;

  if ((!thisint) || (!inframe))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to processKey()!\n");
      return;
    }

  keydata = (struct key_packet *)&inframe[OFFSET_TO_EAP];

  switch (keydata->key_descr)
    {
    case RC4_KEY_TYPE:
      eapol_key_type1_process(thisint, inframe, insize);
      outsize = 0;
      break;
      
    case WPA_KEY_TYPE:
      eapol_key_type254_process(thisint, inframe, insize, outframe, outsize);
      break;

    default:
      debug_printf(DEBUG_NORMAL, "Unknown EAPoL Key Descriptor (%d)!\n",
		   keydata->key_descr);
      break;
    }
}

/*************************************************
 *
 * Run the keying state machine that is defined in the 802.1x standard.  
 * Depending on the state, we may need to process a key.
 *
 *************************************************/
void run_key_statemachine(struct interface_data *thisint, char *inframe,
			  int insize, char *outframe, int *outsize)
{
  if ((!thisint) || (!inframe))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to run_key_statemachine()!\n");
      return;
    }

  if ((thisint->statemachine->initialize == TRUE) ||
      (thisint->statemachine->portEnabled == FALSE))
    {
      // Do the NO_KEY_RECIEVE part of the state machine.

    }

  if (thisint->statemachine->rxKey == TRUE)
    {
      processKey(thisint, inframe, insize, outframe, outsize);
      thisint->statemachine->rxKey = FALSE;
    }
}
