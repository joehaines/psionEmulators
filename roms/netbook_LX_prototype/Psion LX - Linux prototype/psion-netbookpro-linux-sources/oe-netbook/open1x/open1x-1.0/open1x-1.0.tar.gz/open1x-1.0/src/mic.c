/*******************************************************************
 * Handle MIC routines.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE for more info.)
 *
 * File: mic.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: mic.c,v 1.6 2004/09/09 23:11:36 chessing Exp $
 * $Date: 2004/09/09 23:11:36 $
 * $Log: mic.c,v $
 * Revision 1.6  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.5  2004/09/09 04:26:53  chessing
 *
 * Fixed a problem with the MIC code.  We now get to sending the 4th packet of the handshake, and we apply the key.  For some reason, we don't get the first packet of the GTK exchange.  (But, getting closer! ;)
 *
 * Revision 1.4  2004/09/04 01:02:38  chessing
 * A few fixes to the WPA code.  We now attempt to set the key.
 *
 * Revision 1.3  2004/09/02 21:27:00  chessing
 *
 * A few MIC updates, and some WPA key updates.  We should be able to answer the 3rd packet in the 4 way handshake now.  (Still needs to be tested.)  However, before it will work, we need to be able to do an MLME.setkeys.
 *
 * Revision 1.2  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.1  2004/08/28 06:08:26  chessing
 *
 * More pieces for WPA-PSK.  MIC calculation code is now included.  Code to generate the hex key for WPA-PSK from an ascii password.
 *
 *
 *******************************************************************/

#include <openssl/hmac.h>
#include <string.h>

#include "xsup_debug.h"
#include "mic.h"
#include "profile.h"
#include "eapol_key_type254.h"
#include "frame_structs.h"

/************************************************************************
 *
 * Calculate the MIC value for a key packet, and return it.
 *
 ************************************************************************/
void mic_process(char *key, int keylen, char *datain, int insize, int version, 
		 char *mic)
{
  char sha_hmac[20];
  int i;

  debug_printf(DEBUG_INT, "Calculating MIC for Version %d!\n", version);

  switch (version)
    {
    case 1:
      // Do an MD5 HMAC
      debug_printf(DEBUG_NORMAL, "MICing : (%d)\n", insize);
      debug_hex_dump(DEBUG_NORMAL, datain, insize);

      HMAC(EVP_md5(), key, keylen, datain, insize, mic, &i);
      break;

    case 2:
      // Do an SHA1 HMAC  
      // Since the HMAC will be 20 bytes, and we only need 16, we must use
      // a temporary variable.
      HMAC(EVP_sha1(), key, keylen, datain, insize, (char *)&sha_hmac, &i);
      memcpy(mic, &sha_hmac, 16);
      break;
    }
}

/*******************************************************************
 *
 * Given a frame, pull the MIC out, and check it.  If it matches,
 * return TRUE.  Otherwise, return FALSE.
 *
 *******************************************************************/
int mic_wpa_validate(char *inframe, int framesize, char *key, int keylen)
{
  struct wpa_key_packet *keydata;
  char *tempframe;
  char oldmic[16], newmic[16];
  uint16_t value16;
  int rc = FALSE;

  if (inframe == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid frame passed to %s!\n", __FUNCTION__);
      return FALSE;
    }

  tempframe = (char *)malloc(framesize);
  if (tempframe == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Couldn't allocate memory at %s line %d!\n",
		   __FUNCTION__, __LINE__);
      return FALSE;
    }

  memcpy(tempframe, inframe, framesize);

  // First, get the keydata struct pointing to the correct place.
  keydata = (struct wpa_key_packet *)&tempframe[OFFSET_TO_EAPOL+4];
  
  memcpy(oldmic, keydata->key_mic, 16);
  bzero(keydata->key_mic, 16);

  memcpy(&value16, keydata->key_information, 2);
  value16 = ntohs(value16);
  value16 &= WPA_KEYTYPE_MASK;

  debug_printf(DEBUG_NORMAL, "MIC src (%d): \n", framesize-OFFSET_TO_EAPOL);
  debug_hex_dump(DEBUG_NORMAL, (char *)&tempframe[OFFSET_TO_EAPOL], 
		 framesize-OFFSET_TO_EAPOL);

  mic_process(key, keylen, (char *)&tempframe[OFFSET_TO_EAPOL],
	      framesize - OFFSET_TO_EAPOL, value16, newmic);

  if (memcmp(oldmic, newmic, 16) == 0) rc = TRUE;

  free(tempframe);
  tempframe = NULL;

  return rc;
}

/*******************************************************************
 *
 * Given a frame, calculate the MIC, and stick it in the frame.
 *
 *******************************************************************/
void mic_wpa_populate(char *inframe, int framesize, char *key, int keylen)
{
  struct wpa_key_packet *keydata;
  char newmic[16];
  uint16_t value16;

  if (inframe == NULL)
    {
      debug_printf(DEBUG_NORMAL, "Invalid frame passed to %s!\n", __FUNCTION__);
      return;
    }

  // First, get the keydata struct pointing to the correct place.
  keydata = (struct wpa_key_packet *)&inframe[OFFSET_TO_EAPOL+4];
  
  bzero(keydata->key_mic, 16);

  memcpy(&value16, &keydata->key_information, 2);
  value16 = ntohs(value16);
  value16 &= WPA_KEYTYPE_MASK;

  mic_process(key, keylen, (char *)&inframe[OFFSET_TO_EAPOL],
	      framesize - OFFSET_TO_EAPOL -4, value16, newmic);

  memcpy(keydata->key_mic, newmic, 16);
}
