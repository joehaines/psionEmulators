/*******************************************************************
 * Handle MIC routines.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: mic.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _MIC_H_
#define _MIC_H_

void mic_process(char *, int, char *, int, int, char *);
int mic_wpa_validate(char *, int, char *, int);
void mic_wpa_populate(char *, int, char *, int);

#endif
