/*******************************************************************
 * WPA-PSK Function implementations for supplicant
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 * 
 * File: psk.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: psk.c,v 1.2 2004/09/02 17:17:22 chessing Exp $
 * $Date: 2004/09/02 17:17:22 $
 * $Log: psk.c,v $
 * Revision 1.2  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.1  2004/08/28 06:08:26  chessing
 *
 * More pieces for WPA-PSK.  MIC calculation code is now included.  Code to generate the hex key for WPA-PSK from an ascii password.
 *
 *
 *******************************************************************/

#include <openssl/hmac.h>
#include <openssl/err.h>
#include <assert.h>
#include <string.h>

#include "profile.h"
#include "xsup_debug.h"

/*********************************************************************
 *
 * This code taken from 802.11i-D3.0, section F.8.2 reference implementation.
 *
 *********************************************************************/
void psk_wpa_pbkdf2_f(char *password, unsigned char *ssid, int ssidlength,
		      int iterations, int count, unsigned char *output)
{
  unsigned char digest[36], digest1[SHA_DIGEST_LENGTH];
  int i, j, k;

  for (i=0; i < strlen(password); i++)
    {
      assert((password[i] >= 32) && (password[i] <= 126));
    }

  /* U1 = PRF(P, S || int(i)) */
  memcpy(digest, ssid, ssidlength);
  digest[ssidlength] = (unsigned char)((count>>24) & 0xff);
  digest[ssidlength+1] = (unsigned char)((count>>16) & 0xff);
  digest[ssidlength+2] = (unsigned char)((count>>8) & 0xff);
  digest[ssidlength+3] = (unsigned char)(count & 0xff);

  // OpenSSL takes the parameters in a different order than what is
  // defined in F.8.2, so even though it looks wrong, this is correct. ;)
  HMAC(EVP_sha1(), password, strlen(password), digest, ssidlength+4, 
       digest1, &k);

  /* output = U1 */
  memcpy(output, digest1, SHA_DIGEST_LENGTH);

  for (i = 1; i < iterations; i++)
    {
      /* Un = PRF(P, Un-1) */
      HMAC(EVP_sha1(), password, strlen(password), digest1, SHA_DIGEST_LENGTH, 
	   digest, &k);
      memcpy(digest1, digest, k);

      /* output = output xor Un */
      for (j = 0; j < SHA_DIGEST_LENGTH; j++)
	{
	  output[j] ^= digest[j];
	}
    }
}

int psk_wpa_pbkdf2(char *password, unsigned char *ssid, int ssidlength,
		   unsigned char *output)
{
  if ((strlen(password) > 63) || (ssidlength > 32))
    {
      debug_printf(DEBUG_NORMAL, "Invalid WPA-PSK password!\n");
      return FALSE;
    }

  psk_wpa_pbkdf2_f(password, ssid, ssidlength, 4096, 1, output);
  psk_wpa_pbkdf2_f(password, ssid, ssidlength, 4096, 2, 
		   &output[SHA_DIGEST_LENGTH]);
  return TRUE;
}
