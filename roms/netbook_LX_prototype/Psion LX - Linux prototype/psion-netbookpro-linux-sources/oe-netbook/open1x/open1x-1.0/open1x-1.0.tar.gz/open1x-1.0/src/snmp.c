/*******************************************************************
 * File: snmp.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file fore more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: snmp.c,v 1.3 2004/09/02 17:17:22 chessing Exp $
 * $Date: 2004/09/02 17:17:22 $
 * $Log: snmp.c,v $
 * Revision 1.3  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.2  2004/08/11 04:01:17  chessing
 *
 * The -d option now supports letter designations for each debug level, in addition to 0..7.  (However, both letters and numbers can't be used at the same time!)  Also changed some formatting for the SNMP scoreboard.
 *
 * Revision 1.1  2004/08/11 02:44:55  chessing
 *
 * Added missing snmp.c/h files.
 *
 *
 *******************************************************************/

#include "snmp.h"
#include "profile.h"
#include "xsup_debug.h"

void snmp_dump_stats(struct interface_data *intcur)
{
  while (intcur != NULL)
    {
      debug_printf(DEBUG_SNMP, "\nStats for Interface %s with index %d :\n\n",
		   intcur->intName, intcur->intIndex);

      debug_printf(DEBUG_SNMP, "EAPOL Frames RX    : %10d   EAPOL Frames TX    : %10d\n", 
		   intcur->snmp->dot1xSuppEapolFramesRx, intcur->snmp->dot1xSuppEapolFramesTx);
      debug_printf(DEBUG_SNMP, "EAPOL Starts TX    : %10d   EAPOL Logoff TX    : %10d\n",
		   intcur->snmp->dot1xSuppEapolStartFramesTx, intcur->snmp->dot1xSuppEapolLogoffFramesTx);
      debug_printf(DEBUG_SNMP, "EAPOL Resp. ID TX  : %10d   EAPOL Resp. TX     : %10d\n",
		   intcur->snmp->dot1xSuppEapolRespIdFramesTx, intcur->snmp->dot1xSuppEapolRespFramesTx);
      debug_printf(DEBUG_SNMP, "EAPOL Req. ID RX   : %10d   EAPOL Req. RX      : %10d\n",
		   intcur->snmp->dot1xSuppEapolReqIdFramesRx, intcur->snmp->dot1xSuppEapolReqFramesRx);
      debug_printf(DEBUG_SNMP, "EAPOL Invalid Frame: %10d   EAP Length Error   : %10d\n",
		   intcur->snmp->dot1xSuppInvalidEapolFramesRx, intcur->snmp->dot1xSuppEapLengthErrorFramesRx);
      debug_printf(DEBUG_SNMP, "Last EAPOL Version : %10d   Last EAPOL Src.    :",
		   intcur->snmp->dot1xSuppLastEapolFrameVersion);
      debug_hex_printf(DEBUG_SNMP, intcur->snmp->dot1xSuppLastEapolFrameSource, 6);
      debug_printf(DEBUG_SNMP, "EAPOL Success      : %10d   EAPOL Failure      : %10d\n\n",
		   intcur->snmp->eapol_success_rx, intcur->snmp->eapol_fail_rx);
      
      intcur = intcur->next;
    }
}

