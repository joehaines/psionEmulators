/*******************************************************************
 * Handle state machine related functions.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: statemachine.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _STATEMACHINE_H_
#define _STATEMACHINE_H_

#include "profile.h"

// This matches the order of states listed in IEEE 802.1x-2001, pg. 59,
// section 8.5.10.
#define LOGOFF           0
#define DISCONNECTED     1
#define CONNECTING       2
#define ACQUIRED         3
#define AUTHENTICATING   4
#define HELD             5
#define AUTHENTICATED    6

int statemachine_init(struct interface_data *);
int statemachine_run(struct interface_data *, char *, int, char *, int *);
int statemachine_cleanup(struct interface_data *);
int txLogoff(char *, int *);
int txRspId(struct interface_data *, char *, int *);
int txRspAuth(struct interface_data *, char *, int, char *, int *);
int txStart(char *, int *);
#endif
