/*******************************************************************
 * File: wpa.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: wpa.c,v 1.3 2004/09/02 17:17:22 chessing Exp $
 * $Date: 2004/09/02 17:17:22 $
 * $Log: wpa.c,v $
 * Revision 1.3  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.2  2004/08/31 04:49:20  chessing
 *
 * We now have the functions needed to do PRF-X, and compute the MIC.  We attempt to answer the first packet of the 4-way handshake, but appear to be getting something wrong. :-/
 *
 * Revision 1.1  2004/08/19 02:28:06  chessing
 * First piece of WPA patch.  (The patch is growing fast, and this commit is to save what is done so far.)
 *
 *
 *******************************************************************/

#include <string.h>
#include <inttypes.h>
#include <openssl/hmac.h>

#include "wpa.h"
#include "xsup_debug.h"

void wpa_print_auth_suite(unsigned char asuite)
{
  switch (asuite)
    {
    case 0x00:
      debug_printf(DEBUG_NORMAL, "Reserved\n");
      break;
      
    case 0x01:
      debug_printf(DEBUG_NORMAL, "Unspecified authentication over 802.1X\n");
      break;

    case 0x02:
      debug_printf(DEBUG_NORMAL, "None/WPA-PSK\n");
    }
}

void wpa_print_cipher_suite(unsigned char csuite)
{
  switch (csuite)
    {
    case 0x00:
      debug_printf(DEBUG_NORMAL, "None\n");
      break;

    case 0x01:
      debug_printf(DEBUG_NORMAL, "WEP-40\n");
      break;

    case 0x02:
      debug_printf(DEBUG_NORMAL, "TKIP\n");
      break;

    case 0x03:
      debug_printf(DEBUG_NORMAL, "WRAP\n");
      break;

    case 0x04:
      debug_printf(DEBUG_NORMAL, "CCMP\n");
      break;

    case 0x05:
      debug_printf(DEBUG_NORMAL, "WEP-104\n");
      break;
    }
}


void wpa_parse_ie(char *iedata)
{
  struct wpa_ie_struct *ie_struct;
  char wpa_oui[3] = {0x00, 0x50, 0xf2};
  char suite_id[4];
  int i, ieptr;
  uint16_t value16;

  ie_struct = (struct wpa_ie_struct *)iedata;

  if (ie_struct->wpaid != 0xdd)
    {
      debug_printf(DEBUG_NORMAL, "IE is not a valid WPA IE! (Invalid vendor value!)\n");
      return;
    }

  debug_printf(DEBUG_NORMAL, "--- WPA Data ---\n");
  
  if ((memcmp(ie_struct->oui, wpa_oui, 3) != 0) && (ie_struct->oui[4] != 0x01))
    {
      debug_printf(DEBUG_NORMAL, "IE is not a valid WPA IE! (Invalid OUI value!\n");
      return;
    }

  debug_printf(DEBUG_NORMAL, "WPA Version : %d\n", ie_struct->wpa_ver);
  debug_printf(DEBUG_NORMAL, "Group Key Cipher Suite : ");
  wpa_print_cipher_suite(ie_struct->group_cipher[4]);

  debug_printf(DEBUG_NORMAL, "Pairwise Key Cipher Suite Count : %d\n",
	       ie_struct->pk_suite_cnt);

  ieptr = sizeof(struct wpa_ie_struct);

  for (i=0;i<ie_struct->pk_suite_cnt;i++)
    {
      debug_printf(DEBUG_NORMAL, "Cipher Suite : ");
      memcpy((char *)&suite_id, (char *)&iedata[ieptr], 4);

      if (memcmp(suite_id, wpa_oui, 3) != 0)
	{
	  debug_printf(DEBUG_NORMAL, "Invalid WPA OUI!\n");
	} else {
	  wpa_print_cipher_suite(suite_id[3]);
	}

      ieptr+=4;
    }

  memcpy((char *)&value16, (char *)&iedata[ieptr], 2);
  ieptr+=2;
  debug_printf(DEBUG_NORMAL, "Authenticated Key Management Suite Count : %d\n",
	       value16);

  for (i=0;i<value16;i++)
    {
      debug_printf(DEBUG_NORMAL, "Authentication Suite : ");
      memcpy((char *)&suite_id, (char *)&iedata[ieptr], 4);

      if (memcmp(suite_id, wpa_oui, 3) != 0)
	{
	  debug_printf(DEBUG_NORMAL, "Invalid WPA OUI!\n");
	} else {
	  wpa_print_auth_suite(suite_id[3]);
	}
      ieptr+=4;
    }

  if (ieptr < ie_struct->wpalen)
    {
      memcpy((char *)&value16, (char *)&iedata[ieptr], 2);
      debug_printf(DEBUG_NORMAL, "RSN Capabilities : %04X\n\n", value16);
    }
}

/* Code taken from the PRF reference code in 802.11i-D3.0 */
void wpa_PRF(unsigned char *key, int key_len, unsigned char *prefix,
	     int prefix_len, unsigned char *data, int data_len, 
	     unsigned char *output, int len)
{
  int i;
  unsigned char input[1024];
  int currentindex = 0, k;
  int total_len;

  memcpy(input, prefix, prefix_len);
  input[prefix_len] = 0;
  memcpy(&input[prefix_len+1], data, data_len);
  total_len = prefix_len + 1 + data_len;
  input[total_len] = 0;
  total_len++;
  for (i=0; i<(len+19)/20; i++)
    {
      // This is a little different than the reference implementation, 
      // because OpenSSL takes parameters in a different order.
      HMAC(EVP_sha1(), key, key_len, input, total_len, &output[currentindex],
	   &k);
      currentindex += 20;
      input[total_len-1]++;
    }
}

/* These functions are defined by 802.11i-D3.0 */
void wpa_STADisconnect()
{

}

void wpa_RemoveGTK()
{

}

