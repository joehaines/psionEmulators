/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: wpa.h
 *
 *******************************************************************/

#ifndef _WPA_H_
#define _WPA_H_

#define WPA_PSK        -1

struct wpa_ie_struct {
  unsigned char wpaid;
  unsigned char wpalen;
  unsigned char oui[4];
  uint16_t wpa_ver;
  unsigned char group_cipher[4];
  uint16_t pk_suite_cnt;

  // The rest of the IE is variable, and can be structured here.
};

void wpa_parse_ie(char *);
char *wpa_minmax(char *, char *, int, char);
void wpa_PRF(unsigned char *, int, unsigned char *, int, unsigned char *, int,
	     unsigned char *, int);

#endif
