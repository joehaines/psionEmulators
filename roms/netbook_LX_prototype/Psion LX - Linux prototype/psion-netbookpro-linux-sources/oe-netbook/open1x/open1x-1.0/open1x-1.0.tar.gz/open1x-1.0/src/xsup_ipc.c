/*******************************************************************
 *
 * File: xsup_ipc.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: xsup_ipc.c,v 1.21 2004/09/15 03:10:26 chessing Exp $
 * $Date: 2004/09/15 03:10:26 $
 * $Log: xsup_ipc.c,v $
 * Revision 1.21  2004/09/15 03:10:26  chessing
 * Cleanups for various compiler warnings, etc.
 *
 * Revision 1.20  2004/09/15 01:33:48  chessing
 * Updates to IPC and logging functionality.  The config file command 'ipc_group' can be set to the name of the group that users need to be a member of in order to use IPC with the daemon.  Also, an update to an older patch.  If the config file value for 'logfile' is set to 'syslog', then we will log to the syslog daemon.  A new command 'log_facility' specifies the log facility that should be used when in syslog mode.  If not in syslog mode, log_facility does nothing.
 *
 * Revision 1.19  2004/09/10 22:23:00  chessing
 * More updates to IPC.  We now speak IPC with the messages being version 2, instead of version 1.  Because version 1 messages were only allowed across the loopback interface, they have been deprecated, and will result in an error from Xsupplicant!
 *
 * Revision 1.18  2004/09/09 23:11:36  chessing
 * Changed IPC socket to use a Unix Domain socket instead of a loopback socket.  Still need to set privs on the file that is used for the socket, so that non-root users can issue commands.  (Should probably have the socket belong to a group such as dot1x and allow group member writes.)
 *
 * Revision 1.17  2004/09/02 17:17:22  chessing
 *
 * Removed the license text from the headers of all files, and put it in a single file called LICENSE.  All files contain the line "Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)"
 *
 * Revision 1.16  2004/07/15 04:15:35  chessing
 *
 * True/false int values are now bit flags in a byte.  PEAP now calls back in to functions from eap.c for phase 2 methods.  This allows for any phase 1 EAP type to work.  This resulted in some major changes the functions in eap.c, and in peap_phase2.c.  PEAP has been tested using both MS-CHAPv2, and EAP-MD5 as inner types.  More types need to be tested, and enabled.
 *
 * Revision 1.15  2004/06/15 03:22:29  chessing
 *
 * XSupplicant Release 1.0
 *
 *
 *******************************************************************/

#include <sys/socket.h>
//#include <sys/fcntl.h>
#include <sys/un.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <net/if.h>

#include "profile.h"
#include "config.h"
#include "xsup_ipc.h"
#include "xsup_debug.h"
#include "xsup_err.h"
#include "ipc_callout.h"

#define XSUP_SOCKET "/tmp/xsupplicant.sock"

static int ipc_sock;

// mset is the master set of sockets in use.
static fd_set mset;
static int max_sock = 0;

/******************************************************************
 *
 * Initalize the socket that we will use to communicate with a client/clients.
 * Also, set up any structures that may be needed.
 *
 ******************************************************************/
int xsup_ipc_init()
{
  int sockErr = 0, ipc_gid = 0;
  char *error = NULL;
  struct sockaddr_un sa;

  sa.sun_family = AF_LOCAL;
  strncpy(sa.sun_path, XSUP_SOCKET, sizeof(sa.sun_path));

  // Socket we will be using to communicate.
  ipc_sock = socket(PF_UNIX, SOCK_STREAM, 0);

  if (ipc_sock == -1) {
    debug_printf(DEBUG_NORMAL, "Couldn't establish handler to daemon socket!\n");
    return XENOSOCK;
  } 

  max_sock = ipc_sock;
  FD_SET(ipc_sock, &mset);

  debug_printf(DEBUG_INT, "Opened socket descriptor #%d\n", ipc_sock);

  sockErr = bind(ipc_sock, (struct sockaddr *)&sa, sizeof(sa));
  if (sockErr == -1) 
    {
      error = strerror(errno);
      debug_printf(DEBUG_NORMAL, "An error occured binding to socket.  (Error : %s)\n", error);
      close(ipc_sock);
      return XENOSOCK;
    }

  sockErr = listen(ipc_sock, 10);
  if (sockErr < 0)
    {
      error = strerror(errno);
      debug_printf(DEBUG_NORMAL, "An error occured listening on the socket! "
		   "(Error : %s)\n", error);
      close(ipc_sock);
      return XENOSOCK;
    }

  // Set the rights on the file.
  if (chmod(XSUP_SOCKET, S_IREAD | S_IWRITE | S_IEXEC | S_IRGRP | S_IWGRP |
	     S_IXGRP | S_IROTH | S_IXOTH) != 0)
    {
      debug_printf(DEBUG_NORMAL, "Can't set rights on socket file! (Error : "
		   "%s)\n", strerror(errno));
    }

  // Set the correct group ownership. 
  ipc_gid = config_get_ipc_gid();

  if (ipc_gid >= 0)
    {
      if (chown(XSUP_SOCKET, -1, ipc_gid) != 0)
	{
	  debug_printf(DEBUG_NORMAL, "Can't set group ownership on socket file"
		       "! (Error : %s)\n", strerror(errno));
	}
    }

  return XENONE;
}

/**************************************************************
 *
 * Send a message to a client.
 *
 **************************************************************/
void xsup_ipc_send_message(int skfd, char *tosend, int tolen)
{
  int err;

  if ((!tosend) || (tolen <= 0))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to xsup_ipc_send_message()!\n");
      return;
    }

  debug_printf(DEBUG_INT, "(IPC) Sending : \n");
  debug_hex_dump(DEBUG_INT, tosend, tolen);

  err = send(skfd, tosend, tolen, 0);
  if (err < 0)
    {
      debug_printf(DEBUG_NORMAL, "Error writing to client! (Error : %s)\n",
		   strerror(errno));
      return;
    }

  if (err < tolen)
    {
      debug_printf(DEBUG_NORMAL, "Runt message sent to client!\n");
    }
}

/**************************************************************
 *
 * Get a message from a client.  Validate it, and return the payload.
 * outsize should be passed in a valid that is the maximum size of
 * outbuf.  outsize will then be changed to the size of the result
 * buffer.
 *
 **************************************************************/
void xsup_ipc_get_message(int sockdesc, char *outbuf, int *outsize, 
			  char *interface)
{
  int readStat = -1;
  struct ipc_header *myheader;
  char intname[32];

  if ((!outbuf) || (!outsize) || (!interface))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to xsup_ipc_get_message()!\n");
      return;
    }

  readStat = recv(sockdesc, outbuf, *outsize, 0);

  if (readStat <= 0)
    {
      if (readStat == 0)
	{
	  debug_printf(DEBUG_NORMAL, "Disconnecting socket!\n");
	  FD_CLR(sockdesc, &mset);
	} else {
	  debug_printf(DEBUG_NORMAL, "Couldn't read message from a client! (Error %d -- %s)\n", errno,
		       strerror(errno));
	}

      *outsize = 0;
    } else {
      debug_printf(DEBUG_INT, "(IPC) Got : \n");
      debug_hex_dump(DEBUG_INT, outbuf, readStat);
      // Verify that the packet we got is valid.
      
      *outsize = readStat;
      myheader = (struct ipc_header *)outbuf;

      // Make sure we have a valid version.
      if (myheader->version != 2)
	{
	  debug_printf(DEBUG_NORMAL, "Got a request from a client with version"
		       " %d!  We only support clients with versions == 2!\n",
		       myheader->version);
	  *outsize = 0;
	  return;
	}

      if (myheader->version == 2) 
	{
	  if_indextoname(myheader->int_idx, intname);
	  if (intname == NULL)
	    {
	      debug_printf(DEBUG_NORMAL, "Invalid interface index in IPC "
			   "packet!  Packet ignored!\n");
	      *outsize = 0;
	      return;
	    }

	  // We have a valid version.
      	  debug_printf(DEBUG_INT, "Version : %d  Interface Index : %d "
		       " Interface Name : %s\n", myheader->version, 
		       myheader->int_idx, intname);

	  free(intname);
	} else {
	  debug_printf(DEBUG_NORMAL, "Error : Invalid packet header!\n");
	  *outsize = 0;
	}
    }
}

/***********************************************************
 *
 * Send a message to all registered clients.
 *
 ***********************************************************/
int xsup_ipc_send_all(char *message, int msglen)
{
  int i;

  for (i=0;i<max_sock+1;i++)
    {
      if ((FD_ISSET(i, &mset)) && (i != ipc_sock))
	{
	  xsup_ipc_send_message(i, message, msglen);
	}
    }
  
  return XENONE;
}

/***********************************************************
 *
 * Locate the correct interface, and return a pointer to it's structure. If
 * it isn't a valid interface, then return NULL, and send an error packet
 * back.
 *
 ***********************************************************/
struct interface_data *xsup_ipc_select_int(int skfd, char interface, 
					   struct interface_data *thisint)
{
  char outbuf[1500];
  char retstr[150];
  struct ipc_header *myheader;
  struct interface_data *cur;
  int bufptr;

  if ((!interface) || (!thisint))
    {
      debug_printf(DEBUG_NORMAL, "Invalid data passed in to xsup_ipc_select_int()!\n");
      return NULL;
    }

  cur = thisint;

  while ((cur != NULL) && (interface != cur->intIndex))
    {
      cur = cur->next;
    }
  if (cur != NULL) return cur;

  // Otherwise, we don't know about the interface that was requested so we 
  // send an error message.
  debug_printf(DEBUG_NORMAL, "Unknown interface index %d!\n",interface);
  bzero(&outbuf, 1500);
  myheader = (struct ipc_header *)&outbuf[0];
  
  myheader->version = 2;  // We only know about version 2 for now.
  myheader->int_idx = interface;

  bufptr = sizeof(struct ipc_header);

  sprintf((char *)&retstr, "Unknown interface %d!", interface);

  ipc_callout_send_error(thisint, &bufptr, (char *)&outbuf[0], 1500, 
			 (char *)&retstr);

  xsup_ipc_send_message(skfd, &outbuf[0], bufptr);
  return NULL;
}

/***********************************************************
 *
 * Handle the requests the client sent us.
 *
 ***********************************************************/
void xsup_ipc_handle_requests(struct interface_data *thisint,
			      struct interface_data *workint, int skfd,
			      char *buffer, int bufsize)
{
  char sendbuf[1520];
  int sendsize, bufptr;
  struct ipc_header *rethead;
  struct ipc_cmd *cmd;

  rethead = (struct ipc_header *)sendbuf;
  // Set up our header.
  rethead->version = 2;
  rethead->int_idx = workint->intIndex;

  sendsize = sizeof(struct ipc_header);

  bufptr = 0;
  
  while (bufptr < bufsize)
    {
      switch (buffer[bufptr])
	{
	case AUTH_STATE:
	    debug_printf(DEBUG_EVERYTHING, "Checking auth state!\n");
	    ipc_callout_auth_state(workint, &bufptr, buffer, 
				   bufsize, (char *)&sendbuf, &sendsize);
	    break;
	      
	case CONFIG:
	  debug_printf(DEBUG_EVERYTHING, "Setting password!\n");
	  ipc_callout_process_conf(workint, &bufptr, buffer, 
				   bufsize, (char *)&sendbuf, &sendsize);
	  break;
	      
	case INTERFACES:
	  debug_printf(DEBUG_EVERYTHING, "Returning interface list!\n");
	  ipc_callout_get_ints(thisint, workint, &bufptr, buffer, 
			       bufsize, (char *)&sendbuf, &sendsize);
	  break;
		
	case PROFILE:
	  // Get or set a profile.
	  debug_printf(DEBUG_EVERYTHING, "Loading new profile...\n");
	  ipc_callout_getset_profile(workint, &bufptr, buffer,
				     bufsize, (char *)&sendbuf, &sendsize);
	  break;
		
	case TEMPPASSWORD:
	  // Set a temporary password.
	  debug_printf(DEBUG_EVERYTHING, "Setting temporary password.\n");
	  ipc_callout_set_password(workint, &bufptr, buffer,
				   bufsize, (char *)&sendbuf, &sendsize);
	  break;
		
	case ERROR_MSG:
	  debug_printf(DEBUG_NORMAL, "Got an error message from the client.  "
		       "Your client is probably broken!\n");
	  break;
	  
	default:
	  debug_printf(DEBUG_NORMAL, "Unknown command %02X!\n",buffer[bufptr]);
	  cmd = (struct ipc_cmd *)&buffer[bufptr];

	  if ((bufptr+(cmd->len+sizeof(struct ipc_cmd))) > bufsize)
	    {
	      debug_printf(DEBUG_NORMAL, "Size included in command is too high"
			   "! Ignoring remaining part of packet!\n");
	      bufptr = bufsize;
	    } else {
	      bufptr+= (cmd->len+sizeof(struct ipc_cmd));
	    }
	}
    }
  
  // Make sure we actually have something to return.
  if (sendsize > (sizeof(struct ipc_header)+sizeof(struct ipc_cmd)-2))
    {
      debug_printf(DEBUG_EVERYTHING, "Sending IPC response!\n");
      xsup_ipc_send_message(skfd, sendbuf, sendsize);
    } else {
      debug_printf(DEBUG_NORMAL, "sendsize = %d\n", sendsize);
    }
}

/***********************************************************
 *
 * Parse the IPC packet we got, and act on requests.
 *
 ***********************************************************/
void xsup_ipc_process_message(struct interface_data *thisint, int skfd, 
			      char *inbuf, int bufsize)
{
  struct interface_data *curint;
  struct ipc_header *myheader;

  if (bufsize <= 0)
    {
      debug_printf(DEBUG_NORMAL, "No data in IPC buffer!  (%s:%d)\n",
		   __FUNCTION__, __LINE__);
      return;
    }

  myheader = (struct ipc_header *)inbuf;

  if (myheader->version != 2)
    {
      debug_printf(DEBUG_NORMAL, "Unknown version requested! (Version : %d)\n",
		   myheader->version);
      return;
    }

  curint = xsup_ipc_select_int(skfd, myheader->int_idx, thisint);
  if (curint == NULL)
    {
      // We don't know about this interface!
      return;
    }

  // Now, we know that the interface we are using is valid, and the IPC header
  // is correct.  So, start processing the requests.
  xsup_ipc_handle_requests(thisint, curint, skfd, 
			   (char *)&inbuf[sizeof(struct ipc_header)],
			   bufsize - sizeof(struct ipc_header));
}

/***********************************************************
 *
 * Process any IPC messages, and respond accordingly.
 *
 ***********************************************************/
void xsup_ipc_process(struct interface_data *thisint)
{
  char buffer[1520];   // We shouldn't have a message larger than this.
  char result_buf[1520], interface[16];
  int bufsize, resbufptr, numcmds, selres, i, newsock, len;
  fd_set tset;
  struct timeval tv;
  struct ipc_header *rethead, *inhead;
  struct sockaddr sa;

  if (!thisint)
    {
      debug_printf(DEBUG_NORMAL, "Invalid interface struct in xsup_ipc_process()!\n");
      return;
    }

  bufsize = 1520;
  resbufptr = 0;
  numcmds = 0;

  rethead = (struct ipc_header *)&result_buf[0];
  bzero(&result_buf[0], 1520);

  inhead = (struct ipc_header *)&buffer[0];

  tset = mset;
  tv.tv_sec = 0;
  tv.tv_usec = 0;

  selres = select(max_sock+1, &tset, NULL, NULL, &tv);
  if (selres <= 0)
    {
      // Nothing to do.
      return;
    }

  // Otherwise, loop through available sockets, and check for events.
  for (i=0;i<max_sock+1;i++)
    {
      if (FD_ISSET(i, &tset))
	{
	  if (i == ipc_sock)
	    {
	      // We got a request for a new IPC client connection.
	      debug_printf(DEBUG_INT, "Got a request to connect a new client.\n");
	      newsock = accept(ipc_sock, (struct sockaddr *)&sa, &len);
	      if (newsock <= 0)
		{
		  debug_printf(DEBUG_NORMAL, "Got a request for a new IPC client "
			       "connection.  But, accept() returned an error!\n");
		} else {
		  FD_SET(newsock, &mset);
		  if (newsock > max_sock)
		    {
		      max_sock = newsock;
		    }
		}
	    } else {
	      bufsize = 1520;
	      xsup_ipc_get_message(i, (char *)&buffer, &bufsize, 
				   (char *)&interface);

	      xsup_ipc_process_message(thisint, i, (char *)&buffer, bufsize);
	    }
	}
    }
}

/***********************************************************
 *
 * Clean up any structures used, and close out the communication socket.
 *
 ***********************************************************/
void xsup_ipc_cleanup()
{
  char *error;

  debug_printf(DEBUG_EVERYTHING, "Shutting down IPC socket!\n");
  debug_printf(DEBUG_INT, "Closing socket descriptor #%d\n", ipc_sock);
  if (close(ipc_sock) < 0)
    {
      error = strerror(errno);
      debug_printf(DEBUG_NORMAL, "Error closing socket!  (Error : %s)\n",
		   error);
    }

  unlink(XSUP_SOCKET);
}
