/***************************************************************************************
	Copyright 2000-2001 ATMEL Corporation.
	
    WPA Supplicant - driver interaction with Atmel Wireless lan drivers.
    
    This is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Atmel wireless lan drivers; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

**************************************************************************************/

/*
 * WPA Supplicant - driver interaction with atmel driver
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "wireless_copy.h"
#include "common.h"
#include "driver.h"
#include "driver_wext.h"
#include "wpa_supplicant.h"

#define ATMEL_WPA_IOCTL                (SIOCIWFIRSTPRIV + 2)
#define ATMEL_WPA_IOCTL_PARAM          (SIOCIWFIRSTPRIV + 3)
#define ATMEL_WPA_IOCTL_GET_PARAM      (SIOCIWFIRSTPRIV + 4)


/* ATMEL_WPA_IOCTL ioctl() cmd: */
enum {
    SET_WPA_ENCRYPTION  = 1,
    SET_CIPHER_SUITES   = 2,
    MLME_STA_DEAUTH     = 3,
    MLME_STA_DISASSOC   = 4,
};

/* ATMEL_WPA_IOCTL_PARAM ioctl() cmd: */
enum {
            ATMEL_PARAM_WPA = 1,
            ATMEL_PARAM_PRIVACY_INVOKED = 2,
            ATMEL_PARAM_WPA_TYPE = 3,
};

#define MAX_KEY_LENGTH      40

struct atmel_param{
    unsigned char sta_addr[6];
        int     cmd;
        u8      alg;
        u8      key_idx;
        u8      set_tx;
        u8      seq[8];
        u8      seq_len;
        u16     key_len;
        u8      key[MAX_KEY_LENGTH];
    struct{
        int     reason_code;
        u8      state;
    }mlme;
    u8          pairwise_suite;
    u8          group_suite;
    u8          key_mgmt_suite;
};

    
    
static int atmel_ioctl(const char *dev, struct atmel_param *param,
			 int len, int show_err)
{
	int s;
	struct iwreq iwr;

	s = socket(PF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		perror("socket");
		return -1;
	}

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, dev, IFNAMSIZ);
	iwr.u.data.pointer = (caddr_t) param;
	iwr.u.data.length = len;

	if (ioctl(s, ATMEL_WPA_IOCTL, &iwr) < 0) {
		int ret;
		close(s);
		ret = errno;
		if (show_err) 
			perror("ioctl[ATMEL_WPA_IOCTL]");
		return ret;
	}
	close(s);

	return 0;
}


static int atmel2param(const char *ifname, int param, int value)
{
	struct iwreq iwr;
	int *i, s, ret = 0;

	s = socket(PF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		perror("socket[PF_INET,SOCK_DGRAM]");
		return -1;
	}

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ);
	i = (int *) iwr.u.name;
	*i++ = param;
	*i++ = value;

	if (ioctl(s, ATMEL_WPA_IOCTL_PARAM, &iwr) < 0) {
		perror("ioctl[ATMEL_WPA_IOCTL_PARAM]");
		ret = -1;
	}
	close(s);
	return ret;
}


/*static int wpa_driver_atmel_set_wpa_ie(const char *ifname, const char *wpa_ie,
					size_t wpa_ie_len)
{
	struct atmel_param *param;
	int res;
	size_t blen = ATMEL_GENERIC_ELEMENT_HDR_LEN + wpa_ie_len;
	if (blen < sizeof(*param))
		blen = sizeof(*param);

	param = (struct atmel_param *) malloc(blen);
	if (param == NULL)
		return -1;

	memset(param, 0, blen);
	param->cmd = ATMEL_SET_GENERIC_ELEMENT;
	param->u.generic_elem.len = wpa_ie_len;
	memcpy(param->u.generic_elem.data, wpa_ie, wpa_ie_len);
	res = atmel_ioctl(ifname, param, blen, 1);

	free(param);

	return res;
}*/


static int wpa_driver_atmel_set_wpa(const char *ifname, int enabled)
{
        int ret = 0;
	
        printf("wpa_driver_atmel_set_wpa %s\n", ifname);

	wpa_printf(MSG_DEBUG, "%s: enabled=%d", __FUNCTION__, enabled);

	//if (!enabled && wpa_driver_atmel_set_wpa_ie(ifname, NULL, 0) < 0)
	//	ret = -1;
	if (atmel2param(ifname, ATMEL_PARAM_PRIVACY_INVOKED, enabled) < 0)
		ret = -1;
	if (atmel2param(ifname, ATMEL_PARAM_WPA, enabled) < 0)
		ret = -1;

	return ret;
}


static int wpa_driver_atmel_set_key(const char *ifname, wpa_alg alg,
				      unsigned char *addr, int key_idx,
				      int set_tx, u8 *seq, size_t seq_len,
				      u8 *key, size_t key_len)
{
	int ret = 0;
        struct atmel_param *param;
	u8 *buf;
        u8 alg_type;
        
	size_t blen;
	char *alg_name;

	switch (alg) {
	case WPA_ALG_NONE:
		alg_name = "none";
                alg_type = 0;
		break;
	case WPA_ALG_WEP:
		alg_name = "WEP";
		alg_type = 1;
                break;
	case WPA_ALG_TKIP:
		alg_name = "TKIP";
		alg_type = 2;
                break;
	case WPA_ALG_CCMP:
		alg_name = "CCMP";
		alg_type = 3;
                break;
	default:
		return -1;
	}

	wpa_printf(MSG_DEBUG, "%s: alg=%s key_idx=%d set_tx=%d seq_len=%d "
		   "key_len=%d", __FUNCTION__, alg_name, key_idx, set_tx,
		   seq_len, key_len);

	if (seq_len > 8)
		return -2;

	blen = sizeof(*param) + key_len;
	buf = malloc(blen);
	if (buf == NULL)
		return -1;
	memset(buf, 0, blen);

	param = (struct atmel_param *) buf;
        
        param->cmd = SET_WPA_ENCRYPTION; 
        
        if (addr == NULL)
		memset(param->sta_addr, 0xff, ETH_ALEN);
	else
		memcpy(param->sta_addr, addr, ETH_ALEN);
        
        param->alg = alg_type;
        param->key_idx = key_idx;
        param->set_tx = set_tx;
        memcpy(param->seq, seq, seq_len);
        param->seq_len = seq_len;
        param->key_len = key_len;
	memcpy((u8 *)param->key, key, key_len);
	
        if (atmel_ioctl(ifname, param, blen, 1)) {
		wpa_printf(MSG_WARNING, "Failed to set encryption.");
		/* TODO: show key error*/
		ret = -1;
	}
	free(buf);

	return ret;
}


static int wpa_driver_atmel_set_countermeasures(const char *ifname,
						 int enabled)
{
	/* FIX */
	printf("wpa_driver_atmel_set_countermeasures - not yet "
	       "implemented\n");
	return 0;
}


static int wpa_driver_atmel_set_drop_unencrypted(const char *ifname,
						  int enabled)
{
	/* FIX */
	printf("wpa_driver_atmel_set_drop_unencrypted - not yet "
	       "implemented\n");
	return 0;
}


static int wpa_driver_atmel_mlme(const char *ifname, u8 *addr, int cmd,
				  int reason_code)
{
	struct atmel_param param;
	int ret;
        int mgmt_error = 0xaa;
        
	memset(&param, 0, sizeof(param));
	memcpy(param.sta_addr, addr, ETH_ALEN);
	param.cmd = cmd;
	param.mlme.reason_code = reason_code;
        param.mlme.state = mgmt_error;
	ret = atmel_ioctl(ifname, &param, sizeof(param), 1);
	return ret;
}


#if 0
static int wpa_driver_atmel_set_suites(const char *ifname, u8 pairwise_suite, u8 group_suite, u8 key_mgmt_suite)
{
	struct atmel_param param;
	int ret;
        
	memset(&param, 0, sizeof(param));
        param.cmd = SET_CIPHER_SUITES;
        param.pairwise_suite = pairwise_suite;
        param.group_suite = group_suite;
        param.key_mgmt_suite = key_mgmt_suite;
	        
	ret = atmel_ioctl(ifname, &param, sizeof(param), 1);
	return ret;
}
#endif


static int wpa_driver_atmel_deauthenticate(const char *ifname, u8 *addr,
					     int reason_code)
{
	printf("wpa_driver_atmel_deauthenticate\n");
        wpa_printf(MSG_DEBUG, "%s", __FUNCTION__);
	return wpa_driver_atmel_mlme(ifname, addr, MLME_STA_DEAUTH,
				      reason_code);

}


static int wpa_driver_atmel_disassociate(const char *ifname, u8 *addr,
					   int reason_code)
{
	printf("wpa_driver_atmel_disassociate\n");
	wpa_printf(MSG_DEBUG, "%s", __FUNCTION__);
	return wpa_driver_atmel_mlme(ifname, addr, MLME_STA_DISASSOC,
				      reason_code);

}


// Atmel driver uses specific values for each cipher suite
static int convertSuiteToDriver(wpa_cipher suite)
{
    u8 suite_type;
    
    switch(suite) {
        case CIPHER_NONE:
                suite_type =  0;
                break;
        case CIPHER_WEP40:
                suite_type =  1;
                break;
        case CIPHER_TKIP:
                suite_type = 2;
                break;
        case CIPHER_WEP104:
                suite_type = 5;
                break;
        case CIPHER_CCMP:
                suite_type = 3;
                break;
        default:
                suite_type = 2;
    }
    
    return suite_type;

}
    
static int wpa_driver_atmel_associate(const char *ifname, const char *bssid,
					const char *ssid, size_t ssid_len,
					int freq,
					const char *wpa_ie, size_t wpa_ie_len,
					wpa_cipher pairwise_suite,
					wpa_cipher group_suite,
					wpa_key_mgmt key_mgmt_suite)
{
	int ret = 0;
        u8 pairwise_suite_driver;
        u8 group_suite_driver;
        u8 key_mgmt_suite_driver;


        pairwise_suite_driver = convertSuiteToDriver(pairwise_suite);
        group_suite_driver    = convertSuiteToDriver(group_suite);
        key_mgmt_suite_driver = convertSuiteToDriver(key_mgmt_suite);
        
#if 0
        if (wpa_driver_atmel_set_suites(ifname, pairwise_suite_driver, group_suite_driver, key_mgmt_suite_driver) < 0){
	printf("wpa_driver_atmel_set_suites.\n");
                ret = -1;
        }
        if (wpa_driver_wext_set_freq(ifname, freq) < 0) {
	        printf("wpa_driver_atmel_set_freq.\n");
		ret = -1;
        }
#endif
	if (wpa_driver_wext_set_ssid(ifname, ssid, ssid_len) < 0){
	        printf("FAILED : wpa_driver_atmel_set_ssid.\n");
		ret = -1;
        }
	if (wpa_driver_wext_set_bssid(ifname, bssid) < 0) {
	        printf("FAILED : wpa_driver_atmel_set_bssid.\n");
		ret = -1;
        }

	return ret;
}


struct wpa_driver_ops wpa_driver_atmel_ops = {
	.get_bssid = wpa_driver_wext_get_bssid,
	.get_ssid = wpa_driver_wext_get_ssid,
	.set_wpa = wpa_driver_atmel_set_wpa,
	.set_key = wpa_driver_atmel_set_key,
	.events_init = wpa_driver_wext_events_init,
	.events_deinit = wpa_driver_wext_events_deinit,
	.set_countermeasures = wpa_driver_atmel_set_countermeasures,
	.set_drop_unencrypted = wpa_driver_atmel_set_drop_unencrypted,
	.scan = wpa_driver_wext_scan,
	.get_scan_results = wpa_driver_wext_get_scan_results,
	.deauthenticate = wpa_driver_atmel_deauthenticate,
	.disassociate = wpa_driver_atmel_disassociate,
	.associate = wpa_driver_atmel_associate,
};
